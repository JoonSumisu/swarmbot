# SwarmBot 编程规格说明书（v1.2 自治系统优化）

**版本**: v1.2.0
**用途**: 固化 v1.2 自治系统优化实现，作为后续 v1.3 基线
**时间**: 2026-03-15

---

## 版本变更记录

### v1.2.1 (2026-03-15)
- 更新 `__version__` 为 "1.3.0"
- 完成 Bundle-based 自治引擎集成

---

## 一、v1.2-v1.3 核心升级

### 1.1 自治引擎重构

v1.2-v1.3 将 OverthinkingLoop/OveractionLoop 升级为 **Bundle-based AutonomousEngine**：

| Bundle | Interval | 功能 |
|--------|----------|------|
| `core.memory_foundation` | 1800s (30min) | 记忆整理：压缩 Hot/Warm -> QMD |
| `core.boot_optimizer` | 1200s (20min) | 启动提示与 Agent 配置优化 |
| `core.system_hygiene` | 600s (10min) | 资源阈值诊断（disk/mem） |
| `core.bundle_governor` | 300s (5min) | Bundle 冲突检测 |

**双线模型**：
- **MonitorQueue**: 接收 bundle due 事件
- **ActionQueue**: 执行决策计划（execute_task/update_bundle/loop_optimize/gateway_report）

### 1.2 Self-Organizing Task-Based Routing

CLI 命令不再使用固定默认路由模式，而是通过 LLM 驱动的智能路由：

| Route Mode | Profile | Description |
|------------|---------|-------------|
| `simple_direct_master` | lean | 简单问答，由 Master Agent 直接回答 |
| `reasoning_swarm` | balanced | 中等复杂任务，多 Agent Swarm 协作 |
| `engineering_complex` | swarm_max | 复杂工程任务，需要人机交互确认 |

**路由决策流程**：
1. 多个 Planner Agent 并行分析问题
2. 每个 Planner 投票选择 Route Mode
3. 采用多数决（3次无工具投票）
4. 失败回退默认 `reasoning_swarm`

### 1.3 Loop Profile 动态选择

通过 `SWARMBOT_LOOP_PROFILE` 环境变量切换：

- `auto`: 先做 Step2 分析，再由 LLM 选择 profile
- `lean`: analysis_workers=1, collection_workers=1, evaluation_workers=2, max_eval_loops=2, context_limit=3500
- `balanced` (default): analysis_workers=2, collection_workers=2, evaluation_workers=3, max_eval_loops=3, context_limit=6000
- `swarm_max`: analysis_workers=3, collection_workers=3, evaluation_workers=3, max_eval_loops=3, context_limit=9000

### 1.4 Package Version Update (v1.3)

`__version__` 更新为 "1.3.0"，标志着：
- Bundle-based 自治系统成为主架构
- Self-organizing routing 替代固定路由模式
- Loop Profile 动态选择完成

---

## 二、文件变更对照

| 文件 | 状态 | 说明 |
|------|------|------|
| `swarmbot/loops/overthinking.py` | DELETED | 替换为 Bundle-based MemoryFoundationBundle |
| `swarmbot/loops/overaction.py` | DELETED | 替换为 Bundle-based BootOptimizerBundle |
| `swarmbot/__init__.py` | UNCHANGED | SwarmManager 从未在 exports 中 |

---

## 三、配置变更

### 3.1 新增配置节

```json
{
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3,
    "default_locked_bundles": [
      "core.memory_foundation",
      "core.boot_optimizer",
      "core.system_hygiene",
      "core.bundle_governor"
    ]
  }
}
```

### 3.2 移除配置项

- `overthinking.interval_minutes` - 已废弃
- `overaction.interval_minutes` - 已废弃

---

## 四、CLI 变更（v1.3）

### 4.1 `swarmbot run` 命令

**v1.1**: 强制使用 `engineering_complex` route_mode
**v1.2/v1.3**: 自适应路由模式，通过 LLM 投票决定

```python
# v1.1 - hardcoded (已废弃)
inference_loop.route_mode = "engineering_complex"

# v1.2/v1.3 - self-organizing routing via multiple planner voting
# Route mode determined by: simple_direct_master | reasoning_swarm | engineering_complex
```

### 4.2 `swarmbot gateway` 命令

启动时自动初始化并启动 AutonomousEngine（若 enabled=true）

---

## 五、测试脚本更新

| 脚本 | 测试目标 |
|------|----------|
| `scripts/eval_inference_benchmark.py` | 推理能力回归（新增 routing 精度） |
| `scripts/eval_analysis_routing.py` | 路由准确率验证 |
| `scripts/eval_subtask_async.py` | 异步子任务不阻塞 |
| `scripts/eval_musique.py` | MUSIQUE 多跳 QA |
| `scripts/eval_conflict_stability.py` | Bundle 冲突稳定性 |
| `scripts/eval_loop_profiles.py` | Loop Profile 自动选择 |

---

## 六、API 变更

### 6.1 InferenceLoop

新增方法：
- `_decide_route_mode()` - 多 Planner 投票决定路由模式
- `_select_profile()` - 根据问题复杂度选择 Loop Profile

### 6.2 AutonomousEngine

新增 Bundle 类型：
- `_MemoryFoundationBundle`: 记忆压缩（替换 OverthinkingLoop）
- `_BootOptimizerBundle`: 启动优化（替换 OveractionLoop）

---

## 七、版本对照

| 特性 | v1.0 | v1.1 | v1.2 | v1.3 |
|------|------|------|------|------|
| 双线自治模型 | ✅ | ✅ | ✅ | ✅ |
| framework_doc 严格化 | ❌ | ✅ | ✅ | ✅ |
| Skill/Tool 解耦 | ❌ | ✅ | ✅ | ✅ |
| Supervisor 幂等控制 | ❌ | ✅ | ✅ | ✅ |
| Whiteboard 平衡模型 | 基础版 | ✅ | ✅ | ✅ |
| 提前收敛评分 | ❌ | ✅ | ✅ | ✅ |
| Bundle-based 自治 | ❌ | ❌ | ✅ | ✅ |
| Self-organizing routing | ❌ | ❌ | ✅ | ✅ |

---

## 八、v1.3 更新说明

`__version__` 已更新为 "1.3.0"，主要变更：
1. Bundle-based 自治系统成为主架构（OverthinkingLoop/OveractionLoop 移除）
2. Self-organizing routing 替代固定路由模式
3. Loop Profile 动态选择完成

---

## 十、迁移指南

### 8.1 移除旧 Loop 文件

```bash
# v1.2 后不再需要这些文件
rm ~/.swarmbot/workspace/overthinking_state.json
rm ~/.swarmbot/workspace/overaction_schedule_state.json
```

### 8.2 更新配置

```json
{
  // v1.1 配置（废弃）
  "overthinking": { "interval_minutes": 30 },
  "overaction": { "interval_minutes": 60 },

  // v1.2/v1.3 配置（使用）
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "default_locked_bundles": ["core.memory_foundation", ...]
  }
}
```

---

## 十一、v1.3 结论

v1.3 完成从"固定 Loop 架构"到"自适应自治系统"的升级：
**Bundle-based 自治引擎 + Self-organizing routing + Dynamic loop profiles** 已进入主执行链。

后续 v1.4 建议重点：
- 并行化 Tool Gate 投票
- 强化 Skill 远程检索策略
- 完善 acceptance_criteria 评估可解释性
