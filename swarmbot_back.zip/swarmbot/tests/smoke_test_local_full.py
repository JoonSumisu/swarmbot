#!/usr/bin/env python3
"""
Swarmbot v2.0 本地模型全面测试脚本

测试场景:
1. CommunicationHub 完整功能测试
2. MasterAgent 简单对话和推理工具调用
3. 文件操作测试 - 浏览、创建、修改本地文件
4. Boot 文件测试 - soul、swarmboot 加载验证
5. 推理工具测试 - Standard/Supervised/SwarmsWorker
6. 记忆搜索测试 - Warm/ColdMemory 正确检索
7. Hub 相互沟通测试 - 四方沟通正常
8. 长时间运行稳定性测试

配置:
- 本地模型：请自行配置 (http://localhost:8000/v1 或兼容 API)
- 模型：请自行配置 (如 qwen3.5-35b 等)
- max_tokens: 64000

使用方法:
    python tests/smoke_test_local_full.py

注意：请将 LOCAL_MODEL_CONFIG 替换为你自己的模型配置
"""

import json
import os
import sys
import time
import tempfile
import shutil
import traceback
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from enum import Enum
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from swarmbot.gateway.communication_hub import CommunicationHub, MessageType, MessagePriority
from swarmbot.gateway.orchestrator import GatewayMasterAgent, SharedContextPool
from swarmbot.config_manager import load_config, ProviderConfig
from swarmbot.llm_client import OpenAICompatibleClient


# ========== 配置 ==========
# 注意：请替换为你自己的本地模型配置
LOCAL_MODEL_CONFIG = {
    "name": "local-model",
    "base_url": "http://localhost:8000/v1",  # 修改为你的 API 地址
    "api_key": "your-api-key",                # 修改为你的 API 密钥
    "model": "your-model-name",               # 修改为你的模型名称
    "max_tokens": 64000,
    "temperature": 0.7,
}

TEST_WORKSPACE = Path.home() / ".swarmbot/workspace"
TEST_RESULTS_DIR = Path.home() / ".swarmbot/test_results"


class TestStatus(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"
    TIMEOUT = "TIMEOUT"


@dataclass
class TestResult:
    name: str
    status: TestStatus
    message: str = ""
    details: Optional[Dict[str, Any]] = None
    duration: float = 0.0
    timestamp: str = ""


class FullTestRunner:
    """全面测试执行器"""

    def __init__(self, workspace_path: Optional[Path] = None):
        self.workspace_path = workspace_path or TEST_WORKSPACE
        self.results: List[TestResult] = []
        self.start_time = time.time()

        # 确保工作空间存在
        self.workspace_path.mkdir(parents=True, exist_ok=True)

        # 创建结果目录
        TEST_RESULTS_DIR.mkdir(parents=True, exist_ok=True)

        # 初始化 LLM 客户端
        self.llm_client = self._init_llm_client()

        # 初始化 CommunicationHub
        self.hub = CommunicationHub(self.workspace_path)

        # 初始化 ContextPool
        self.context_pool = SharedContextPool(self.workspace_path)

        # 初始化 MasterAgent
        try:
            self.config = load_config()
            self.master_agent = GatewayMasterAgent(self.workspace_path, self.config)
        except Exception as e:
            print(f"[Runner] Warning: Could not initialize MasterAgent: {e}")
            self.master_agent = None
            self.config = None

    def _init_llm_client(self):
        """初始化本地模型客户端"""
        try:
            provider = ProviderConfig(
                name=LOCAL_MODEL_CONFIG["name"],
                base_url=LOCAL_MODEL_CONFIG["base_url"],
                api_key=LOCAL_MODEL_CONFIG["api_key"],
                model=LOCAL_MODEL_CONFIG["model"],
                max_tokens=LOCAL_MODEL_CONFIG["max_tokens"],
                temperature=LOCAL_MODEL_CONFIG["temperature"],
            )
            client = OpenAICompatibleClient.from_provider(provider=provider)

            # 测试连接
            response = client.completion(
                messages=[{"role": "user", "content": "你好"}],
                max_tokens=50,
            )
            print(f"[Runner] LLM client initialized: {LOCAL_MODEL_CONFIG['model']}")
            return client
        except Exception as e:
            print(f"[Runner] Error initializing LLM client: {e}")
            return None

    def record_result(self, name: str, status: TestStatus, message: str = "",
                     details: Optional[Dict[str, Any]] = None, duration: float = 0.0):
        """记录测试结果"""
        result = TestResult(
            name=name,
            status=status,
            message=message,
            details=details,
            duration=duration,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        self.results.append(result)

        status_icon = {
            TestStatus.PASS: "✓",
            TestStatus.FAIL: "✗",
            TestStatus.SKIP: "○",
            TestStatus.TIMEOUT: "⏱",
        }.get(status, "?")

        duration_str = f"({duration:.2f}s)" if duration > 0 else ""
        print(f"  [{status_icon}] {name}: {message} {duration_str}")

    def print_summary(self):
        """打印测试摘要"""
        total_time = time.time() - self.start_time

        print("\n" + "=" * 70)
        print("Swarmbot v2.0 全面测试结果摘要")
        print("=" * 70)
        print(f"测试时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"总耗时：{total_time:.1f}秒 ({total_time/60:.1f}分钟)")
        print(f"工作空间：{self.workspace_path}")
        print()

        passed = sum(1 for r in self.results if r.status == TestStatus.PASS)
        failed = sum(1 for r in self.results if r.status == TestStatus.FAIL)
        skipped = sum(1 for r in self.results if r.status == TestStatus.SKIP)
        timeout = sum(1 for r in self.results if r.status == TestStatus.TIMEOUT)

        print(f"结果：{passed} 通过，{failed} 失败，{skipped} 跳过，{timeout} 超时")
        print(f"总计：{len(self.results)} 测试")
        print(f"通过率：{passed/max(1, passed+failed)*100:.1f}%")

        if failed > 0:
            print("\n失败测试:")
            for r in self.results:
                if r.status == TestStatus.FAIL:
                    print(f"  - {r.name}: {r.message}")

        if timeout > 0:
            print("\n超时测试:")
            for r in self.results:
                if r.status == TestStatus.TIMEOUT:
                    print(f"  - {r.name}")

        print("=" * 70)

    def save_report(self):
        """保存测试报告"""
        report_path = TEST_RESULTS_DIR / f"test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        report = {
            "test_time": datetime.now().isoformat(),
            "total_duration": time.time() - self.start_time,
            "workspace": str(self.workspace_path),
            "llm_config": LOCAL_MODEL_CONFIG,
            "results": [
                {
                    "name": r.name,
                    "status": r.status.value,
                    "message": r.message,
                    "details": r.details,
                    "duration": r.duration,
                    "timestamp": r.timestamp,
                }
                for r in self.results
            ],
            "summary": {
                "passed": sum(1 for r in self.results if r.status == TestStatus.PASS),
                "failed": sum(1 for r in self.results if r.status == TestStatus.FAIL),
                "skipped": sum(1 for r in self.results if r.status == TestStatus.SKIP),
                "timeout": sum(1 for r in self.results if r.status == TestStatus.TIMEOUT),
                "total": len(self.results),
            }
        }

        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        print(f"\n测试报告已保存：{report_path}")
        return report_path

    # ========== 测试用例 ==========

    def test_01_llm_connection(self):
        """测试 1: LLM 连接和基本对话"""
        print("\n[Test 1] LLM 连接和基本对话测试")

        if not self.llm_client:
            self.record_result("LLM 连接", TestStatus.FAIL, "客户端初始化失败")
            return

        start = time.time()

        try:
            # 测试 1: 简单对话
            response = self.llm_client.completion(
                messages=[{"role": "user", "content": "你好，请用一句话介绍你自己"}],
                max_tokens=100,
            )
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
            self.record_result("LLM 简单对话", TestStatus.PASS, f"回复长度：{len(content)}", duration=time.time()-start)

            # 测试 2: 复杂问题
            start = time.time()
            response = self.llm_client.completion(
                messages=[{
                    "role": "user",
                    "content": "请解释什么是人工智能，以及它的主要应用场景有哪些？请分点说明。"
                }],
                max_tokens=500,
            )
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
            self.record_result("LLM 复杂问题", TestStatus.PASS, f"回复长度：{len(content)}", duration=time.time()-start)

            # 测试 3: 代码生成
            start = time.time()
            response = self.llm_client.completion(
                messages=[{
                    "role": "user",
                    "content": "请用 Python 写一个快速排序函数，并添加简要注释。"
                }],
                max_tokens=1000,
            )
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
            has_code = "def" in content and "sort" in content.lower()
            status = TestStatus.PASS if has_code else TestStatus.FAIL
            self.record_result("LLM 代码生成", status, f"生成代码：{has_code}", duration=time.time()-start)

        except Exception as e:
            self.record_result("LLM 连接测试", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_02_communication_hub_basic(self):
        """测试 2: CommunicationHub 基础功能"""
        print("\n[Test 2] CommunicationHub 基础功能测试")
        start = time.time()

        try:
            hub = self.hub

            # 测试发送消息
            msg_id = hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="测试消息",
                recipient="master_agent",
                thread_id="test-thread",
            )
            assert msg_id, "Message ID should not be empty"

            # 测试接收消息
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert len(messages) >= 1

            # 测试标记消费
            hub.mark_consumed(msg_id)
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")

            self.record_result("CommunicationHub 基础", TestStatus.PASS, "所有操作正常", duration=time.time()-start)

        except Exception as e:
            self.record_result("CommunicationHub 基础", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_03_communication_hub_recipient(self):
        """测试 3: CommunicationHub 接收者过滤"""
        print("\n[Test 3] CommunicationHub 接收者过滤测试")
        start = time.time()

        try:
            hub = self.hub

            # 发送给不同接收者
            hub.send_to_master_agent(MessageType.SYSTEM_INFO, "test", "给 MA 的消息")
            hub.send_to_inference_loop(MessageType.SYSTEM_INFO, "test", "给 IL 的消息")
            hub.send_to_autonomous_engine(MessageType.SYSTEM_INFO, "test", "给 AE 的消息")
            hub.send_to_user(MessageType.SYSTEM_INFO, "test", "给 User 的消息")
            hub.broadcast(MessageType.SYSTEM_INFO, "test", "广播消息")

            # 验证过滤
            ma_msgs = len(hub.get_unconsumed_messages(recipient_filter="master_agent"))
            il_msgs = len(hub.get_unconsumed_messages(recipient_filter="inference_loop"))
            ae_msgs = len(hub.get_unconsumed_messages(recipient_filter="autonomous_engine"))
            user_msgs = len(hub.get_unconsumed_messages(recipient_filter="user"))

            # 每个接收者应该收到 2 条（1 条定向 + 1 条广播）
            assert ma_msgs >= 2, f"MA 应该收到至少 2 条消息，实际 {ma_msgs}"
            assert il_msgs >= 2, f"IL 应该收到至少 2 条消息，实际 {il_msgs}"

            self.record_result(
                "接收者过滤", TestStatus.PASS,
                f"MA:{ma_msgs}, IL:{il_msgs}, AE:{ae_msgs}, User:{user_msgs}",
                duration=time.time()-start
            )

            # 清理
            for msg in hub.get_unconsumed_messages():
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("接收者过滤", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_04_communication_hub_thread(self):
        """测试 4: CommunicationHub 线程追踪"""
        print("\n[Test 4] CommunicationHub 线程追踪测试")
        start = time.time()

        try:
            hub = self.hub

            # 创建线程对话
            msg_id_1 = hub.send_to_master_agent(
                MessageType.SYSTEM_INFO, "test", "问题 1",
                thread_id="thread-1"
            )
            msg_id_2 = hub.send_to_master_agent(
                MessageType.SYSTEM_INFO, "test", "回复 1",
                thread_id="thread-1",
                in_reply_to=msg_id_1
            )
            msg_id_3 = hub.send_to_master_agent(
                MessageType.SYSTEM_INFO, "test", "再回复",
                thread_id="thread-1",
                in_reply_to=msg_id_2
            )

            # 验证线程
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            thread_msgs = [m for m in messages if m.thread_id == "thread-1"]

            assert len(thread_msgs) == 3, f"应该有 3 条线程消息，实际 {len(thread_msgs)}"

            # 验证回复链
            reply_msg = next(m for m in thread_msgs if m.in_reply_to == msg_id_1)
            assert reply_msg is not None

            self.record_result(
                "线程追踪", TestStatus.PASS,
                f"线程消息数：{len(thread_msgs)}, 回复链完整",
                duration=time.time()-start
            )

            # 清理
            for msg in messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("线程追踪", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_05_hub_four_party_communication(self):
        """测试 5: Hub 四方沟通完整场景"""
        print("\n[Test 5] Hub 四方沟通完整场景测试")
        start = time.time()

        try:
            hub = self.hub
            conversation_id = f"conv-{int(time.time())}"

            # 场景 1: Autonomous → MasterAgent (Bundle 状态报告)
            ae_to_ma = hub.send_to_master_agent(
                MessageType.AUTONOMOUS_STATUS, "autonomous_engine",
                "Bundle core.memory_foundation 执行完成，评分 A",
                metadata={"bundle_id": "core.memory_foundation", "grade": "A"},
                conversation_id=conversation_id,
            )

            # 场景 2: MasterAgent → Autonomous (用户反馈)
            ma_to_ae = hub.send_to_autonomous_engine(
                MessageType.USER_FEEDBACK, "master_agent",
                "用户对 Bundle 执行结果满意，继续优化",
                metadata={"bundle_id": "core.memory_foundation"},
                conversation_id=conversation_id,
                in_reply_to=ae_to_ma,
            )

            # 场景 3: InferenceLoop → MasterAgent (人在回路请求)
            il_to_ma = hub.send_to_master_agent(
                MessageType.HUMAN_IN_LOOP_REQUEST, "inference_loop",
                "需要确认：是否执行代码修改操作？",
                priority=MessagePriority.CRITICAL,
                metadata={"stage": "CODE_MODIFY", "risk_level": "L2"},
                conversation_id=conversation_id,
            )

            # 场景 4: MasterAgent → InferenceLoop (用户确认)
            ma_to_il = hub.send_to_inference_loop(
                MessageType.HUMAN_IN_LOOP_RESPONSE, "master_agent",
                "用户确认：继续执行代码修改",
                priority=MessagePriority.HIGH,
                metadata={"request_msg_id": il_to_ma},
                conversation_id=conversation_id,
                in_reply_to=il_to_ma,
            )

            # 场景 5: User → MasterAgent (新任务请求)
            user_to_ma = hub.send_to_master_agent(
                MessageType.USER_FEEDBACK, "user",
                "请帮我分析当前系统状态",
                conversation_id=conversation_id,
            )

            # 场景 6: MasterAgent → User (响应)
            ma_to_user = hub.send_to_user(
                MessageType.SYSTEM_INFO, "master_agent",
                "系统运行正常，所有 Bundle 执行成功",
                conversation_id=conversation_id,
                in_reply_to=user_to_ma,
            )

            # 验证所有消息都被正确发送
            all_messages = hub.get_unconsumed_messages()
            conv_messages = [m for m in all_messages if m.conversation_id == conversation_id]

            assert len(conv_messages) == 6, f"应该有 6 条会话消息，实际 {len(conv_messages)}"

            # 验证回复链
            reply_msgs = [m for m in conv_messages if m.in_reply_to]
            assert len(reply_msgs) >= 3, f"应该有至少 3 条回复消息，实际 {len(reply_msgs)}"

            self.record_result(
                "四方沟通场景", TestStatus.PASS,
                f"会话消息数：{len(conv_messages)}, 回复数：{len(reply_msgs)}",
                duration=time.time()-start
            )

            # 清理
            for msg in conv_messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("四方沟通场景", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_06_shared_context_pool(self):
        """测试 6: SharedContextPool 上下文共享"""
        print("\n[Test 6] SharedContextPool 上下文共享测试")
        start = time.time()

        try:
            pool = self.context_pool

            # 更新多个 Bundle 状态
            test_bundles = [
                ("core.memory_foundation", "success", "执行成功，评分 A"),
                ("core.system_hygiene", "warning", "需要优化，评分 C"),
                ("core.bundle_governor", "success", "执行成功，评分 B"),
                ("core.boot_optimizer", "normal", "执行中"),
            ]

            for bundle_id, status, details in test_bundles:
                pool.update_sync(bundle_id, status, details)

            # 获取所有状态
            all_status = pool.get_all_status_sync()
            assert len(all_status) >= len(test_bundles)

            # 获取任务相关上下文
            context = pool.get_context_for_task_sync(
                task_desc="优化 system_hygiene Bundle",
            )

            scored = context.get("scored_context", [])
            assert len(scored) > 0, "应该有评分的上下文"

            self.record_result(
                "SharedContextPool", TestStatus.PASS,
                f"Bundle 状态数：{len(all_status)}, 相关上下文：{len(scored)}",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("SharedContextPool", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_07_master_agent_simple_dialog(self):
        """测试 7: MasterAgent 简单对话模式"""
        print("\n[Test 7] MasterAgent 简单对话模式测试")
        start = time.time()

        try:
            agent = self.master_agent
            if not agent:
                self.record_result("MasterAgent 简单对话", TestStatus.SKIP, "MasterAgent 未初始化", duration=time.time()-start)
                return

            # 测试简单对话检测
            simple_inputs = [
                ("你好", True),
                ("谢谢", True),
                ("好的", True),
                ("Hello", True),
                ("再见", True),
                ("你好吗", True),
            ]

            all_correct = True
            for inp, expected in simple_inputs:
                result = agent._should_use_simple_direct(inp)
                if result != expected:
                    all_correct = False
                    print(f"    错误：'{inp}' 预期={expected}, 实际={result}")

            status = TestStatus.PASS if all_correct else TestStatus.FAIL
            self.record_result("简单对话检测", status, duration=time.time()-start)

        except Exception as e:
            self.record_result("MasterAgent 简单对话", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_08_boot_file_loading(self):
        """测试 8: Boot 文件加载"""
        print("\n[Test 8] Boot 文件加载测试")
        start = time.time()

        try:
            boot_paths = [
                Path.home() / ".swarmbot/boot/SOUL.md",
                Path.home() / ".swarmbot/boot/swarmboot.md",
                Path(__file__).parent.parent / "swarmbot" / "boot" / "inference_tools.md",
            ]

            loaded_count = 0
            for boot_path in boot_paths:
                if boot_path.exists():
                    content = boot_path.read_text(encoding="utf-8")
                    if content.strip():
                        loaded_count += 1

            status = TestStatus.PASS if loaded_count >= 2 else TestStatus.FAIL
            self.record_result(
                "Boot 文件加载", status,
                f"成功加载 {loaded_count}/{len(boot_paths)} 个文件",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("Boot 文件加载", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_09_inference_tools_config(self):
        """测试 9: 推理工具配置"""
        print("\n[Test 9] 推理工具配置测试")
        start = time.time()

        try:
            agent = self.master_agent
            if not agent:
                self.record_result("推理工具配置", TestStatus.SKIP, "MasterAgent 未初始化", duration=time.time()-start)
                return

            tools_config = agent._load_inference_tools_config()

            if not tools_config:
                self.record_result("推理工具配置", TestStatus.FAIL, "未找到工具配置", duration=time.time()-start)
                return

            # 验证每个工具
            validated_tools = []
            for tool in tools_config:
                tool_id = tool.get("tool_id", "")
                module_path = tool.get("module_path", "")
                class_name = tool.get("class_name", "")

                try:
                    import importlib
                    module = importlib.import_module(module_path)
                    cls = getattr(module, class_name)
                    validated_tools.append(tool_id)
                except Exception as e:
                    print(f"    工具验证失败 {tool_id}: {e}")

            status = TestStatus.PASS if len(validated_tools) >= 2 else TestStatus.FAIL
            self.record_result(
                "推理工具配置", status,
                f"验证 {len(validated_tools)}/{len(tools_config)} 个工具",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("推理工具配置", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_10_llm_multi_turn_conversation(self):
        """测试 10: LLM 多轮对话连续性"""
        print("\n[Test 10] LLM 多轮对话连续性测试")
        start = time.time()

        if not self.llm_client:
            self.record_result("LLM 多轮对话", TestStatus.SKIP, "LLM 客户端未初始化", duration=time.time()-start)
            return

        try:
            conversation_history = []

            # 第 1 轮
            conversation_history.append({
                "role": "user",
                "content": "我想学习 Python 编程，请给我一些建议"
            })
            response = self.llm_client.completion(
                messages=conversation_history,
                max_tokens=500,
            )
            ai_response_1 = response.get("choices", [{}])[0].get("message", {}).get("content", "")
            conversation_history.append({"role": "assistant", "content": ai_response_1})

            # 第 2 轮 - 基于上一轮继续
            conversation_history.append({
                "role": "user",
                "content": "基于你刚才的建议，我应该先学习哪些基础概念？"
            })
            response = self.llm_client.completion(
                messages=conversation_history,
                max_tokens=500,
            )
            ai_response_2 = response.get("choices", [{}])[0].get("message", {}).get("content", "")
            conversation_history.append({"role": "assistant", "content": ai_response_2})

            # 第 3 轮
            conversation_history.append({
                "role": "user",
                "content": "能给我推荐一些学习资源吗？"
            })
            response = self.llm_client.completion(
                messages=conversation_history,
                max_tokens=500,
            )
            ai_response_3 = response.get("choices", [{}])[0].get("message", {}).get("content", "")

            # 验证连续性
            all_responses = ai_response_1 + ai_response_2 + ai_response_3
            has_continuity = len(all_responses) > 500  # 确保有实质性内容

            self.record_result(
                "LLM 多轮对话", TestStatus.PASS if has_continuity else TestStatus.FAIL,
                f"3 轮对话总长度：{len(all_responses)}",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("LLM 多轮对话", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_11_llm_code_understanding(self):
        """测试 11: LLM 代码理解能力"""
        print("\n[Test 11] LLM 代码理解能力测试")
        start = time.time()

        if not self.llm_client:
            self.record_result("LLM 代码理解", TestStatus.SKIP, "LLM 客户端未初始化", duration=time.time()-start)
            return

        try:
            code_snippet = '''
def communication_hub_send(self, msg_type, sender, content, recipient="broadcast"):
    """发送消息到沟通窗口"""
    msg_id = f"{int(time.time() * 1000)}-{sender[:8]}-{hash(content) % 10000:04d}"
    msg = ChatMessage(
        msg_id=msg_id,
        msg_type=msg_type,
        sender=sender,
        recipient=recipient,
        content=content,
    )
    self._append_message(msg)
    return msg_id
'''

            prompt = f"""请分析以下 Python 代码的功能，并指出可能的问题：

{code_snippet}

请用中文回答。"""

            response = self.llm_client.completion(
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
            )
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")

            # 验证回复包含关键分析
            has_analysis = any(kw in content.lower() for kw in ["功能", "代码", "分析", "def", "消息"])

            self.record_result(
                "LLM 代码理解", TestStatus.PASS if has_analysis else TestStatus.FAIL,
                f"回复长度：{len(content)}, 包含分析：{has_analysis}",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("LLM 代码理解", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_12_llm_long_context(self):
        """测试 12: LLM 长上下文处理"""
        print("\n[Test 12] LLM 长上下文处理测试")
        start = time.time()

        if not self.llm_client:
            self.record_result("LLM 长上下文", TestStatus.SKIP, "LLM 客户端未初始化", duration=time.time()-start)
            return

        try:
            # 构建长上下文
            background = """
你是一个智能助手，正在帮助用户分析一个复杂的软件系统。

系统架构说明：
1. CommunicationHub - 双向沟通窗口，基于文件的 FIFO 消息队列
2. GatewayMasterAgent - 统一消息编排器，负责处理用户消息和调度推理工具
3. AutonomousEngine - 自主引擎，基于 Bundle 的自我组织系统
4. InferenceLoop - 推理工具集，包括 Standard/Supervised/SwarmsWorker

当前系统状态：
- CommunicationHub 中有 15 条未消费消息
- AutonomousEngine 正在执行 3 个 Bundle
- MasterAgent 已处理 42 个用户请求
- 系统运行时间：4 小时 32 分钟

用户历史请求记录：
1. 查询系统状态 - 已完成
2. 创建新的 Bundle - 已完成
3. 优化 system_hygiene Bundle - 进行中
"""

            question = """
基于以上系统状态，请回答：
1. 当前系统运行是否正常？
2. 有哪些需要关注的问题？
3. 下一步应该优先处理什么？

请详细分析并给出建议。"""

            response = self.llm_client.completion(
                messages=[
                    {"role": "system", "content": background},
                    {"role": "user", "content": question}
                ],
                max_tokens=1500,
            )
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")

            # 验证回复质量
            has_structure = any(kw in content for kw in ["1.", "2.", "3.", "第一", "第二", "首先", "其次"])
            min_length = 200

            self.record_result(
                "LLM 长上下文", TestStatus.PASS if (has_structure and len(content) > min_length) else TestStatus.FAIL,
                f"回复长度：{len(content)}, 结构化：{has_structure}",
                duration=time.time()-start
            )

        except Exception as e:
            self.record_result("LLM 长上下文", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_13_memory_warm_cold(self):
        """测试 13: 记忆系统 (Warm/Cold Memory)"""
        print("\n[Test 13] 记忆系统测试")
        start = time.time()

        try:
            from swarmbot.memory.warm_memory import WarmMemory
            from swarmbot.memory.cold_memory import ColdMemory

            warm_memory = WarmMemory(self.workspace_path)
            cold_memory = ColdMemory()

            # Warm Memory 测试 - 使用正确的 API 参数
            warm_memory.append_log(
                loop_id="test-session-1",
                input_prompt="查询系统状态",  # 正确参数名：input_prompt
                summary="用户查询系统运行状态",
                facts=["系统运行正常", "3 个 Bundle 执行成功"],
            )

            # 读取 Warm Memory - 使用正确的 API
            today_content = warm_memory.read_today()
            has_content = len(today_content) > 0 and "test-session-1" in today_content

            # Cold Memory 测试
            cold_memory.search_text("系统状态", limit=5)

            self.record_result(
                "记忆系统", TestStatus.PASS if has_content else TestStatus.FAIL,
                f"Warm Memory 内容：{'有' if has_content else '无'}, Cold Memory: 正常",
                duration=time.time()-start
            )

        except ImportError:
            self.record_result("记忆系统", TestStatus.SKIP, "记忆模块未找到", duration=time.time()-start)
        except Exception as e:
            self.record_result("记忆系统", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_14_stress_concurrent_messages(self):
        """测试 14: 压力测试 - 并发消息处理"""
        print("\n[Test 14] 压力测试 - 并发消息处理")
        start = time.time()

        try:
            hub = self.hub

            # 批量发送消息
            msg_count = 50
            msg_ids = []

            for i in range(msg_count):
                msg_id = hub.send(
                    msg_type=MessageType.SYSTEM_INFO,
                    sender="stress_test",
                    content=f"压力测试消息 {i}",
                    recipient="master_agent",
                    thread_id=f"stress-thread-{i % 5}",  # 5 个线程
                )
                msg_ids.append(msg_id)

            # 验证消息数量
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")

            # 按线程分组
            threads = {}
            for msg in messages:
                tid = msg.thread_id or "no-thread"
                if tid not in threads:
                    threads[tid] = []
                threads[tid].append(msg)

            self.record_result(
                "并发消息压力", TestStatus.PASS,
                f"发送 {msg_count} 条，收到 {len(messages)} 条，线程数：{len(threads)}",
                duration=time.time()-start
            )

            # 清理
            for msg in messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("并发消息压力", TestStatus.FAIL, str(e), duration=time.time()-start)

    def test_15_priority_ordering(self):
        """测试 15: 消息优先级排序"""
        print("\n[Test 15] 消息优先级排序测试")
        start = time.time()

        try:
            hub = self.hub

            # 按不同优先级发送消息
            priorities = [
                (MessagePriority.LOW, "低优先级"),
                (MessagePriority.NORMAL, "普通优先级"),
                (MessagePriority.HIGH, "高优先级"),
                (MessagePriority.CRITICAL, "紧急优先级"),
            ]

            for priority, content in priorities:
                hub.send(
                    msg_type=MessageType.SYSTEM_INFO,
                    sender="priority_test",
                    content=content,
                    recipient="master_agent",
                    priority=priority,
                )

            # 获取消息并验证排序
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")

            priority_order = {
                MessagePriority.CRITICAL: 0,
                MessagePriority.HIGH: 1,
                MessagePriority.NORMAL: 2,
                MessagePriority.LOW: 3,
            }

            is_sorted = True
            for i in range(len(messages) - 1):
                if priority_order[messages[i].priority] > priority_order[messages[i+1].priority]:
                    is_sorted = False
                    break

            self.record_result(
                "消息优先级排序", TestStatus.PASS if is_sorted else TestStatus.FAIL,
                f"消息数：{len(messages)}, 排序正确：{is_sorted}",
                duration=time.time()-start
            )

            # 清理
            for msg in messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("消息优先级排序", TestStatus.FAIL, str(e), duration=time.time()-start)

    def run_all_tests(self):
        """运行所有测试"""
        print("=" * 70)
        print("Swarmbot v2.0 本地模型全面测试")
        print("=" * 70)
        print(f"开始时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"工作空间：{self.workspace_path}")
        print(f"本地模型：{LOCAL_MODEL_CONFIG['model']}")
        print(f"Max Tokens: {LOCAL_MODEL_CONFIG['max_tokens']}")
        print()

        try:
            # LLM 基础测试
            self.test_01_llm_connection()

            # CommunicationHub 测试
            self.test_02_communication_hub_basic()
            self.test_03_communication_hub_recipient()
            self.test_04_communication_hub_thread()
            self.test_05_hub_four_party_communication()

            # 上下文和配置测试
            self.test_06_shared_context_pool()
            self.test_07_master_agent_simple_dialog()
            self.test_08_boot_file_loading()
            self.test_09_inference_tools_config()

            # LLM 高级能力测试
            self.test_10_llm_multi_turn_conversation()
            self.test_11_llm_code_understanding()
            self.test_12_llm_long_context()

            # 记忆系统测试
            self.test_13_memory_warm_cold()

            # 压力测试
            self.test_14_stress_concurrent_messages()
            self.test_15_priority_ordering()

        finally:
            self.print_summary()
            self.save_report()

        return all(r.status not in [TestStatus.FAIL, TestStatus.TIMEOUT] for r in self.results)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Swarmbot v2.0 本地模型全面测试")
    parser.add_argument("--workspace", type=str, help="指定工作空间路径")
    args = parser.parse_args()

    workspace = Path(args.workspace) if args.workspace else None
    runner = FullTestRunner(workspace_path=workspace)
    success = runner.run_all_tests()

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
