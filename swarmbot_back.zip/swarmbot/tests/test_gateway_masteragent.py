#!/usr/bin/env python3
"""
Test script for Gateway-MasterAgent integration (v2.0)

Tests:
1. PriorityMessageQueue - Message priority handling
2. OutputBuffer - Message buffering and flushing
3. SharedContextPool - Context storage and retrieval
4. SkillPool - Skill generation and registry
5. GatewayMasterAgent - Integration test
"""

import asyncio
import sys
import time
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from swarmbot.gateway.orchestrator import (
    Priority, PriorityMessageQueue, OutputBuffer,
    SharedContextPool, GatewayMasterAgent
)
from swarmbot.skill_pool import SkillPool, Skill, SkillRegistry


def test_priority_queue():
    """Test PriorityMessageQueue"""
    print("\n=== Test PriorityMessageQueue ===")

    async def run_test():
        queue = PriorityMessageQueue()

        # Add messages with different priorities
        await queue.put(PrioritizedMessage(
            priority=Priority.P2_BUNDLE_REPORT,
            timestamp=1,
            content="Bundle report",
            msg_type="bundle"
        ))
        await queue.put(PrioritizedMessage(
            priority=Priority.P0_USER_RESPONSE,
            timestamp=2,
            content="User response",
            msg_type="user"
        ))
        await queue.put(PrioritizedMessage(
            priority=Priority.P1_HUMAN_REQUEST,
            timestamp=3,
            content="Human request",
            msg_type="human"
        ))

        # Should get P0 first
        msg = await queue.get()
        assert msg.priority == Priority.P0_USER_RESPONSE, f"Expected P0, got {msg.priority}"
        print("✓ P0 message retrieved first")

        msg = await queue.get()
        assert msg.priority == Priority.P1_HUMAN_REQUEST, f"Expected P1, got {msg.priority}"
        print("✓ P1 message retrieved second")

        msg = await queue.get()
        assert msg.priority == Priority.P2_BUNDLE_REPORT, f"Expected P2, got {msg.priority}"
        print("✓ P2 message retrieved third")

    from swarmbot.gateway.orchestrator import PrioritizedMessage
    asyncio.run(run_test())
    print("✓ PriorityMessageQueue test passed\n")


def test_output_buffer():
    """Test OutputBuffer"""
    print("\n=== Test OutputBuffer ===")

    async def run_test():
        buffer = OutputBuffer(max_wait_seconds=0.1)

        # Buffer some messages
        await buffer.buffer(PrioritizedMessage(
            priority=Priority.P2_BUNDLE_REPORT,
            timestamp=int(time.time() * 1000),
            content="Message 1",
            msg_type="bundle"
        ))
        await buffer.buffer(PrioritizedMessage(
            priority=Priority.P2_BUNDLE_REPORT,
            timestamp=int(time.time() * 1000),
            content="Message 2",
            msg_type="bundle"
        ))

        # Should not flush immediately (within max_wait)
        should_flush = await buffer.should_flush()
        print(f"✓ should_flush after buffering: {should_flush}")

        # Wait for timeout
        await asyncio.sleep(0.15)

        should_flush = await buffer.should_flush()
        assert should_flush, "Should flush after timeout"
        print("✓ should_flush after timeout: True")

        contents = await buffer.flush()
        assert len(contents) == 2, f"Expected 2 contents, got {len(contents)}"
        print(f"✓ Flushed {len(contents)} messages")

    from swarmbot.gateway.orchestrator import PrioritizedMessage
    asyncio.run(run_test())
    print("✓ OutputBuffer test passed\n")


def test_context_pool():
    """Test SharedContextPool"""
    print("\n=== Test SharedContextPool ===")

    async def run_test():
        # Use temp directory for testing
        test_dir = Path("/tmp/swarmbot_test_context")
        test_dir.mkdir(parents=True, exist_ok=True)

        pool = SharedContextPool(test_dir)

        # Update some bundle statuses
        await pool.update("core.system_hygiene", "warning", "Disk space low")
        await pool.update("core.memory_foundation", "success", "Memory compressed")
        await pool.update("core.boot_optimizer", "success", "Boot prompt optimized")

        # Get all status
        all_status = await pool.get_all_status()
        assert len(all_status) == 3, f"Expected 3 statuses, got {len(all_status)}"
        print(f"✓ Got {len(all_status)} bundle statuses")

        # Get single status
        status = await pool.get_status("core.system_hygiene")
        assert status is not None, "Status should not be None"
        assert status["status"] == "warning", f"Expected warning, got {status['status']}"
        print(f"✓ Got single status: {status['status']}")

        # Cleanup
        import shutil
        shutil.rmtree(test_dir)

    asyncio.run(run_test())
    print("✓ SharedContextPool test passed\n")


def test_skill_registry():
    """Test SkillRegistry"""
    print("\n=== Test SkillRegistry ===")

    registry = SkillRegistry()

    # Get all skills
    all_skills = registry.get_all_skills()
    print(f"✓ Built-in skills: {len(all_skills)}")

    # Get skills by category
    code_skills = registry.get_skills_by_category("code")
    print(f"✓ Code skills: {len(code_skills)}")

    # Register a new skill
    new_skill = Skill(
        skill_id="test_skill",
        name="Test Skill",
        description="A test skill",
        category="general",
        prompt_template="Do something",
        required_tools=["file_read"],
    )
    registry.register_skill(new_skill)
    print("✓ Registered new skill")

    # Verify registration
    all_skills = registry.get_all_skills()
    assert "test_skill" in all_skills, "Skill should be registered"
    print("✓ Verified skill registration")

    print("✓ SkillRegistry test passed\n")


def test_skill_generator():
    """Test SkillGenerator"""
    print("\n=== Test SkillGenerator ===")

    from swarmbot.skill_pool import SkillGenerator

    generator = SkillGenerator()

    # Test with high-quality execution
    execution_result = {
        "bundle_id": "core.system_hygiene",
        "execution_history": [
            {"step": "Check disk space", "result": "10% free"},
            {"step": "Check memory", "result": "50% free"},
            {"tool": "shell_exec", "command": "df -h"},
        ],
        "eval": {
            "grade": "A",
            "score": 0.95,
            "issues": [],
        },
    }

    skill = generator.generate_from_execution(execution_result)
    if skill:
        print(f"✓ Generated skill: {skill.skill_id}")
        print(f"  Name: {skill.name}")
        print(f"  Category: {skill.category}")
    else:
        print("  No skill generated (expected for simple execution)")

    # Test with low-quality execution (should not generate)
    execution_result_low = {
        "bundle_id": "core.test",
        "execution_history": [],
        "eval": {
            "grade": "D",
            "score": 0.2,
            "issues": ["Failed"],
        },
    }

    skill_low = generator.generate_from_execution(execution_result_low)
    assert skill_low is None, "Should not generate skill from low-quality execution"
    print("✓ Correctly skipped low-quality execution")

    print("✓ SkillGenerator test passed\n")


def test_gateway_master_agent():
    """Test GatewayMasterAgent integration"""
    print("\n=== Test GatewayMasterAgent ===")

    async def run_test():
        # Use temp directory for testing
        test_dir = Path("/tmp/swarmbot_test_gw")
        test_dir.mkdir(parents=True, exist_ok=True)

        agent = GatewayMasterAgent(test_dir)

        # Test context pool
        await agent.context_pool.update("core.test", "success", "Test OK")
        context = await agent.get_context_for_loop()
        assert "core.test" in context.get("all_status", {}), "Context should contain test bundle"
        print("✓ Context pool integration works")

        # Test message queue
        from swarmbot.gateway.orchestrator import PrioritizedMessage
        await agent.message_queue.put(PrioritizedMessage(
            priority=Priority.P0_USER_RESPONSE,
            timestamp=int(time.time() * 1000),
            content="Test message",
            msg_type="test"
        ))
        msg = await agent.message_queue.get()
        assert msg.content == "Test message", "Message should match"
        print("✓ Message queue works")

        # Test loop registration
        agent.register_loop("test_chat", {"loop_id": "test"})
        assert agent.has_active_loop("test_chat"), "Should have active loop"
        print("✓ Loop registration works")

        agent.unregister_loop("test_chat")
        assert not agent.has_active_loop("test_chat"), "Should not have active loop"
        print("✓ Loop unregistration works")

        # Cleanup
        import shutil
        shutil.rmtree(test_dir)

    asyncio.run(run_test())
    print("✓ GatewayMasterAgent test passed\n")


def main():
    """Run all tests"""
    print("=" * 60)
    print("Gateway-MasterAgent Integration Tests (v2.0)")
    print("=" * 60)

    try:
        test_priority_queue()
        test_output_buffer()
        test_context_pool()
        test_skill_registry()
        test_skill_generator()
        test_gateway_master_agent()

        print("=" * 60)
        print("All tests passed!")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
