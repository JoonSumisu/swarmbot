#!/usr/bin/env python3
"""
全面兼容性测试套件 (Gateway-MasterAgent v2.0)

测试范围:
1. InferenceLoop 基础功能回归测试
2. Gateway 服务器功能测试
3. Autonomous Engine 功能测试
4. 新旧组件集成测试
5. 消息优先级和缓冲测试
6. Skill 系统兼容性测试
"""

import asyncio
import json
import sys
import time
import os
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Set up test environment
os.environ.setdefault("SWARMBOT_LOOP_PROFILE", "lean")


class TestResult:
    """Test result tracker"""
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []

    def add_pass(self, name: str):
        self.passed += 1
        print(f"  ✓ {name}")

    def add_fail(self, name: str, reason: str):
        self.failed += 1
        self.errors.append((name, reason))
        print(f"  ✗ {name}: {reason}")

    def summary(self):
        total = self.passed + self.failed
        print(f"\n{'='*60}")
        print(f"测试结果：{self.passed}/{total} 通过")
        if self.failed > 0:
            print(f"失败测试:")
            for name, reason in self.errors:
                print(f"  - {name}: {reason}")
        print(f"{'='*60}")
        return self.failed == 0


result = TestResult()


# ============================================================
# Test 1: InferenceLoop 基础功能回归测试
# ============================================================

def test_inference_loop_import():
    """测试 InferenceLoop 可以正常导入和初始化"""
    print("\n=== Test 1: InferenceLoop 基础功能 ===")

    try:
        from swarmbot.loops.inference import InferenceLoop
        from swarmbot.config_manager import load_config

        config = load_config()
        workspace = Path.home() / ".swarmbot" / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)

        loop = InferenceLoop(config, str(workspace))
        result.add_pass("InferenceLoop 初始化成功")

        # 验证新增的组件已正确集成
        assert hasattr(loop, 'context_pool'), "Should have context_pool"
        assert hasattr(loop, 'skill_pool'), "Should have skill_pool"
        result.add_pass("context_pool 和 skill_pool 属性存在")

        # 验证 whiteboard 功能正常
        loop.whiteboard.update("test_key", {"test": "value"})
        data = loop.whiteboard.get("test_key")
        assert data["test"] == "value", "Whiteboard update/get should work"
        result.add_pass("Whiteboard 功能正常")

        # 验证 skill_registry 向后兼容
        skills = loop.skill_registry.get_skills("planner")
        assert "web_search" in skills or "python_exec" in skills, "Should have some skills"
        result.add_pass("SkillRegistry 向后兼容")

    except Exception as e:
        result.add_fail("InferenceLoop 基础功能", str(e))


def test_inference_loop_profile():
    """测试 Loop Profile 决策功能"""
    print("\n=== Test 2: Loop Profile 决策 ===")

    try:
        from swarmbot.loops.inference import InferenceLoop
        from swarmbot.config_manager import load_config

        config = load_config()
        workspace = Path.home() / ".swarmbot" / "workspace"

        loop = InferenceLoop(config, str(workspace))

        # 测试 profile 设置
        settings = loop._profile_settings("lean")
        assert settings["analysis_workers"] == 1, "Lean profile should have 1 analysis worker"
        result.add_pass("Lean profile 设置正确")

        settings = loop._profile_settings("balanced")
        assert settings["analysis_workers"] == 2, "Balanced profile should have 2 analysis workers"
        result.add_pass("Balanced profile 设置正确")

        settings = loop._profile_settings("swarm_max")
        assert settings["analysis_workers"] == 3, "Swarm_max profile should have 3 analysis workers"
        result.add_pass("Swarm_max profile 设置正确")

        # 测试工具门控
        gate_result = loop._decide_tool_gate_once(
            stage="collection",
            user_input="今天天气如何？",
            context_json="{}",
            fallback_tools=["web_search"]
        )
        assert "ok" in gate_result, "Gate result should have 'ok' key"
        result.add_pass("工具门控决策正常")

    except Exception as e:
        result.add_fail("Loop Profile 决策", str(e))


def test_context_pool_integration():
    """测试 context_pool 与 InferenceLoop 集成"""
    print("\n=== Test 3: ContextPool 集成测试 ===")

    try:
        from swarmbot.loops.inference import InferenceLoop
        from swarmbot.config_manager import load_config

        config = load_config()
        workspace = Path.home() / ".swarmbot" / "workspace"

        loop = InferenceLoop(config, str(workspace))

        # 验证 context_pool 存在
        assert loop.context_pool is not None, "context_pool should be initialized"
        result.add_pass("context_pool 已初始化")

        # 测试 _get_context_for_collection (同步调用，因为它是同步方法)
        analysis = {"domain": "security"}
        context = loop._get_context_for_collection(analysis)
        assert isinstance(context, dict), f"Context should be a dict, got {type(context)}"
        result.add_pass("_get_context_for_collection 返回正确格式")

        # 测试 _format_context_pool_for_prompt
        prompt_text = loop._format_context_pool_for_prompt(context)
        assert isinstance(prompt_text, str), "Prompt text should be a string"
        result.add_pass("_format_context_pool_for_prompt 返回正确格式")

    except Exception as e:
        result.add_fail("ContextPool 集成", str(e))


# ============================================================
# Test 4-5: SkillPool 功能测试
# ============================================================

def test_skill_pool_basic():
    """测试 SkillPool 基本功能"""
    print("\n=== Test 4: SkillPool 基本功能 ===")

    try:
        from swarmbot.skill_pool import SkillPool, Skill

        # 获取单例
        pool = SkillPool.get_instance(Path.home() / ".swarmbot" / "skills_test")

        # 测试 get_skills_for_task
        skills = pool.get_skills_for_task("planner", "分析代码性能")
        assert isinstance(skills, dict), "Skills should be a dict"
        assert "whiteboard_update" in skills, "Should have base skills"
        result.add_pass("get_skills_for_task 返回正确格式")

        # 测试技能注册
        test_skill = Skill(
            skill_id="test_regression",
            name="回归测试技能",
            description="用于测试",
            category="test",
            prompt_template="Test prompt",
            required_tools=["file_read"]
        )
        pool.registry.register_skill(test_skill)
        result.add_pass("技能注册成功")

        # 验证注册
        all_skills = pool.get_all_skills()
        assert "test_regression" in all_skills, "Skill should be registered"
        result.add_pass("技能验证成功")

    except Exception as e:
        result.add_fail("SkillPool 基本功能", str(e))


def test_skill_generator_quality_check():
    """测试 SkillGenerator 质量检查"""
    print("\n=== Test 5: SkillGenerator 质量检查 ===")

    try:
        from swarmbot.skill_pool import SkillGenerator

        generator = SkillGenerator()

        # 测试高质量执行 (应该生成)
        high_quality = {
            "bundle_id": "core.test",
            "execution_history": [{"step": "test", "result": "success"}],
            "eval": {"grade": "A", "score": 0.95, "issues": []}
        }
        skill = generator.generate_from_execution(high_quality)
        # 可能生成也可能不生成 (取决于执行历史)
        result.add_pass("高质量执行处理正常")

        # 测试低质量执行 (不应该生成)
        low_quality = {
            "bundle_id": "core.test",
            "execution_history": [],
            "eval": {"grade": "D", "score": 0.2, "issues": ["Failed"]}
        }
        skill = generator.generate_from_execution(low_quality)
        assert skill is None, "Should not generate skill from low quality"
        result.add_pass("低质量执行被正确拒绝")

        # 测试边界情况 (Grade=B, Score=0.7)
        boundary = {
            "bundle_id": "core.test",
            "execution_history": [{"step": "test"}],
            "eval": {"grade": "B", "score": 0.7, "issues": []}
        }
        skill = generator.generate_from_execution(boundary)
        result.add_pass("边界情况处理正常")

    except Exception as e:
        result.add_fail("SkillGenerator 质量检查", str(e))


# ============================================================
# Test 6-7: Gateway 和 Orchestrator 测试
# ============================================================

def test_gateway_orchestrator_priority():
    """测试 Gateway Orchestrator 优先级处理"""
    print("\n=== Test 6: Gateway Orchestrator 优先级 ===")

    try:
        from swarmbot.gateway.orchestrator import Priority, PriorityMessageQueue, PrioritizedMessage

        async def run_test():
            queue = PriorityMessageQueue()

            # 添加不同优先级的消息
            messages = [
                (Priority.P2_BUNDLE_REPORT, "Bundle report"),
                (Priority.P0_USER_RESPONSE, "User response"),
                (Priority.P1_HUMAN_REQUEST, "Human request"),
                (Priority.P3_SYSTEM_INFO, "System info"),
            ]

            for priority, content in messages:
                await queue.put(PrioritizedMessage(
                    priority=priority,
                    timestamp=time.time(),
                    content=content,
                    msg_type="test"
                ))

            # 验证优先级顺序
            msg1 = await queue.get()
            assert msg1.priority == Priority.P0_USER_RESPONSE, "First should be P0"
            result.add_pass("P0 优先级最高")

            msg2 = await queue.get()
            assert msg2.priority == Priority.P1_HUMAN_REQUEST, "Second should be P1"
            result.add_pass("P1 优先级第二")

            msg3 = await queue.get()
            assert msg3.priority == Priority.P2_BUNDLE_REPORT, "Third should be P2"
            result.add_pass("P2 优先级第三")

            msg4 = await queue.get()
            assert msg4.priority == Priority.P3_SYSTEM_INFO, "Fourth should be P3"
            result.add_pass("P3 优先级最低")

        asyncio.run(run_test())

    except Exception as e:
        result.add_fail("Gateway Orchestrator 优先级", str(e))


def test_output_buffer_integration():
    """测试 OutputBuffer 缓冲整合"""
    print("\n=== Test 7: OutputBuffer 缓冲整合 ===")

    try:
        from swarmbot.gateway.orchestrator import OutputBuffer, PrioritizedMessage, Priority

        async def run_test():
            buffer = OutputBuffer(max_wait_seconds=0.05)

            # 缓冲消息
            await buffer.buffer(PrioritizedMessage(
                priority=Priority.P2_BUNDLE_REPORT,
                timestamp=int(time.time() * 1000),
                content="Message 1",
                msg_type="bundle"
            ))
            await buffer.buffer(PrioritizedMessage(
                priority=Priority.P2_BUNDLE_REPORT,
                timestamp=int(time.time() * 1000),
                content="Message 2",
                msg_type="bundle"
            ))

            # 立即检查 (不应该刷新)
            should_flush = await buffer.should_flush()
            # 可能为 False (如果时间未到)
            result.add_pass("缓冲消息后应检查刷新条件")

            # 等待超时
            await asyncio.sleep(0.1)

            should_flush = await buffer.should_flush()
            assert should_flush, "Should flush after timeout"
            result.add_pass("超时后正确刷新")

            contents = await buffer.flush()
            assert len(contents) == 2, f"Should have 2 contents, got {len(contents)}"
            result.add_pass("刷新内容数量正确")

        asyncio.run(run_test())

    except Exception as e:
        result.add_fail("OutputBuffer 缓冲整合", str(e))


# ============================================================
# Test 8-9: SharedContextPool 测试
# ============================================================

def test_context_pool_persistence():
    """测试 ContextPool 持久化"""
    print("\n=== Test 8: ContextPool 持久化 ===")

    try:
        from swarmbot.gateway.orchestrator import SharedContextPool

        async def run_test():
            import tempfile
            import shutil

            # 创建临时目录
            test_dir = Path(tempfile.mkdtemp())

            try:
                pool = SharedContextPool(test_dir)

                # 验证文件创建
                assert pool.file_path.exists(), "Context file should be created"
                result.add_pass("Context 文件自动创建")

                # 更新状态
                await pool.update("core.test_bundle", "success", "Test details")
                result.add_pass("更新状态成功")

                # 读取状态
                status = await pool.get_status("core.test_bundle")
                assert status is not None, "Status should exist"
                assert status["status"] == "success", "Status should match"
                result.add_pass("读取状态正确")

                # 读取所有状态
                all_status = await pool.get_all_status()
                assert "core.test_bundle" in all_status, "Should contain test bundle"
                result.add_pass("读取所有状态正确")

                # 验证文件格式 (Markdown)
                content = pool.file_path.read_text()
                assert "| bundle_id |" in content, "Should be Markdown table format"
                result.add_pass("文件格式为 Markdown 表格")

            finally:
                shutil.rmtree(test_dir)

        asyncio.run(run_test())

    except Exception as e:
        result.add_fail("ContextPool 持久化", str(e))


def test_context_pool_cleanup():
    """测试 ContextPool 自动清理过期记录"""
    print("\n=== Test 9: ContextPool 自动清理 ===")

    try:
        from swarmbot.gateway.orchestrator import SharedContextPool

        async def run_test():
            import tempfile
            import shutil
            import time

            test_dir = Path(tempfile.mkdtemp())

            try:
                pool = SharedContextPool(test_dir)

                # 手动添加过期记录 (25 小时前)
                old_timestamp = str(time.time() - (25 * 60 * 60))
                content = (
                    "# Context Memory\n\n"
                    "## Active Bundle Status\n\n"
                    "| bundle_id | timestamp | status | details |\n"
                    "|-----------|-----------|--------|---------|\n"
                    f"| old_bundle | {old_timestamp} | old | Expired |\n"
                    f"| new_bundle | {time.time()} | new | Valid |\n"
                )
                pool.file_path.write_text(content)

                # 读取所有状态 (应该自动清理过期记录)
                all_status = await pool.get_all_status()

                assert "old_bundle" not in all_status, "Old bundle should be cleaned"
                result.add_pass("过期记录被自动清理")

                assert "new_bundle" in all_status, "New bundle should remain"
                result.add_pass("有效记录保留")

            finally:
                shutil.rmtree(test_dir)

        asyncio.run(run_test())

    except Exception as e:
        result.add_fail("ContextPool 自动清理", str(e))


# ============================================================
# Test 10: Autonomous Engine 兼容性测试
# ============================================================

def test_autonomous_engine_import():
    """测试 Autonomous Engine 可以正常导入"""
    print("\n=== Test 10: Autonomous Engine 兼容性 ===")

    try:
        from swarmbot.autonomous.engine import AutonomousEngine, Bundle
        import threading

        # 创建停止事件
        stop_event = threading.Event()

        # 初始化引擎 (不启动)
        engine = AutonomousEngine(stop_event)
        result.add_pass("AutonomousEngine 初始化成功")

        # 验证新增组件
        assert hasattr(engine, '_skill_pool'), "Should have _skill_pool"
        assert hasattr(engine, '_context_pool'), "Should have _context_pool"
        result.add_pass("新增组件已集成")

        # 验证 bundles 字典存在
        assert isinstance(engine.bundles, dict), "Bundles should be a dict"
        result.add_pass("Bundles 字典正常")

    except Exception as e:
        result.add_fail("Autonomous Engine 兼容性", str(e))


# ============================================================
# Test 11: 向后兼容性测试
# ============================================================

def test_backward_compatibility():
    """测试向后兼容性"""
    print("\n=== Test 11: 向后兼容性测试 ===")

    try:
        # 测试旧的技能注册表仍然可用
        from swarmbot.loops.skill_registry import SkillRegistry, VALID_SKILLS

        registry = SkillRegistry()

        # 验证内置技能
        assert "whiteboard_update" in VALID_SKILLS, "whiteboard_update should be valid"
        assert "web_search" in VALID_SKILLS, "web_search should be valid"
        result.add_pass("VALID_SKILLS 集合正常")

        # 验证角色技能映射
        planner_skills = registry.get_skills("planner")
        assert isinstance(planner_skills, dict), "Should return dict"
        result.add_pass("角色技能映射正常")

        # 验证领域技能
        code_skills = registry.get_skills("coder")
        assert "file_write" in code_skills, "Coder should have file_write skill"
        result.add_pass("领域技能正常")

    except Exception as e:
        result.add_fail("向后兼容性测试", str(e))


# ============================================================
# Test 12: 配置加载测试
# ============================================================

def test_config_loading():
    """测试配置加载"""
    print("\n=== Test 12: 配置加载测试 ===")

    try:
        from swarmbot.config_manager import load_config, ensure_dirs

        # 确保目录存在
        ensure_dirs()

        # 加载配置
        config = load_config()

        # 验证基本配置
        assert config is not None, "Config should load"
        result.add_pass("配置加载成功")

        # 验证 providers
        assert hasattr(config, 'providers'), "Should have providers"
        assert len(config.providers) >= 1, "Should have at least one provider"
        result.add_pass("Providers 配置正常")

        # 验证 autonomous 配置
        assert hasattr(config, 'autonomous'), "Should have autonomous config"
        assert hasattr(config.autonomous, 'enabled'), "Should have enabled flag"
        result.add_pass("Autonomous 配置正常")

        # 验证 daemon 配置
        assert hasattr(config, 'daemon'), "Should have daemon config"
        result.add_pass("Daemon 配置正常")

    except Exception as e:
        result.add_fail("配置加载测试", str(e))


# ============================================================
# Main
# ============================================================

def main():
    """运行所有测试"""
    print("=" * 60)
    print("Gateway-MasterAgent 全面兼容性测试套件 (v2.0)")
    print("=" * 60)

    # 运行所有测试
    test_inference_loop_import()
    test_inference_loop_profile()
    test_context_pool_integration()
    test_skill_pool_basic()
    test_skill_generator_quality_check()
    test_gateway_orchestrator_priority()
    test_output_buffer_integration()
    test_context_pool_persistence()
    test_context_pool_cleanup()
    test_autonomous_engine_import()
    test_backward_compatibility()
    test_config_loading()

    # 输出结果
    passed = result.summary()

    if passed:
        print("\n✓ 所有兼容性测试通过！新架构与现有功能无冲突。")
        return 0
    else:
        print("\n✗ 存在兼容性问题，请检查失败测试。")
        return 1


if __name__ == "__main__":
    sys.exit(main())
