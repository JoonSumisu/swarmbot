#!/usr/bin/env python3
"""
端到端测试：验证路由系统与 Loop 集成
"""

import sys
sys.path.insert(0, '/root/swarmbot_dev')

from swarmbot.loops.router import decide_route
from swarmbot.config_manager import load_config
from swarmbot.loops.simple_direct_master import SimpleDirectMasterLoop
from swarmbot.loops.inference import InferenceLoop  # reasoning_swarm
from swarmbot.loops.engineering_complex import EngineeringComplexLoop
from pathlib import Path

config = load_config()
WORKSPACE_PATH = Path.home() / ".swarmbot" / "workspace"

# 测试用例：(输入，期望的 Loop 类)
test_cases = [
    ("你好", SimpleDirectMasterLoop),
    ("谢谢", SimpleDirectMasterLoop),
    ("帮我写一个 Python 脚本", EngineeringComplexLoop),
    ("部署服务", EngineeringComplexLoop),
    ("解释量子力学", InferenceLoop),
    ("如何学习编程", InferenceLoop),
]

print("=" * 80)
print("端到端测试：路由 -> Loop 实例化")
print("=" * 80)

passed = 0
failed = 0

for text, expected_loop_class in test_cases:
    try:
        # 1. 路由决策
        route_mode, route_reason = decide_route(text, config)

        # 2. 根据路由创建对应的 Loop
        if route_mode == "simple_direct_master":
            loop_class = SimpleDirectMasterLoop
        elif route_mode == "engineering_complex":
            loop_class = EngineeringComplexLoop
        else:  # reasoning_swarm
            loop_class = InferenceLoop

        # 3. 验证
        if loop_class == expected_loop_class:
            status = "PASS"
            passed += 1
        else:
            status = "FAIL"
            failed += 1

        print(f"[{status}] '{text[:20]}' -> {route_mode:<25} -> {loop_class.__name__}")

    except Exception as e:
        status = "ERROR"
        failed += 1
        print(f"[{status}] '{text[:20]}' -> 错误：{e}")

print("\n" + "=" * 80)
print(f"结果：{passed}/{len(test_cases)} 通过")
print("=" * 80)

sys.exit(0 if failed == 0 else 1)
