#!/usr/bin/env python3
"""
Swarmbot v2.0 冒烟测试脚本

测试场景:
1. 连续对话测试 - 10 轮对话上下文连续性
2. 文件操作测试 - 浏览、创建、修改本地文件
3. Boot 文件测试 - soul、swarmboot 加载验证
4. Bundle 创建测试 - Autonomous 创建新 Bundle
5. 推理工具测试 - 调用 Standard/Supervised/SwarmsWorker
6. 记忆搜索测试 - Warm/ColdMemory 正确检索
7. Hub 相互沟通测试 - 验证 Autonomous/MasterAgent/InferenceLoop/User 四方沟通正常

使用方法:
    python tests/smoke_test_v2.py [--quick] [--local-model]

配置本地模型:
    swarmbot provider add \
      --base-url "http://127.0.0.1:8000/v1" \
      --api-key "sk-xxx" \
      --model "qwen3-coder-next"
"""

import json
import os
import sys
import time
import tempfile
import shutil
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from enum import Enum

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from swarmbot.gateway.communication_hub import CommunicationHub, MessageType, MessagePriority
from swarmbot.gateway.orchestrator import GatewayMasterAgent
from swarmbot.config_manager import load_config


class TestStatus(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"


@dataclass
class TestResult:
    name: str
    status: TestStatus
    message: str = ""
    details: Optional[Dict[str, Any]] = None


class SmokeTestRunner:
    """冒烟测试执行器"""

    def __init__(self, workspace_path: Optional[str] = None, quick_mode: bool = False,
                 local_model: bool = False):
        self.workspace_path = Path(workspace_path) if workspace_path else None
        self.quick_mode = quick_mode
        self.local_model = local_model  # 是否使用本地模型测试
        self.results: List[TestResult] = []
        self.temp_dir = None
        self.llm_client = None

        # 设置测试工作空间
        if self.workspace_path is None:
            self.temp_dir = tempfile.mkdtemp(prefix="swarmbot_smoke_test_")
            self.workspace_path = Path(self.temp_dir)
            print(f"[SmokeTest] Using temp workspace: {self.workspace_path}")

        # 确保工作空间存在
        self.workspace_path.mkdir(parents=True, exist_ok=True)

        # 初始化配置和 LLM 客户端
        try:
            self.config = load_config()
            if self.local_model:
                self._init_local_model_client()
        except Exception as e:
            print(f"[SmokeTest] Warning: Could not load config: {e}")
            self.config = None

    def _init_local_model_client(self):
        """初始化本地模型客户端"""
        try:
            from swarmbot.llm_client import OpenAICompatibleClient
            from swarmbot.config_manager import ProviderConfig

            # 注意：请替换为你自己的模型配置
            provider = ProviderConfig(
                name='local-model',
                base_url='http://localhost:8000/v1',  # 修改为你的 API 地址
                api_key='your-api-key',                # 修改为你的 API 密钥
                model='your-model-name',               # 修改为你的模型名称
                max_tokens=32000,
                temperature=0.7,
            )
            self.llm_client = OpenAICompatibleClient.from_provider(provider=provider)
            print("[SmokeTest] Local model client initialized")
        except Exception as e:
            print(f"[SmokeTest] Warning: Could not initialize local model: {e}")
            self.llm_client = None

    def cleanup(self):
        """清理临时目录"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            print(f"[SmokeTest] Cleaned up temp workspace")

    def record_result(self, name: str, status: TestStatus, message: str = "", details: Optional[Dict[str, Any]] = None):
        """记录测试结果"""
        result = TestResult(name=name, status=status, message=message, details=details)
        self.results.append(result)

        status_icon = {
            TestStatus.PASS: "✓",
            TestStatus.FAIL: "✗",
            TestStatus.SKIP: "○",
        }.get(status, "?")

        print(f"  [{status_icon}] {name}: {message}")

    def print_summary(self):
        """打印测试摘要"""
        print("\n" + "=" * 60)
        print("Smoke Test Summary")
        print("=" * 60)

        passed = sum(1 for r in self.results if r.status == TestStatus.PASS)
        failed = sum(1 for r in self.results if r.status == TestStatus.FAIL)
        skipped = sum(1 for r in self.results if r.status == TestStatus.SKIP)

        print(f"\nResults: {passed} passed, {failed} failed, {skipped} skipped")
        print(f"Total: {len(self.results)} tests\n")

        if failed > 0:
            print("Failed tests:")
            for r in self.results:
                if r.status == TestStatus.FAIL:
                    print(f"  - {r.name}: {r.message}")

        print("=" * 60)

    # ========== 测试用例 ==========

    def test_communication_hub_basic(self):
        """测试 1: CommunicationHub 基础功能"""
        print("\n[Test 1] CommunicationHub 基础功能测试")

        try:
            hub = CommunicationHub(self.workspace_path)

            # 测试发送消息
            msg_id = hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="测试消息 1",
                recipient="master_agent",
            )
            assert msg_id, "Message ID should not be empty"
            self.record_result("发送消息", TestStatus.PASS, f"msg_id={msg_id}")

            # 测试接收消息
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert len(messages) == 1, f"Expected 1 message, got {len(messages)}"
            self.record_result("接收消息", TestStatus.PASS, f"收到 {len(messages)} 条消息")

            # 测试标记已消费
            success = hub.mark_consumed(msg_id)
            assert success, "Failed to mark message as consumed"
            self.record_result("标记已消费", TestStatus.PASS, "消息已标记")

            # 验证消息不再出现在未消费列表中
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert len(messages) == 0, f"Expected 0 messages after consuming, got {len(messages)}"
            self.record_result("验证已消费", TestStatus.PASS, "消息列表已清空")

        except Exception as e:
            self.record_result("CommunicationHub 基础功能", TestStatus.FAIL, str(e))

    def test_communication_hub_recipient(self):
        """测试 2: CommunicationHub 接收者过滤"""
        print("\n[Test 2] CommunicationHub 接收者过滤测试")

        try:
            hub = CommunicationHub(self.workspace_path)

            # 发送给不同接收者的消息
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="给 master_agent 的消息",
                recipient="master_agent",
            )
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="给 inference_loop 的消息",
                recipient="inference_loop",
            )
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="广播消息",
                recipient="broadcast",
            )

            # 测试只接收发给 master_agent 的消息（包括广播）
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert len(messages) == 2, f"Expected 2 messages for master_agent, got {len(messages)}"
            self.record_result("接收者过滤 (master_agent)", TestStatus.PASS, f"收到 {len(messages)} 条消息")

            # 测试只接收发给 inference_loop 的消息（包括广播）
            messages = hub.get_unconsumed_messages(recipient_filter="inference_loop")
            assert len(messages) == 2, f"Expected 2 messages for inference_loop, got {len(messages)}"
            self.record_result("接收者过滤 (inference_loop)", TestStatus.PASS, f"收到 {len(messages)} 条消息")

            # 清理
            for msg in hub.get_unconsumed_messages():
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("CommunicationHub 接收者过滤", TestStatus.FAIL, str(e))

    def test_communication_hub_thread(self):
        """测试 3: CommunicationHub 线程追踪"""
        print("\n[Test 3] CommunicationHub 线程追踪测试")

        try:
            hub = CommunicationHub(self.workspace_path)

            thread_id = "test-thread-1"

            # 发送线程消息
            msg_id_1 = hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="线程消息 1",
                recipient="master_agent",
                thread_id=thread_id,
            )
            msg_id_2 = hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="回复消息 1",
                recipient="master_agent",
                thread_id=thread_id,
                in_reply_to=msg_id_1,
            )

            # 验证 thread_id
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            thread_messages = [m for m in messages if m.thread_id == thread_id]
            assert len(thread_messages) == 2, f"Expected 2 thread messages, got {len(thread_messages)}"
            self.record_result("线程消息追踪", TestStatus.PASS, f"找到 {len(thread_messages)} 条线程消息")

            # 验证 in_reply_to
            reply_msg = next(m for m in thread_messages if m.in_reply_to)
            assert reply_msg.in_reply_to == msg_id_1, f"Expected reply to {msg_id_1}, got {reply_msg.in_reply_to}"
            self.record_result("引用回复追踪", TestStatus.PASS, f"reply_to={reply_msg.in_reply_to}")

            # 清理
            for msg in messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("CommunicationHub 线程追踪", TestStatus.FAIL, str(e))

    def test_communication_hub_convenience_methods(self):
        """测试 4: CommunicationHub 便捷方法"""
        print("\n[Test 4] CommunicationHub 便捷方法测试")

        try:
            hub = CommunicationHub(self.workspace_path)

            # 测试 send_to_master_agent
            msg_id = hub.send_to_master_agent(
                msg_type=MessageType.AUTONOMOUS_STATUS,
                sender="autonomous_engine",
                content="Bundle 完成",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert any(m.msg_id == msg_id for m in messages), "Message not found"
            self.record_result("send_to_master_agent", TestStatus.PASS)

            # 测试 send_to_autonomous_engine
            msg_id = hub.send_to_autonomous_engine(
                msg_type=MessageType.USER_FEEDBACK,
                sender="master_agent",
                content="用户反馈",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="autonomous_engine")
            assert any(m.msg_id == msg_id for m in messages), "Message not found"
            self.record_result("send_to_autonomous_engine", TestStatus.PASS)

            # 测试 send_to_inference_loop
            msg_id = hub.send_to_inference_loop(
                msg_type=MessageType.HUMAN_IN_LOOP_RESPONSE,
                sender="user",
                content="用户确认",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="inference_loop")
            assert any(m.msg_id == msg_id for m in messages), "Message not found"
            self.record_result("send_to_inference_loop", TestStatus.PASS)

            # 测试 send_to_user
            msg_id = hub.send_to_user(
                msg_type=MessageType.SYSTEM_INFO,
                sender="master_agent",
                content="处理结果",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="user")
            assert any(m.msg_id == msg_id for m in messages), "Message not found"
            self.record_result("send_to_user", TestStatus.PASS)

            # 测试 broadcast
            msg_id = hub.broadcast(
                msg_type=MessageType.SYSTEM_INFO,
                sender="system",
                content="广播通知",
            )
            # 广播消息应该被所有接收者看到
            for recipient in ["master_agent", "inference_loop", "autonomous_engine"]:
                messages = hub.get_unconsumed_messages(recipient_filter=recipient)
                assert any(m.msg_id == msg_id for m in messages), f"Broadcast message not found for {recipient}"
            self.record_result("broadcast", TestStatus.PASS)

            # 清理
            for msg in hub.get_unconsumed_messages():
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("CommunicationHub 便捷方法", TestStatus.FAIL, str(e))

    def test_communication_hub_hub_communication(self):
        """测试 5: Hub 相互沟通测试 (四方沟通)"""
        print("\n[Test 5] Hub 相互沟通测试 (Autonomous/MasterAgent/InferenceLoop/User)")

        try:
            hub = CommunicationHub(self.workspace_path)

            # 场景 1: Autonomous → MasterAgent 消息
            msg_id_1 = hub.send_to_master_agent(
                msg_type=MessageType.AUTONOMOUS_STATUS,
                sender="autonomous_engine",
                content="Bundle core.memory_foundation 执行完成",
                metadata={"bundle_id": "core.memory_foundation", "status": "success"},
            )
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert any(m.msg_id == msg_id_1 for m in messages), "Autonomous→MasterAgent 消息未找到"
            self.record_result("Autonomous → MasterAgent", TestStatus.PASS)
            hub.mark_consumed(msg_id_1)

            # 场景 2: MasterAgent → Autonomous 反馈
            msg_id_2 = hub.send_to_autonomous_engine(
                msg_type=MessageType.USER_FEEDBACK,
                sender="master_agent",
                content="用户对 Bundle 执行的反馈：优化方向正确",
                metadata={"bundle_id": "core.memory_foundation"},
            )
            messages = hub.get_unconsumed_messages(recipient_filter="autonomous_engine")
            assert any(m.msg_id == msg_id_2 for m in messages), "MasterAgent→Autonomous 消息未找到"
            self.record_result("MasterAgent → Autonomous", TestStatus.PASS)
            hub.mark_consumed(msg_id_2)

            # 场景 3: InferenceLoop → MasterAgent 人在回路请求
            msg_id_3 = hub.send_to_master_agent(
                msg_type=MessageType.HUMAN_IN_LOOP_REQUEST,
                sender="inference_loop",
                content="需要确认分析方向是否正确",
                priority=MessagePriority.CRITICAL,
                metadata={"loop_id": "session-123", "stage": "ANALYSIS_REVIEW"},
            )
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert any(m.msg_id == msg_id_3 for m in messages), "InferenceLoop→MasterAgent 消息未找到"
            self.record_result("InferenceLoop → MasterAgent", TestStatus.PASS)
            hub.mark_consumed(msg_id_3)

            # 场景 4: MasterAgent → InferenceLoop 用户响应
            msg_id_4 = hub.send_to_inference_loop(
                msg_type=MessageType.HUMAN_IN_LOOP_RESPONSE,
                sender="master_agent",
                content="用户确认继续执行",
                priority=MessagePriority.HIGH,
                metadata={"request_msg_id": msg_id_3},
                in_reply_to=msg_id_3,
            )
            messages = hub.get_unconsumed_messages(recipient_filter="inference_loop")
            assert any(m.msg_id == msg_id_4 for m in messages), "MasterAgent→InferenceLoop 消息未找到"
            self.record_result("MasterAgent → InferenceLoop", TestStatus.PASS)
            hub.mark_consumed(msg_id_4)

            # 场景 5: User → MasterAgent 直接消息
            msg_id_5 = hub.send_to_master_agent(
                msg_type=MessageType.USER_FEEDBACK,
                sender="user",
                content="查询当前状态",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            assert any(m.msg_id == msg_id_5 for m in messages), "User→MasterAgent 消息未找到"
            self.record_result("User → MasterAgent", TestStatus.PASS)
            hub.mark_consumed(msg_id_5)

            # 场景 6: MasterAgent → User 响应
            msg_id_6 = hub.send_to_user(
                msg_type=MessageType.SYSTEM_INFO,
                sender="master_agent",
                content="当前系统运行正常，Bundle 执行成功",
            )
            messages = hub.get_unconsumed_messages(recipient_filter="user")
            assert any(m.msg_id == msg_id_6 for m in messages), "MasterAgent→User 消息未找到"
            self.record_result("MasterAgent → User", TestStatus.PASS)
            hub.mark_consumed(msg_id_6)

            # 场景 7: 跨线程消息隔离测试
            thread_a = "thread-A"
            thread_b = "thread-B"

            hub.send_to_master_agent(
                msg_type=MessageType.SYSTEM_INFO,
                sender="autonomous_engine",
                content="线程 A 消息 1",
                thread_id=thread_a,
            )
            hub.send_to_master_agent(
                msg_type=MessageType.SYSTEM_INFO,
                sender="autonomous_engine",
                content="线程 B 消息 1",
                thread_id=thread_b,
            )

            # 验证线程隔离（这里简化测试，实际应该按 thread_id 过滤）
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            thread_a_msgs = [m for m in messages if m.thread_id == thread_a]
            thread_b_msgs = [m for m in messages if m.thread_id == thread_b]
            assert len(thread_a_msgs) == 1, f"Expected 1 thread A message, got {len(thread_a_msgs)}"
            assert len(thread_b_msgs) == 1, f"Expected 1 thread B message, got {len(thread_b_msgs)}"
            self.record_result("跨线程消息隔离", TestStatus.PASS)

            # 清理
            for msg in hub.get_unconsumed_messages():
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("Hub 相互沟通测试", TestStatus.FAIL, str(e))

    def test_boot_file_loading(self):
        """测试 6: Boot 文件加载测试"""
        print("\n[Test 6] Boot 文件加载测试")

        try:
            # 检查 boot 文件是否存在
            boot_paths = [
                Path.home() / ".swarmbot/boot/SOUL.md",
                Path.home() / ".swarmbot/boot/swarmboot.md",
                Path.home() / ".swarmbot/boot/inference_tools.md",
            ]

            for boot_path in boot_paths:
                if boot_path.exists():
                    content = boot_path.read_text(encoding="utf-8")
                    self.record_result(
                        f"Boot 文件加载：{boot_path.name}",
                        TestStatus.PASS,
                        f"{len(content)} chars",
                    )
                else:
                    self.record_result(
                        f"Boot 文件加载：{boot_path.name}",
                        TestStatus.SKIP,
                        "文件不存在",
                    )

        except Exception as e:
            self.record_result("Boot 文件加载", TestStatus.FAIL, str(e))

    def test_inference_tools_config(self):
        """测试 7: 推理工具配置解析"""
        print("\n[Test 7] 推理工具配置解析测试")

        try:
            agent = GatewayMasterAgent(self.workspace_path, self.config)
            tools_config = agent._load_inference_tools_config()

            if tools_config:
                self.record_result(
                    "推理工具配置加载",
                    TestStatus.PASS,
                    f"加载 {len(tools_config)} 个工具",
                )

                for tool in tools_config:
                    tool_id = tool.get("tool_id", "unknown")
                    class_name = tool.get("class_name", "unknown")
                    module_path = tool.get("module_path", "unknown")

                    # 验证工具类是否存在
                    try:
                        import importlib
                        module = importlib.import_module(module_path)
                        cls = getattr(module, class_name)
                        self.record_result(
                            f"工具类验证：{tool_id}",
                            TestStatus.PASS,
                            f"{module_path}.{class_name}",
                        )
                    except ImportError as e:
                        self.record_result(
                            f"工具类验证：{tool_id}",
                            TestStatus.FAIL,
                            f"无法导入：{e}",
                        )
            else:
                self.record_result(
                    "推理工具配置加载",
                    TestStatus.FAIL,
                    "未找到工具配置",
                )

        except Exception as e:
            self.record_result("推理工具配置解析", TestStatus.FAIL, str(e))

    def test_master_agent_simple_direct(self):
        """测试 8: MasterAgent 简单对话模式"""
        print("\n[Test 8] MasterAgent 简单对话模式测试")

        try:
            agent = GatewayMasterAgent(self.workspace_path, self.config)

            # 测试简单对话检测
            simple_inputs = ["你好", "谢谢", "好的", "Hello", "再见"]
            for inp in simple_inputs:
                result = agent._should_use_simple_direct(inp)
                if result:
                    self.record_result(f"简单对话检测：'{inp}'", TestStatus.PASS, "正确识别为简单对话")
                else:
                    self.record_result(f"简单对话检测：'{inp}'", TestStatus.FAIL, "未识别为简单对话")

            # 测试非简单对话检测
            complex_inputs = ["如何优化代码？", "帮我分析这个问题", "为什么会出现这个错误？"]
            for inp in complex_inputs:
                result = agent._should_use_simple_direct(inp)
                if not result:
                    self.record_result(f"复杂对话检测：'{inp}'", TestStatus.PASS, "正确识别为复杂对话")
                else:
                    self.record_result(f"复杂对话检测：'{inp}'", TestStatus.FAIL, "错误识别为简单对话")

        except Exception as e:
            self.record_result("MasterAgent 简单对话模式", TestStatus.FAIL, str(e))

    def test_shared_context_pool(self):
        """测试 9: SharedContextPool 测试"""
        print("\n[Test 9] SharedContextPool 测试")

        try:
            from swarmbot.gateway.orchestrator import SharedContextPool

            pool = SharedContextPool(self.workspace_path)

            # 更新 Bundle 状态
            pool.update_sync("test.bundle", "success", "执行成功")
            pool.update_sync("test.bundle", "warning", "需要优化")

            # 获取状态
            status = pool.get_all_status_sync()
            assert "test.bundle" in status, "Bundle status not found"
            self.record_result("SharedContextPool 更新状态", TestStatus.PASS)

            # 获取任务上下文
            context = pool.get_context_for_task_sync(task_desc="优化 Bundle")
            assert "bundle_status" in context, "Context missing bundle_status"
            self.record_result("SharedContextPool 获取上下文", TestStatus.PASS)

        except Exception as e:
            self.record_result("SharedContextPool 测试", TestStatus.FAIL, str(e))

    def test_message_priority(self):
        """测试 10: 消息优先级测试"""
        print("\n[Test 10] 消息优先级测试")

        try:
            hub = CommunicationHub(self.workspace_path)

            # 发送不同优先级的消息
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="低优先级消息",
                recipient="master_agent",
                priority=MessagePriority.LOW,
            )
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="普通优先级消息",
                recipient="master_agent",
                priority=MessagePriority.NORMAL,
            )
            hub.send(
                msg_type=MessageType.SYSTEM_INFO,
                sender="test",
                content="高优先级消息",
                recipient="master_agent",
                priority=MessagePriority.HIGH,
            )
            hub.send(
                msg_type=MessageType.HUMAN_IN_LOOP_REQUEST,
                sender="test",
                content="紧急消息",
                recipient="master_agent",
                priority=MessagePriority.CRITICAL,
            )

            # 验证排序
            messages = hub.get_unconsumed_messages(recipient_filter="master_agent")
            priorities = [m.priority for m in messages]

            # 验证优先级顺序：CRITICAL < HIGH < NORMAL < LOW (数值越小优先级越高)
            priority_order = {
                MessagePriority.CRITICAL: 0,
                MessagePriority.HIGH: 1,
                MessagePriority.NORMAL: 2,
                MessagePriority.LOW: 3,
            }
            priority_values = [priority_order[p] for p in priorities]
            is_sorted = all(priority_values[i] <= priority_values[i+1] for i in range(len(priority_values)-1))

            if is_sorted:
                self.record_result("消息优先级排序", TestStatus.PASS, "按优先级正确排序")
            else:
                self.record_result("消息优先级排序", TestStatus.FAIL, "排序不正确")

            # 清理
            for msg in messages:
                hub.mark_consumed(msg.msg_id)

        except Exception as e:
            self.record_result("消息优先级测试", TestStatus.FAIL, str(e))

    def run_all_tests(self):
        """运行所有测试"""
        print("=" * 60)
        print("Swarmbot v2.0 Smoke Test")
        print("=" * 60)
        print(f"Workspace: {self.workspace_path}")
        print(f"Quick Mode: {self.quick_mode}")
        print()

        try:
            # CommunicationHub 测试
            self.test_communication_hub_basic()
            self.test_communication_hub_recipient()
            self.test_communication_hub_thread()
            self.test_communication_hub_convenience_methods()
            self.test_communication_hub_hub_communication()

            # Boot 文件测试
            self.test_boot_file_loading()

            # 推理工具测试
            self.test_inference_tools_config()

            # MasterAgent 测试
            self.test_master_agent_simple_direct()

            # ContextPool 测试
            self.test_shared_context_pool()

            # 优先级测试
            self.test_message_priority()

        finally:
            self.print_summary()
            self.cleanup()

        return all(r.status != TestStatus.FAIL for r in self.results)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Swarmbot v2.0 Smoke Test")
    parser.add_argument("--quick", action="store_true", help="快速模式")
    parser.add_argument("--workspace", type=str, help="指定工作空间路径")
    args = parser.parse_args()

    runner = SmokeTestRunner(workspace_path=args.workspace, quick_mode=args.quick)
    success = runner.run_all_tests()

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
