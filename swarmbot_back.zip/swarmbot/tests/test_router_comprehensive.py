#!/usr/bin/env python3
"""
全面测试路由系统
验证不同 loop 的正确使用、autonomous 信息沟通、gateway masteragent 效果
"""

import sys
sys.path.insert(0, '/root/swarmbot_dev')

from swarmbot.loops.router import decide_route
from swarmbot.config_manager import load_config

config = load_config()

# 测试用例：(输入，期望模式，描述)
test_cases = [
    # SIMPLE 测试
    ("你好", "simple_direct_master", "问候"),
    ("谢谢", "simple_direct_master", "感谢"),
    ("再见", "simple_direct_master", "告别"),
    ("早上好", "simple_direct_master", "问候"),
    ("Hi", "simple_direct_master", "英文问候"),
    ("是的", "simple_direct_master", "简单确认"),
    ("好的", "simple_direct_master", "简单确认"),
    ("哈哈", "simple_direct_master", "情感表达"),

    # ENGINEERING 测试
    ("帮我写一个 Python 脚本", "engineering_complex", "写代码"),
    ("部署服务到生产环境", "engineering_complex", "部署"),
    ("修复这个 bug", "engineering_complex", "修 bug"),
    ("创建一个 REST API", "engineering_complex", "创建 API"),
    ("爬取网页数据", "engineering_complex", "数据爬取"),
    ("执行这个命令", "engineering_complex", "执行命令"),
    ("修改配置文件", "engineering_complex", "操作文件"),
    ("初始化数据库", "engineering_complex", "数据库操作"),

    # REASONING 测试
    ("解释一下量子纠缠", "reasoning_swarm", "解释概念"),
    ("什么是机器学习", "reasoning_swarm", "知识查询"),
    ("如何学习编程", "reasoning_swarm", "提供建议"),
    ("明天北京天气怎么样", "reasoning_swarm", "查询信息"),
    ("分析一下这个问题", "reasoning_swarm", "分析问题"),
    ("为什么天空是蓝色的", "reasoning_swarm", "科学解释"),
    ("这个方案可行吗", "reasoning_swarm", "方案评估"),
    ("比较两种技术的优缺点", "reasoning_swarm", "对比分析"),
]

print("=" * 80)
print("LOOP ROUTER 全面测试")
print("=" * 80)

passed = 0
failed = 0
simple_pass = 0
simple_fail = 0
eng_pass = 0
eng_fail = 0
reason_pass = 0
reason_fail = 0

for text, expected_mode, description in test_cases:
    mode, reason = decide_route(text, config)
    status = "PASS" if mode == expected_mode else "FAIL"

    if status == "PASS":
        passed += 1
        if expected_mode == "simple_direct_master":
            simple_pass += 1
        elif expected_mode == "engineering_complex":
            eng_pass += 1
        else:
            reason_pass += 1
    else:
        failed += 1
        if expected_mode == "simple_direct_master":
            simple_fail += 1
        elif expected_mode == "engineering_complex":
            eng_fail += 1
        else:
            reason_fail += 1

    print(f"[{status}] {description}: {text[:20]:<20} -> {mode:<25} (期望：{expected_mode})")

print("\n" + "=" * 80)
print("测试结果汇总")
print("=" * 80)
print(f"总计：{passed}/{len(test_cases)} 通过 ({100*passed/len(test_cases):.1f}%)")
print(f"SIMPLE:      {simple_pass}/{simple_pass+simple_fail} 通过")
print(f"ENGINEERING: {eng_pass}/{eng_pass+eng_fail} 通过")
print(f"REASONING:   {reason_pass}/{reason_pass+reason_fail} 通过")
print("=" * 80)

if failed > 0:
    print(f"\n失败测试：{failed} 个")
    sys.exit(1)
else:
    print("\n所有测试通过！")
    sys.exit(0)
