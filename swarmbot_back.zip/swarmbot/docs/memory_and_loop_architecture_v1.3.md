# SwarmAgentLoop 架构与运行机制详解 (v1.3)

**版本**: v1.3
**最后更新**: 2026-03-15

本文档详细描述了 Swarmbot v1.3 的核心运行循环 (Loop)、记忆系统架构以及多智能体协作流程。

---

## 1. 核心架构图

```mermaid
graph TD
    User[用户 (Feishu/CLI)] --> Gateway[Gateway Server]
    Gateway --> Loop[InferenceLoop]
    Loop --> LLMClient[OpenAICompatibleClient]

    subgraph "InferenceLoop Execution"
        Loop -->|Phase 1| Analysis[Analysis - LLM Routing]
        Analysis -->|Route Decision| Route{Routing Mode}
        Route -->|simple_direct_master| Master[Master Agent]
        Route -->|reasoning_swarm| Swarm[Swarm Agents]
        Route -->|engineering_complex| Complex[Complex Workflow]

        Swarm -->|Task List| Supervisor[Supervisor Control]
        Supervisor -->|Stage Lock| Execution[Execution Phase]
        Execution -->|Tools| ToolAdapter[Tool Adapter]
        ToolAdapter -->|Exec| Tools[Native Tools]
        Tools -->|Result| Execution

        Execution -->|Results| Evaluation[Evaluation - Early Finish Scoring]
        Evaluation -->|Pass/Fail| Response[Response Generation]
    end

    Loop --> User

    subgraph "Autonomous Engine"
        BundleEngine[AutonomousEngine] -->|MonitorQueue| Monitor[Bundles Monitor]
        BundleEngine -->|ActionQueue| Action[Bundled Actions]

        Monitor -->|core.memory_foundation| QMD[QMD Memory Archival]
        Monitor -->|core.boot_optimizer| BootPrompts[Boot Prompts]
        Monitor -->|core.system_hygiene| SystemCheck[System Health]
        Monitor -->|core.bundle_governor| Conflict[Conflict Detection]
    end
```

---

## 2. 运行循环 (The Loop) 详解

Swarmbot 的处理流程是同步与异步结合的，主要分为 **Ingress**, **InferenceLoop Execution**, **Egress** 三个阶段。

### 2.1 Ingress (接入层)
*   **Gateway**: `swarmbot.gateway.server` 启动 HTTP Server，监听 Feishu WebSocket 或 CLI 输入。
*   **Interception**: `InferenceLoop` 拦截消息，屏蔽系统心跳，提取 `chat_id`。

### 2.2 InferenceLoop Execution (核心执行层)
v1.3 版本引入了 **LLM-Driven Routing** 自动选择最优路由模式：

| Route Mode | Profile | 描述 |
|------------|---------|------|
| `simple_direct_master` | lean | 简单问答，由 Master Agent 直接回答 |
| `reasoning_swarm` | balanced | 中等复杂任务，多 Agent Swarm 协作 |
| `engineering_complex` | swarm_max | 复杂工程任务，需要人机交互确认 |

#### Phase 1: Analysis (分析与路由)
- LLM 驱动的任务类型识别
- 多个 Planner Agent 投票决定 routing mode
- 动态分配 profile（worker 数量、context_limit）

#### Phase 2: Collection (上下文收集)
- 从 QMD检索相关知识
- 恢复 Whiteboard 状态
- 加载历史对话记录

#### Phase 3: Planning (计划生成)
- 使用 `framework_doc` 严格结构化输出
- Supervisor 阶段锁防止冲突转换
- 幂等控制动作防重复操作

#### Phase 4: Execution (执行阶段)
- 多 Agent 并行/串行执行任务
- Tool Adapter 执行原生工具调用
- 支持 ReAct 循环（最多 max_turns 轮）

#### Phase 5: Evaluation (评估阶段)
- 多个 Evaluators 投票打分
- Early Finish Scoring 基于：
  - Task Completion Rate
  - Confidence Level
  - Consistency Score
  - Evidence Coverage

#### Phase 6: Response & Organization (响应与记忆更新)
- Master Agent 格式化最终回复
- 更新 Whiteboard 状态
- 归档到 Warm Memory (L3)

### 2.3 Egress (输出层)
*   **Sanitization**: 清洗回复内容
*   **Delivery**: 通过 `FeishuChannel` 发送回用户

---

## 3. 自组织引擎 (Autonomous Engine)

v1.3 完全重构了后台自进化系统，使用 Bundle 模式替代传统的 Overthinking/Overaction Loop。

### 3.1 Bundle 架构

```python
class _Bundle:
    """自主任务集合基类"""
    def __init__(self, name: str, interval_seconds: int):
        self.name = name
        self.interval_seconds = interval_seconds
```

### 3.2 内置 Bundles

| Bundle Name | Interval | 功能 |
|-------------|----------|------|
| `core.memory_foundation` | 1800s (30min) | 记忆压缩与 QMD 归档 |
| `core.boot_optimizer` | 1200s (20min) | 启动提示优化 |
| `core.system_hygiene` | 600s (10min) | 系统健康监控 |
| `core.bundle_governor` | 300s (5min) | Bundle 冲突检测 |

### 3.3 Engine 架构

| Component | Purpose |
|-----------|---------|
| `MonitorQueue` | 存储来自 Bundle 检查的事件 |
| `ActionQueue` | 存储已批准的行动（含 Swarm 配置、任务列表） |
| `_main_loop()` | 主循环：monitor -> decision -> action |
| `_decision_phase()` | 基于评分和优先级决定执行哪个 Action |

---

## 4. 记忆系统 (QMD - 四层记忆)

| Layer | Name | Persistence | Cleared By |
|-------|------|-------------|------------|
| L1 | Whiteboard | Session-only | 每次 InferenceLoop 完成后清理 |
| L2 | HotMemory | 1-7 days | 手动或 autonomous bundle cleanup |
| L3 | WarmMemory | Daily logs | Processing by autonomous bundles |
| L4 | ColdMemory (QMD) | Permanent | None - archival only |

### 4.1 Whiteboard (L1)
*   Structured workspace for current dialogue
*   Stores: `wb_control`, `wb_plan`, `wb_evidence`, `wb_results`
*   清理：InferenceLoop 完成后自动清空

### 4.2 HotMemory (L2)
*   Short-term memory with Todo List
*   持久化到 `hot_memory.md`
*   编辑：Agents 和 autonomous bundle

### 4.3 WarmMemory (L3)
*   Sequential log of completed loops
*   时间序列记录：`memory/YYYY-MM-DD.md`
*   只读：大多数 Agent

### 4.4 ColdMemory (QMD) (L4)
*   Semantic knowledge base
*   Vector database for long-term learning
*   归档：从 Warm Memory 提取高价值知识 via core.memory_foundation bundle

---

## 5. Supervisor 控制系统 (v1.3 新增)

增强的控制机制防止冲突操作和重复执行：

### 5.1 幂等动作键 (Idempotency Keys)
```python
idempotency_key = f"{action_id}:{chat_id}"
```

### 5.2 阶段锁 (Stage Lock)
```python
stage_lock = {
    "analysis": False,
    "planning": False,
    "execution": False
}
```

### 5.3 提前收敛评分 (Early Finish Scoring)
基于以下维度计算：
- **Task Completion Rate**: 完成的任务比例
- **Confidence Level**: LLM 置信度
- **Consistency Score**: 结果一致性
- **Evidence Coverage**: 证据覆盖度

---

## 6. CLI 自组织路由 (v1.3)

`swarmbot run` 命令使用 LLM 驱动的任务类型识别：

```python
def cmd_run():
    inference_loop = InferenceLoop(cfg, WORKSPACE_PATH)
    # route_mode 决定于问题复杂度（通过 LLM 投票）
```

### 6.1 路由决策流程
1. Analysis Phase: 多个 Planner Agent 分析用户输入
2. Voting: 基于复杂度评分投票选择 routing mode
3. Profile Allocation: 自动调整 worker 数量和 context_limit

---

## 7. 工具/技能系统

| Type | Description |
|------|-------------|
| Tools | 可执行能力 (e.g., web_search, python_exec) |
| Skills | 任务指令文档 (SKILL.md)，指导 Agent 策略 |

**双通道发现**:
- Skill Discovery: skill_summary/skill_load
- Tool Decision: tool gate voting

---

## 8. 文件结构

```
swarmbot/
├── boot/               # System prompts (SOUL.md, swarmboot.md)
├── core/               # Agent & LLM primitives
├── loops/              # Inference loop only
│   ├── inference.py
│   └── definitions.py  # Prompt templates
├── memory/             # Memory classes
│   ├── whiteboard.py
│   ├── hot_memory.py
│   ├── warm_memory.py
│   └── cold_memory.py  # QMD wrapper
├── autonomous/         # Self-organizing engine with Bundles
│   └── engine.py
└── gateway/            # Server & Message Bus
```

---

## 9. 配置示例

```json
{
  "providers": [
    {
      "name": "primary",
      "base_url": "http://localhost:8000/v1",
      "api_key": "sk-xxx",
      "model": "qwen3-coder-next",
      "max_tokens": 64000,
      "temperature": 0.6
    }
  ],
  "swarm": {
    "max_agents": 4,
    "roles": ["planner", "coder", "critic", "summarizer"],
    "architecture": "auto",
    "max_turns": 16,
    "display_mode": "simple"
  },
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3
  }
}
```
