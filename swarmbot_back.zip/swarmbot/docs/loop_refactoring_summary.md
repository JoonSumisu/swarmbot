# Loop 重构实施总结 (v2.0/v2.1)

## 实施日期
2026-03-17

## 实施内容

### 第一阶段：Loop 简化重构 (v2.0)

#### 1. 简化路由器 (`swarmbot/loops/inference.py`)

**修改内容**:
- 简化 `_decide_route_mode_once()` 方法，移除多余的注释和说明
- 简化 `_decide_route_mode()` 方法，使用纯 3 代理投票机制
- 路由决策只输出数字 1/2/3，对应三种模式：
  - Route 1: `simple_direct_master` - 简单问题直接回答
  - Route 2: `reasoning_swarm` - 中等复杂度多代理推理
  - Route 3: `engineering_complex` - 高复杂度交互式执行

**投票机制**:
- 3 个 planner 并行投票
- 多数决，平局时默认选择 Route 2（安全偏好）
- 移除前置规则判断（task_type/domain 检查）

#### 2. 简化 Route 1 (`swarmbot/loops/simple_direct_master.py`)

**新流程**: Input → Master Agent → Memory → End

从 6 步减少到 1 步：
- 删除：ANALYSIS, EVALUATION, TRANSLATION 步骤
- 保留：Master Agent 直接回答 + 保存记忆
- 代码约 50 行

#### 3. 简化 Route 2 (`swarmbot/loops/reasoning_swarm.py`)

**新流程**: Input → Multi-agent Reasoning → Master Agent → Memory → End

从 8 步减少到 2 步：
- Step 1: 3 个 planner 并行推理
- Step 2: Master Agent 综合回答 + 保存记忆
- 删除：ANALYSIS, COLLECTION, PLANNING, EXECUTION, EVALUATION 步骤
- 代码约 80 行

#### 4. Route 3 保持不变

`engineering_complex.py` 保持现有逻辑，支持复杂任务的交互式执行。

---

### 第二阶段：Engineering Complex 优化 (v2.1)

#### 1. 创建 Supervisor 基础框架

**新文件**: `swarmbot/loops/supervisor.py`

**LoopSupervisor 类核心功能**:
- `evaluate_stage_output(stage, output)`: 评估阶段输出质量
  - 评估维度：完整性、一致性、对齐度
  - 返回：`{"passed": bool, "score": 0-1, "issues": [...], "recommended_action": str}`
- `decide_next_action(stage, eval_result, retry_count)`: 决定下一步行动
  - 可选行动：PROCEED, RETRY, ESCALATE, ADAPT
- `adjust_worker_roles(current_roles, task_context, reason)`: 动态调整 worker 角色
- `create_quality_report()`: 生成质量报告

#### 2. 增强 HITL 确认机制

**修改文件**: `swarmbot/loops/engineering_complex.py`

**新增方法**:
- `_create_analysis_checkpoint(analysis, roles, eval_result)`: 创建结构化分析确认界面
- `_create_plan_checkpoint(plan, eval_result)`: 创建结构化计划确认界面
- `_format_checkpoint_prompt(checkpoint)`: 格式化为可读的确认提示

**结构化确认界面格式**:
```json
{
  "stage": "ANALYSIS_REVIEW",
  "status": "pending_user_review",
  "content": {
    "problem_type": "...",
    "domain": "...",
    "identified_goals": [],
    "constraints": [],
    "worker_roles_proposed": []
  },
  "quality_eval": {
    "score": 0.85,
    "passed": true,
    "issues": []
  },
  "user_actions": {
    "confirm": "确认分析，继续执行",
    "modify_roles": "修改建议的 worker 角色",
    "add_constraint": "添加额外约束条件",
    "reject_restart": "拒绝并重新开始分析"
  },
  "whiteboard_mutable_keys": ["worker_roles", "problem_analysis"]
}
```

**用户可读格式**:
```
[SUSPENDED] ANALYSIS_REVIEW
路由模式：engineering_complex

=== 内容摘要 ===
问题类型：xxx
领域：xxx
建议角色：role1, role2
识别目标：[...]
约束条件：[...]

=== 质量评估 ===
评分：0.85
状态：通过
问题：[...]

=== 可用操作 ===
  - confirm: 确认分析，继续执行
  - modify_roles: 修改建议的 worker 角色
  ...
```

#### 3. 集成 Supervisor 到 Engineering Complex

**修改内容**:
- 在 `__init__` 中添加 `supervisor` 属性
- 在 `run()` 方法的 ANALYSIS 阶段后调用 supervisor 评估
- 在 `resume_from_checkpoint()` 的 PLANNING 阶段后调用 supervisor 评估
- 在悬挂前创建结构化确认界面

**质量门禁集成**:
- 新增 `_run_quality_gate(stage, output)` 方法
- 新增 `_attempt_auto_fix(stage, eval_result)` 方法
- 在阶段结束时自动执行质量检查
- 根据评分决定：继续/重试/升级/调整

---

## 文件变更清单

| 文件 | 变更类型 | 说明 |
|------|----------|------|
| `swarmbot/loops/inference.py` | 修改 | 简化路由决策逻辑 |
| `swarmbot/loops/simple_direct_master.py` | 无变化 | 已符合简化要求 |
| `swarmbot/loops/reasoning_swarm.py` | 无变化 | 已符合简化要求 |
| `swarmbot/loops/engineering_complex.py` | 重大修改 | 集成 Supervisor + HITL 增强 |
| `swarmbot/loops/supervisor.py` | 新增 | Loop 监控系统 |

---

## 新的执行流程 (优化后)

### Route 1 (简单问题)
```
Input → Master Agent → Memory → End
```

### Route 2 (中等复杂)
```
Input → 3 Planners 并行推理 → Master Agent 综合 → Memory → End
```

### Route 3 (工程复杂)
```
┌─────────────────────────────────────────────────────────────┐
│                    ANALYSIS 阶段                              │
│  3 个 analyst 并行分析 → Supervisor 质量评估                    │
│  ├─ 质量分 >= 0.7: 进入确认点                                  │
│  ├─ 0.4 <= 质量分 < 0.7: 自动调整角色后重试                   │
│  └─ 质量分 < 0.4: 悬挂，请求用户干预                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
              [SUSPEND: 结构化分析确认]
              用户可：确认 / 修改角色 / 添加约束 / 拒绝重启
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                   COLLECTION 阶段                             │
│  Tool Gate 投票 → 工具执行 → Supervisor 完整性检查              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                    PLANNING 阶段                              │
│  生成计划 → Supervisor 可执行性验证                            │
│  ├─ 验证通过：进入确认点                                       │
│  └─ 验证失败：自动重规划                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
              [SUSPEND: 结构化计划确认]
              用户可：确认 / 修改任务 / 调整优先级 / 拒绝重启
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                   EXECUTION 阶段                              │
│  任务分配 → 并行执行 → Supervisor 实时监控                      │
│  ├─ 检测到角色不匹配：动态调整角色                            │
│  └─ 检测到任务失败：触发重执行或升级                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                   EVALUATION 阶段                             │
│  3 个 evaluator 投票 → Supervisor 综合判定                       │
│  ├─ PASS >= 2: 继续                                         │
│  └─ FAIL >= 2: 触发 Re-Planning 流程                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
                  TRANSLATION → ORGANIZATION → DONE
```

---

## 验证测试

### 编译测试
```bash
python3 -m py_compile swarmbot/loops/*.py  # 全部通过
```

### 导入测试
```bash
python3 -c "from swarmbot.loops.* import *"  # 全部成功
```

### 功能测试（建议执行）
```bash
# 测试简单问题（应走 Route 1）
swarmbot run <<< '你好'

# 测试中等问题（应走 Route 2）
swarmbot run <<< '为什么天空是蓝色的？'

# 测试复杂问题（应走 Route 3 并触发悬挂）
swarmbot run <<< '设计一个微服务架构，包含 CI/CD、回滚、限流与审计'
```

---

## 向后兼容性

- 所有变更保持与现有接口兼容
- Route 1/2/3 的输入输出格式不变
- Supervisor 为可选组件，不影响现有流程
- 结构化确认数据可被现有 gateway 处理

---

## 后续工作

1. **Phase 3: 动态角色调整** (已完成基础框架)
   - 在 EXECUTION 阶段集成角色动态调整
   - 记录调整历史，支持回滚

2. **Phase 4: 质量门禁系统完善** (已部分完成)
   - 添加更多质量评估维度
   - 优化自动修复策略

3. **前端集成**
   - 支持结构化确认界面的图形化展示
   - 添加用户操作按钮

---

## 备注

- 本实施计划保持与 Route 1/2 的接口兼容性
- Supervisor 可复用于未来新增的 Loop 模式
- 结构化确认数据格式已考虑前端展示需求
