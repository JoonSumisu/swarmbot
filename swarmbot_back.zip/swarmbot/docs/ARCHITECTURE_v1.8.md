# Swarmbot v1.8 架构文档

> 文档版本：1.8.0
> 更新日期：2026-03-18
> 最后 commit：2329b7c feat(skill): 新增任务管理与优化技能文档

---

## 目录

1. [整体架构概览](#1-整体架构概览)
2. [被动思考：InferenceLoop 流程](#2-被动思考-inferenceloop-流程)
3. [主动思考：Autonomous Engine 流程](#3-主动思考-autonomous-engine-流程)
4. [Gate-MasterAgent 统一编排](#4-gate-masteragent-统一编排)
5. [记忆系统：QMD 四层架构](#5-记忆系统-qmd-四层架构)
6. [记忆穿插机制](#6-记忆穿插机制)
7. [SkillPool 技能固化](#7-skillpool-技能固化)
8. [Bundle 治理与生命周期](#8-bundle-治理与生命周期)

---

## 1. 整体架构概览

### 1.1 双引擎架构

Swarmbot v1.8 采用**双引擎驱动**架构：

```
┌─────────────────────────────────────────────────────────────────┐
│                        Gateway Server                           │
│  (HTTP Server + Message Bus + Priority Queue + OutputBuffer)    │
└─────────────────────────────────────────────────────────────────┘
                              │
            ┌─────────────────┴─────────────────┐
            │                                   │
            ▼                                   ▼
┌───────────────────────┐           ┌───────────────────────────┐
│   Inference Loop      │           │   Autonomous Engine       │
│   (被动思考)           │           │   (主动思考)              │
│                       │           │                           │
│ • 用户请求触发         │           │ • 后台定时触发             │
│ • 8 步推理流程          │           │ • Bundle 执行              │
│ • LLM 驱动路由          │           │ • 监控->决策->行动          │
│ • 自我组织任务认领     │           │ • 技能生成与固化           │
└───────────────────────┘           └───────────────────────────┘
            │                                   │
            └─────────────────┬─────────────────┘
                              │
                              ▼
                ┌─────────────────────────┐
                │    SharedContextPool    │
                │    (上下文共享池)        │
                │  context_memory.md      │
                └─────────────────────────┘
                              │
            ┌─────────────────┼─────────────────┐
            │                 │                 │
            ▼                 ▼                 ▼
    ┌───────────────┐ ┌───────────────┐ ┌───────────────┐
    │  Whiteboard   │ │   HotMemory   │ │  WarmMemory   │
    │     (L1)      │ │     (L2)      │ │     (L3)      │
    └───────────────┘ └───────────────┘ └───────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │  ColdMemory     │
                    │  (QMD, L4)      │
                    └─────────────────┘
```

### 1.2 核心组件矩阵

| 组件 | 文件 | 类型 | 触发方式 | 频率 |
|------|------|------|----------|------|
| **GatewayServer** | `gateway/server.py` | HTTP 服务器 | 手动/daemon | 持续运行 |
| **GatewayMasterAgent** | `gateway/orchestrator.py` | 消息编排器 | 每个 inbound message | 按需 |
| **OutputBuffer** | `gateway/orchestrator.py` | 智能缓冲 | 消息到达 | 动态刷新 |
| **SharedContextPool** | `gateway/orchestrator.py` | 上下文共享 | Bundle 执行后 | 实时更新 |
| **InferenceLoop** | `loops/inference.py` | 推理引擎 | 用户请求 | 按需 |
| **AutonomousEngine** | `autonomous/engine.py` | 自主引擎 | 后台 tick | 30s 间隔 |
| **BundleGovernor** | `autonomous/engine.py` | Bundle 治理 | 定期评估 | 5min 间隔 |
| **SkillPool** | `skill_pool.py` | 技能固化 | 高质量执行后 | 按需 |

### 1.3 核心 Bundle

| Bundle ID | 间隔 | 职责 | 关键指标 |
|-----------|------|------|----------|
| `core.memory_foundation` | 30min | 记忆压缩与 QMD 归档 | compression_rate, retrieval_accuracy |
| `core.boot_optimizer` | 20min | Boot 提示词优化 | boot_prompt_score |
| `core.system_hygiene` | 10min | 系统健康监控 | cpu_usage, disk_free_ratio, api_success_rate |
| `core.bundle_governor` | 5min | Bundle 冲突检测与效能评估 | efficiency_score |

---

## 2. 被动思考：InferenceLoop 流程

### 2.1 8 步推理流程

```
用户输入 → [ANALYSIS] → [COLLECTION] → [PLANNING] → [INFERENCE] → [EVALUATION] → [TRANSLATION] → [ORGANIZATION] → 输出
              │              │              │              │              │              │              │
              │              │              │              │              │              │              │
           问题分析        信息收集        行动规划        推理执行        评估验证        输出生成        记忆归档
        (无工具)      (可启用工具)      (无工具)      (自组织认领)    (投票判定)    (可启用工具)    (无工具)
```

### 2.2 各阶段详解

#### Step 1: Route Decision (路由决策)

```python
# 简单对话检测 - 直接走 MasterAgent 快速路径
if _should_use_simple_direct(user_input):
    return _run_simple_direct_master(user_input)

# LLM 驱动 Loop Profile 决策
selected_profile = _decide_loop_profile()  # lean / balanced / swarm_max
```

| Profile | analysis_workers | collection_workers | evaluation_workers | max_eval_loops | context_limit |
|---------|------------------|-------------------|-------------------|----------------|---------------|
| lean | 1 | 1 | 2 | 2 | 3500 |
| balanced (default) | 2 | 2 | 3 | 3 | 6000 |
| swarm_max | 3 | 3 | 3 | 3 | 9000 |

#### Step 2: ANALYSIS (问题分析)

**目标**: 分析用户问题类型、领域、意图、复杂度

**特征**:
- 无工具调用
- 多 worker 并行分析
- 自定义角色 (self_defined_role)
- 输出工具建议

```python
results = _run_parallel(prompt, analysis_workers, "analyst", enable_tools=False)
merged = {}
worker_roles = []
for r in results:
    data = json.loads(_extract_json(r))
    merged.update(data)
    if data.get("self_defined_role"):
        worker_roles.append(data["self_defined_role"])
```

#### Step 3: COLLECTION (信息收集)

**目标**: 收集上下文信息，验证物理假设

**特征**:
- **Tool Gate 决策**: 由 LLM 投票决定是否启用工具
- 记忆快照：Hot/Warm/Cold Memory
- ContextPool 状态查询 (Autonomous Engine 发现)

```python
# Tool Gate 决策
gate = _decide_tool_gate(
    stage="collection",
    user_input=user_input,
    context_json=context_json,
    fallback_tools=["web_search", "browser_open", "browser_read", "file_read"]
)

if gate.get("need_tools"):
    # 启用工具收集外部信息
    tool_results = _run_parallel(prompt, 1, "collector", enable_tools=True)
```

**记忆整合**:
```python
hot = self.hot_memory.read()           # L2 短期记忆
warm = self.warm_memory.read_today()   # L3 今日日志
cold = self.cold_memory.search_text(analysis, limit=5)  # L4 向量检索
context_pool = self._get_context_for_collection(analysis)  # Bundle 状态
```

#### Step 4: PLANNING (行动规划)

**目标**: 创建具体执行计划

**特征**:
- 无工具调用
- 生成任务列表 (tasks)
- 每个任务包含 required_skills

```python
plan = {
    "tasks": [
        {"id": 1, "desc": "...", "required_skills": ["web_search"]},
        {"id": 2, "desc": "...", "required_skills": ["python_exec"]}
    ]
}
```

#### Step 5: INFERENCE (推理执行)

**目标**: 自组织任务认领与执行

**特征**:
- **Self-Organized Task Claim**: Worker 自主认领任务
- 多轮认领机制 (最多 3 轮)
- 基于置信度选择最优认领者

```python
# 任务认领流程
for round_idx in range(1, 4):
    claims = []
    for worker_id in worker_ids:
        claim = _run_claim(worker_id)  # Worker 自主决定认领哪个任务
        claims.append(claim)

    # 按置信度选择最优认领者
    for tid in pending:
        cs = [c for c in claims if c.task_id == tid]
        chosen = sorted(cs, key=lambda x: x.confidence, reverse=True)[0]
        assignments[tid] = chosen
```

**执行**:
```python
def run_task(assign):
    worker = _create_worker(
        assign["role"],
        enable_tools=bool(assign["tools"]),
        allowed_tools=assign["tools"]
    )
    return worker.step(prompt)
```

#### Step 6: EVALUATION (评估验证)

**目标**: 逻辑一致性验证

**特征**:
- 无工具调用
- 多 worker 投票 (PASS/FAIL)
- 自定评估角色 (self_defined_role)

```python
evals = _run_parallel(prompt, evaluation_workers, "evaluator", enable_tools=False)
pass_count = sum(1 for e in evals if e.vote == "PASS")
passed = pass_count >= 2  # 多数投票
```

**失败处理**:
```python
if not passed and i < max_eval_loops - 1:
    _step_replanning(retry_idx=i)  # 调整计划后重试
```

#### Step 7: TRANSLATION (输出生成)

**目标**: 将推理结论转化为用户友好的回答

**特征**:
- Tool Gate 决策 (可能需要外部验证)
- SOUL 人格注入
- 硬约束校验 (物理/逻辑约束)

```python
gate = _decide_tool_gate(stage="translation", ...)
response = _create_worker("master", enable_tools=gate["need_tools"]).step(prompt)

# 约束校验
violations = _response_violates_constraints(user_input, response)
if violations:
    response = _calibrate_final_response(user_input, response)
```

#### Step 8: ORGANIZATION (记忆归档)

**目标**: 反馈循环与记忆更新

**特征**:
- 无工具调用
- HotMemory 追加
- WarmMemory 日志

```python
hot_update = f"\n\n### Loop Update @ {timestamp}\nQ: {user_input[:200]}\nA: {response[:200]}"
hot_memory.update(current_hot + hot_update)

warm_memory.append_log(timestamp, user_input, response[:200], extracted_facts)
```

---

## 3. 主动思考：Autonomous Engine 流程

### 3.1 主循环架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Autonomous Engine                        │
│                                                             │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐       │
│  │  Monitor    │ → │  Decision   │ → │   Action    │       │
│  │   Phase     │   │   Phase     │   │   Phase     │       │
│  └─────────────┘   └─────────────┘   └─────────────┘       │
│         │                  │                  │             │
│         ▼                  ▼                  ▼             │
│  • 执行 due Bundle   • 分析 MonitorEvent  • 执行行动计划    │
│  • 创建 MonitorEvent  • 决定 auto/human   • 记录优化历史    │
│  • 更新 ContextPool  • 生成优化计划       • 技能生成        │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              BundleGovernor (每 5 分钟)               │   │
│  │  • 效能评估  • 自动暂停  • 自动恢复  • 淘汰机制      │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Monitor Phase

**职责**: 检查并执行到期的 Bundle

```python
def _monitor_phase(now_ts):
    for bundle_id, bundle in bundles.items():
        if not _bundle_governor.should_execute(bundle_id):
            continue  # 跳过暂停/淘汰的 Bundle

        if not bundle.due(now_ts):
            continue  # 未到期

        # 执行 Bundle
        result = bundle.execute(workspace_path)

        # 记录执行历史
        _append_memory(bundle_id, "execution_history", result)

        # 评估结果
        eval_result = _evaluate_bundle_result(bundle, result)
        _append_memory(bundle_id, "eval_results", eval_result)

        # 创建 MonitorEvent
        event = _create_monitor_event(bundle, result, eval_result)
        monitor_queue.append(event)

        # 更新 ContextPool (供 InferenceLoop 查询)
        if context_pool:
            status = "success" if eval_result["grade"] == "A" else "warning"
            context_pool.update_sync(bundle_id, status, details)

        # 技能生成 (高质量执行)
        if skill_pool and eval_result["grade"] in ["A", "B"]:
            _try_generate_skill(bundle_id, result, eval_result)
```

### 3.3 Decision Phase

**职责**: 分析 MonitorEvent，决定自动优化还是人工介入

```python
def _decision_phase(now_ts):
    while monitor_queue:
        event = monitor_queue.popleft()
        decision = _analyze_event(event)

        if decision["action"] == "auto_optimize":
            _execute_auto_optimize(event, decision, now_ts)
        elif decision["action"] == "human_in_loop":
            _request_human_input(event, decision, now_ts)
```

**决策逻辑**:
```python
def _analyze_event(event):
    if event.human_in_loop_required:  # Grade D 或 Score < 0.5
        return {"action": "human_in_loop", "questions": ["请提供反馈"]}

    score = event.evidence["eval"]["score"]
    if score < 0.7:
        return {"action": "auto_optimize", "optimization_plan": {...}}

    return {"action": "observe"}
```

### 3.4 Bundle 配置示例

```json
{
  "bundle_id": "core.system_hygiene",
  "objective": "监控系统健康状态，预防资源耗尽",
  "interval_seconds": 600,
  "success_metrics": {
    "disk_free_ratio": {"target": 0.1, "direction": "maximize"},
    "memory_free_ratio": {"target": 0.1, "direction": "maximize"},
    "cpu_usage": {"target": 0.8, "direction": "minimize"},
    "api_success_rate": {"target": 0.95, "direction": "maximize"},
    "bundle_failure_rate": {"target": 0.1, "direction": "minimize"}
  },
  "optimization_targets": [
    {"target_id": "t1", "metric_name": "disk_free_ratio", ...},
    {"target_id": "t2", "metric_name": "api_success_rate", ...}
  ],
  "feedback_loop": {
    "enabled": true,
    "trigger": "on_threshold_breach",
    "via": "gateway"
  }
}
```

---

## 4. Gate-MasterAgent 统一编排

### 4.1 优先级消息队列

```python
class Priority(IntEnum):
    P0_USER_RESPONSE = 0      # 用户消息响应 (最高)
    P1_HUMAN_REQUEST = 1      # 人在回路请求 / 紧急告警
    P2_BUNDLE_REPORT = 2      # Bundle 优化报告
    P3_SYSTEM_INFO = 3        # 系统信息
```

**消息堆结构**:
```python
@dataclass(order=True)
class PrioritizedMessage:
    priority: int
    timestamp: int
    content: str
    msg_type: str
    metadata: Dict[str, Any]
```

### 4.2 OutputBuffer 智能刷新

**刷新决策逻辑**:

| 条件 | 行为 |
|------|------|
| P0 消息 + ≥0.5s | 立即刷新 |
| P1 消息 + ≥0.5s | 立即刷新 |
| 内容 ≥500 字符 | 刷新避免丢失 |
| ≥3 条消息 + ≥1.5s | 刷新 |
| 超时 3s | 强制刷新 |

```python
async def should_flush(self) -> bool:
    has_p0 = any(m.priority == P0 for m in buffer)
    has_p1 = any(m.priority == P1 for m in buffer)
    total_chars = sum(len(m.content) for m in buffer)
    elapsed = time.time() - first_msg_time

    if has_p0 and elapsed >= 0.5: return True
    if has_p1 and elapsed >= 0.5: return True
    if total_chars >= 500: return True
    if len(buffer) >= 3 and elapsed >= 1.5: return True
    if elapsed >= 3.0: return True

    return False  # 继续等待
```

### 4.3 SharedContextPool 上下文共享

**文件存储**: `~/.swarmbot/workspace/context_memory.md`

**数据结构**:
```markdown
# Context Memory - 上下文共享池

## Active Bundle Status

| bundle_id | timestamp | status | details |
|-----------|-----------|--------|---------|
| core.system_hygiene | 1710777600 | warning | CPU 使用率偏高：72.3% |
| core.memory_foundation | 1710777500 | success | OK |
```

**评分公式**:
```
Context Score = 语义相关性 (50%) + 时效性权重 (30%) + 严重性权重 (20%)

时效性：指数衰减，半衰期 30min
严重性：warning/critical 状态优先
```

---

## 5. 记忆系统：QMD 四层架构

### 5.1 记忆层次

| 层级 | 名称 | 持久化 | 清除时机 | 文件位置 |
|------|------|--------|----------|----------|
| L1 | Whiteboard | 会话内 | InferenceLoop 完成 | 内存 |
| L2 | HotMemory | 1-7 天 | 手动/自主清理 | `hot_memory.md` |
| L3 | WarmMemory | 日日志 | 被自主 Bundle 处理 | `memory/YYYY-MM-DD.md` |
| L4 | ColdMemory (QMD) | 永久 | 仅归档 | `qmd/{fact,theory,experience}/` |

### 5.2 记忆流转

```
用户输入 → InferenceLoop → Whiteboard (L1)
                               │
                               ▼
                        Organization Step
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
         HotMemory        WarmMemory      ColdMemory
        (追加上下文)      (日日志)        (向量检索)
              │                │                │
              └────────────────┼────────────────┘
                               │
                               ▼
                    Autonomous Bundle
               (core.memory_foundation)
                       │
                       ▼
                 压缩/归档到 QMD
```

### 5.3 记忆文件结构

**HotMemory** (`hot_memory.md`):
```markdown
# Hot Memory

## Past (Recent)
...

## Present
...

## Future
...

## Todo List
- [ ] 待办任务 1
- [ ] 待办任务 2
```

**WarmMemory** (`memory/YYYY-MM-DD.md`):
```markdown
## Entry [14:30:25] Loop: 1710777600
### Input
用户问题...

### Conclusion
回答摘要...

### Facts
- 事实 1
- 事实 2
```

**ColdMemory** (`qmd/core_memory/memory_*.md`):
```markdown
# Memory

Type: fact/theory/experience
Derived from: 2026-03-04
Tags: [python, debugging, testing]

Content: ...
```

---

## 6. 记忆穿插机制

### 6.1 Collection 阶段的记忆检索

在 InferenceLoop 的 COLLECTION 阶段，系统会同时检索所有记忆层：

```python
# L2: Hot Memory - 最近上下文
hot = self.hot_memory.read()  # 最近事件、待办

# L3: Warm Memory - 今日日志
warm = self.warm_memory.read_today()  # 今日对话历史

# L4: Cold Memory - 向量检索
cold = self.cold_memory.search_text(analysis, limit=5)  # 相关知识

# ContextPool - Bundle 发现
context_pool = self._get_context_for_collection(analysis)
```

### 6.2 ContextPool 相关性匹配

```python
domain_keywords = {
    "security": ["security", "system_hygiene", "health"],
    "performance": ["performance", "optimizer", "boot"],
    "memory": ["memory", "qmd", "archive"],
    "code": ["code", "developer", "engineer"],
}

for bundle_id, status_data in all_status.items():
    for keyword in domain_keywords.get(domain, []):
        if keyword in bundle_id.lower():
            relevant_bundles.append((bundle_id, status_data))
```

### 6.3 Organization 阶段的记忆写入

```python
# HotMemory 追加
hot_update = f"\n\n### Loop Update @ {timestamp}\nQ: {input}\nA: {response}"
hot_memory.update(current_hot + hot_update)

# WarmMemory 日志
warm_memory.append_log(loop_id, input, summary, extracted_facts)
```

---

## 7. SkillPool 技能固化

### 7.1 技能生成流程

```
Bundle 执行 (高质量)
        │
        ▼
执行轨迹分析 (ExecutionTraceAnalysis)
        │
        ├── 关键决策点识别
        ├── 工具序列提取
        ├── 成功/失败因素分析
        │
        ▼
可复用性评分 (0.0 - 1.0)
        │
        ├── 决策点数量 (适中=高分)
        ├── 工具多样性
        ├── 执行长度
        ├── 成功因素数量
        │
        ▼
评分 ≥ 0.6 → 生成 Skill
        │
        ▼
保存到 ~/.swarmbot/skills/SKILL-{id}.md
```

### 7.2 可复用性评分公式

```python
score = 0.5  # 基础分

# 决策点评分 (0-0.2)
if 2 <= num_decisions <= 8: score += 0.2  # 适中
elif 1 <= num_decisions <= 10: score += 0.1

# 工具多样性评分 (0-0.2)
if unique_tools >= 3: score += 0.2
elif unique_tools >= 2: score += 0.15

# 执行长度评分 (0-0.2)
if 3 <= execution_length <= 15: score += 0.2

# 成功因素评分 (0-0.2)
if num_factors >= 3: score += 0.2
```

### 7.3 技能使用

```python
# InferenceLoop 在 PLANNING/INFERENCE 阶段调用
skills = skill_pool.get_skills_for_task(
    role="collector",
    task_desc="收集网络信息",
    required_skills=["web_search"]
)
```

---

## 8. Bundle 治理与生命周期

### 8.1 BundleGovernor 效能评估

**评估维度**:
```
效能评分 = 成功率 (30%) + 时间效率 (20%) + 价值产出 (30%) + 资源效率 (20%)

成功率 = A/B 级执行数 / 总执行数
时间效率 = f(平均执行时间)
价值产出 = min(1.0, (技能数×0.5 + 解决数) / 执行数)
资源效率 = 1 - (最近失败数 / 5)
```

### 8.2 生命周期状态机

```
        ┌─────────┐
        │ active  │
        └────┬────┘
             │
    ┌────────┼────────┐
    │        │        │
    ▼        ▼        ▼
 暂停      优化     淘汰
(paused) (optimize) (retired)
    │
    ▼
 自动恢复
 (30min 后)
```

### 8.3 阈值与行动

| 效能评分 | 行动 | 说明 |
|----------|------|------|
| < 0.15 | retire | 淘汰 Bundle |
| 0.15 - 0.3 | pause | 暂停 Bundle |
| 0.3 - 0.5 | optimize | 需要优化 |
| ≥ 0.5 | keep | 保持运行 |

### 8.4 自动恢复机制

```python
def _try_resume_bundle(bundle_id):
    recent_evals = evaluation_history[bundle_id][-3:]
    avg_score = sum(e.efficiency_score for e in recent_evals) / len(recent_evals)

    if avg_score >= EFFICIENCY_PAUSE_THRESHOLD + 0.1:
        paused_bundles.discard(bundle_id)
        lifecycle_states[bundle_id].state = "active"
        return True
    return False
```

---

## 附录 A: 关键文件路径

```
~/.swarmbot/
├── config.json                 # 主配置
├── boot/
│   ├── SOUL.md                 # 人格定义
│   ├── swarmboot.md            # 系统规则
│   ├── masteragentboot.md      # MasterAgent Boot
│   └── ...
├── bundles/
│   ├── core.memory_foundation/
│   ├── core.boot_optimizer/
│   ├── core.system_hygiene/
│   └── core.bundle_governor/
├── workspace/
│   ├── hot_memory.md           # L2 记忆
│   ├── memory/                 # L3 日日志
│   ├── qmd/                    # L4 QMD
│   ├── context_memory.md       # ContextPool
│   └── HEARTBEAT.md            # 待办任务
├── skills/                     # 技能库
└── logs/                       # 日志
```

## 附录 B: 配置示例

```json
{
  "providers": [...],
  "swarm": {
    "max_agents": 4,
    "architecture": "auto",
    "max_turns": 16
  },
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3,
    "default_locked_bundles": [
      "core.memory_foundation",
      "core.boot_optimizer",
      "core.system_hygiene",
      "core.bundle_governor"
    ]
  },
  "daemon": {
    "manage_gateway": true,
    "manage_autonomous": true
  }
}
```

## 附录 C: 术语表

| 术语 | 定义 |
|------|------|
| Bundle | 自主执行的文件夹单元，包含配置、脚本、记忆 |
| ContextPool | 上下文共享池，Bundle 与 InferenceLoop 共享状态 |
| InferenceLoop | 用户请求触发的 8 步推理流程 |
| MonitorEvent | Bundle 执行后创建的监控事件 |
| QMD | Quad Memory Database，四层记忆数据库 |
| SkillPool | 技能固化池，从执行经验中提取可复用模式 |
| Tool Gate | LLM 驱动的工具启用/禁用决策 |
| Whiteboard | L1 临时工作区，InferenceLoop 内共享 |

---

*文档结束*
