# Swarmbot Architecture (v1.3)

## Overview
Swarmbot is a self-organizing multi-agent collective intelligence system designed for complex problem solving and long-term memory retention. It operates on an Autonomous Engine architecture with Bundle-based background tasks, supported by a 4-Layer Memory System.

## 🧠 4-Layer Memory System

| Layer | Name | Persistence | Description | Storage |
|:---:|:---:|:---:|:---|:---|
| **L1** | **Whiteboard** | Session (Volatile) | Structured workspace for the current dialogue. Stores prompt analysis, plans, execution results, and evaluations. Cleared after each loop. | Memory Object |
| **L2** | **Hot Memory** | Short-term (1-7 days) | Context for recent past, present focus, future plans, and **Todo List**. Edited by agents and autonomous bundles. | `hot_memory.md` |
| **L3** | **Warm Memory** | Sequential Log | Time-series record of all completed inference loops (Input + Conclusion + Facts). Read-only for most agents. | `memory/YYYY-MM-DD.md` |
| **L4** | **Cold Memory** | Long-term (Permanent) | Semantic knowledge base (Facts, Experiences, Theories) derived from Warm Memory via memory_foundation Bundle. | QMD (Vector DB) |

---

## 🔄 Autonomous Engine Architecture

### Inference Loop (The "Fast" Loop)
Triggered by user input (Feishu/CLI).
**Steps:**
1.  **Ingress**: Receive message.
2.  **Analysis**: LLM-driven routing decides optimal mode (simple_direct_master/reasoning_swarm/engineering_complex) via multi-agent voting
3.  **Collection**: Workers gather context (L2/L3/L4 + Web) -> Whiteboard.
4.  **Planning**: Planner creates execution plan with framework_doc validation -> Whiteboard.
5.  **Execution**: Workers execute tools/tasks -> Whiteboard.
6.  **Evaluation**: Evaluators vote on results with early finish scoring. Retry up to max_eval_loops.
7.  **Translation**: Master Agent formats final response.
8.  **Organization**: Master Agent updates L2/L3 memories.

**Runtime Guards**
- Gateway handles each inbound request with an isolated `InferenceLoop` instance to avoid cross-session whiteboard contamination.
- Outbound delivery is dispatched asynchronously and retried on transient dispatch failures.
- If inference fails, gateway still emits a fallback outbound response instead of silently dropping the user request.

### Autonomous Engine (Background Tasks)
Self-organizing system using Bundle pattern:

| Bundle | Purpose | Interval |
|--------|---------|----------|
| `core.memory_foundation` | Memory compression and QMD archival | 30 minutes |
| `core.boot_optimizer` | Boot prompt optimization | 20 minutes |
| `core.system_hygiene` | System health monitoring | 10 minutes |
| `core.bundle_governor` | Bundle conflict detection | 5 minutes |

**Architecture**
- **MonitorQueue**: Events from Bundle checks
- **ActionQueue**: Approved actions with Swarm profiles, task lists, retry policies
- **Self-Organizing**: Agents dynamically allocate based on task requirements (no fixed agent roles)

---

## 🔎 Observability Checklist

- **Ingress:** Feishu receive log exists (`[Feishu] Received message ...`).
- **Inference:** loop enters Step 2~8 and records CoT/tool-call traces. Routing mode decided by LLM voting.
- **Egress:** outbound message published and dispatched to channel subscriber.
- **Channel Delivery:** Feishu send success log appears; if card send fails, text fallback path is attempted.
- **MemoryMap (EvoMap):** `context_policy_update` / `whiteboard_update` can mutate whiteboard keys during runtime.

---

## 📂 File Structure
```
swarmbot/
├── boot/               # System prompts (SOUL.md, swarmboot.md, masteragentboot.md)
├── core/               # Agent & LLM primitives
├── loops/              # Inference loop only
│   ├── inference.py
│   └── definitions.py  # Prompt templates
├── memory/             # Memory classes
│   ├── whiteboard.py
│   ├── hot_memory.py
│   ├── warm_memory.py
│   └── cold_memory.py  # QMD wrapper
├── autonomous/         # Self-organizing engine with Bundles
│   └── engine.py
└── gateway/            # Server & Message Bus
```
