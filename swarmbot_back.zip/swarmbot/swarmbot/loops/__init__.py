"""Loop mode implementations for Swarmbot (v2.0)."""

from .base import InferenceLoopBase
from .inference_standard import InferenceLoopStandard
from .inference_supervised import InferenceLoopSupervised
from .swarms_worker import SwarmsWorker

# v2.0: InferenceLoop Standard/Supervised and SwarmsWorker are tools called by MasterAgent
# Old routing modules (simple_direct_master, reasoning_swarm, engineering_complex, router) removed

__all__ = [
    "InferenceLoopBase",
    "InferenceLoopStandard",
    "InferenceLoopSupervised",
    "SwarmsWorker",
]
