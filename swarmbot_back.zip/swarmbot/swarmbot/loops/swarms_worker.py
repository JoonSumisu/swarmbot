"""
SwarmsWorker - 多 Worker 协作推理工具

适用于需要多视角分析的复杂任务。
功能：
- 动态生成 3-9 个 Worker
- Worker 自动分配角色（互不冲突）
- 多轮沟通投票（10 轮内出结果）
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from ..config_manager import load_config
from ..llm_client import OpenAICompatibleClient
from ..memory.whiteboard import Whiteboard
from ..memory.hot_memory import HotMemory
from ..memory.warm_memory import WarmMemory
from ..memory.cold_memory import ColdMemory
from .definitions import *
from .skill_registry import SkillRegistry

# Import Gateway-MasterAgent components
try:
    from ..gateway.orchestrator import SharedContextPool
    from ..skill_pool import SkillPool
except ImportError:
    SharedContextPool = None
    SkillPool = None


class SwarmsWorker:
    """多 Worker 协作推理工具"""

    # Worker 角色池 - 确保角色多样性
    ROLE_POOL = [
        "analyst",      # 分析师 - 拆解问题
        "planner",      # 规划师 - 制定策略
        "executor",     # 执行者 - 具体实施
        "critic",       # 评论家 - 找出问题
        "researcher",   # 研究员 - 查找信息
        "writer",       # 作家 - 整理输出
        "engineer",     # 工程师 - 技术方案
        "designer",     # 设计师 - 用户体验
        "mediator",     # 协调者 - 综合观点
    ]

    def __init__(self, config, workspace_path: str):
        self.config = config
        self.workspace_path = Path(workspace_path)
        self.llm = OpenAICompatibleClient.from_provider(providers=config.providers)

        # Memories
        self.whiteboard = Whiteboard()
        self.hot_memory = HotMemory(workspace_path)
        self.warm_memory = WarmMemory(workspace_path)
        self.cold_memory = ColdMemory()
        self.skill_registry = SkillRegistry()

        # Gateway-MasterAgent integration
        self.context_pool = SharedContextPool(self.workspace_path) if SharedContextPool else None
        self.skill_pool = SkillPool.get_instance() if SkillPool else None

        # Load boot files
        self.swarmboot = self._load_boot_file("swarmboot.md")
        self.soul = self._load_boot_file("SOUL.md")

        # Execution state
        self.is_suspended = False
        self.suspended_stage = None

    def _load_boot_file(self, filename: str) -> str:
        """Load boot file from disk."""
        paths = [
            os.path.expanduser(f"~/.swarmbot/boot/{filename}"),
            os.path.join(os.path.dirname(__file__), f"../boot/{filename}")
        ]
        for p in paths:
            if os.path.exists(p):
                return open(p, "r", encoding="utf-8").read()
        return ""

    def _create_worker(
        self,
        role: str,
        enable_tools: bool = True,
        allowed_tools: List[str] | None = None,
        task_desc: str = "",
        required_skills: List[str] | None = None,
    ) -> Any:
        """Create a worker agent."""
        if self.skill_pool:
            skills = self.skill_pool.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)
        else:
            skills = self.skill_registry.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)

        if allowed_tools is not None:
            allowed = set(allowed_tools) | {"whiteboard_update", "hot_memory_update"}
            skills = {k: v for k, v in skills.items() if k in allowed}

        from ..core.agent import CoreAgent, AgentContext
        ctx = AgentContext(agent_id=f"swarm-{role}-{time.time_ns()}", role=role, skills=skills)
        return CoreAgent(ctx, self.llm, self.cold_memory, hot_memory=self.hot_memory, enable_tools=enable_tools)

    def _safe_dumps(self, data: Any, max_len: int = 4000) -> str:
        """Safely dump data to JSON string."""
        def truncate(obj):
            if isinstance(obj, str):
                return obj[:max_len] + "..." if len(obj) > max_len else obj
            if isinstance(obj, list):
                return [truncate(x) for x in obj]
            if isinstance(obj, dict):
                return {k: truncate(v) for k, v in obj.items()}
            return obj
        try:
            return json.dumps(truncate(data), ensure_ascii=False)
        except:
            return "{}"

    def _extract_json(self, text: str) -> str:
        """Extract JSON block from text."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else "{}"

    def _decide_worker_count(self, user_input: str, complexity: str = "medium") -> int:
        """Decide number of workers based on task complexity."""
        # Analyze complexity
        prompt = (
            "你是任务复杂度评估器。\n"
            f"用户问题：{user_input}\n\n"
            "评估任务复杂度，输出适合的 Worker 数量（3-9 个）。\n"
            "原则：\n"
            "- 3-4 个：简单问题，单一领域\n"
            "- 5-6 个：中等复杂度，多领域\n"
            "- 7-9 个：高复杂度，需要多角度验证\n"
            '输出 JSON: {"worker_count": 5, "reason": "..."}'
        )
        res = self._create_worker("planner", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            count = int(data.get("worker_count") or 5)
            return max(3, min(9, count))  # Clamp to 3-9
        except:
            # Default based on input length
            if len(user_input) < 50:
                return 3
            elif len(user_input) < 200:
                return 5
            else:
                return 7

    def _assign_unique_roles(self, worker_count: int, user_input: str) -> List[Dict[str, str]]:
        """Assign unique roles to workers based on task requirements."""
        # Select roles from pool
        prompt = (
            "你是角色分配器。\n"
            f"用户问题：{user_input}\n"
            f"可用角色：{', '.join(self.ROLE_POOL)}\n"
            f"需要分配：{worker_count} 个独特角色\n\n"
            "选择最适合的角色组合，确保角色之间不冲突且能互补。\n"
            '输出 JSON: {"roles": ["analyst", "planner", ...], "rationale": "..."}'
        )
        res = self._create_worker("mediator", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            selected_roles = data.get("roles", self.ROLE_POOL[:worker_count])
            # Ensure unique roles
            selected_roles = list(dict.fromkeys(selected_roles))[:worker_count]
            # Fill in if not enough
            while len(selected_roles) < worker_count:
                for role in self.ROLE_POOL:
                    if role not in selected_roles:
                        selected_roles.append(role)
                        if len(selected_roles) >= worker_count:
                            break
            return [{"worker_id": f"worker_{i+1}", "role": role} for i, role in enumerate(selected_roles)]
        except:
            # Fallback: assign first N roles
            return [{"worker_id": f"worker_{i+1}", "role": self.ROLE_POOL[i]} for i in range(worker_count)]

    def run(self, user_input: str, session_id: str) -> str:
        """执行多 Worker 协作推理"""
        print(f"[SwarmsWorker] Start: {user_input[:50]}...")

        # Initialize
        self.whiteboard.clear()
        self.whiteboard.update("metadata", {"session_id": session_id, "loop_id": str(int(time.time()))})
        self.whiteboard.update("input_prompt", user_input)

        # Step 1: Decide worker count
        worker_count = self._decide_worker_count(user_input)
        print(f"[SwarmsWorker] Decided worker count: {worker_count}")
        self.whiteboard.update("worker_count", worker_count)

        # Step 2: Assign unique roles
        role_assignments = self._assign_unique_roles(worker_count, user_input)
        print(f"[SwarmsWorker] Assigned roles: {[r['role'] for r in role_assignments]}")
        self.whiteboard.update("role_assignments", role_assignments)

        # Step 3: Multi-round communication and voting (max 10 rounds)
        max_rounds = 10
        discussion_history: List[Dict[str, Any]] = []
        final_vote: Optional[Dict[str, Any]] = None

        for round_idx in range(1, max_rounds + 1):
            print(f"[SwarmsWorker] Round {round_idx}/{max_rounds}...")

            # Each worker contributes
            round_contributions = self._run_worker_round(
                worker_count=worker_count,
                role_assignments=role_assignments,
                user_input=user_input,
                discussion_history=discussion_history,
                round_idx=round_idx
            )

            discussion_history.extend(round_contributions)
            self.whiteboard.update("discussion_history", discussion_history)

            # Check if consensus reached
            vote_result = self._check_consensus(round_contributions, discussion_history)
            if vote_result.get("consensus_reached"):
                print(f"[SwarmsWorker] Consensus reached in round {round_idx}")
                final_vote = vote_result
                break

            # If last round, force vote
            if round_idx == max_rounds:
                print("[SwarmsWorker] Final forced vote...")
                final_vote = self._force_final_vote(discussion_history, user_input)

        # Step 4: Synthesize final response
        final_response = self._synthesize_response(final_vote, discussion_history, user_input)

        # Save to memory
        self._save_to_memory(user_input, final_response, discussion_history)

        print(f"[SwarmsWorker] Complete: {final_response[:50]}...")
        return final_response

    def _run_worker_round(
        self,
        worker_count: int,
        role_assignments: List[Dict[str, str]],
        user_input: str,
        discussion_history: List[Dict[str, Any]],
        round_idx: int
    ) -> List[Dict[str, Any]]:
        """Run one round of worker contributions."""
        contributions = []

        def run_worker(worker_info: Dict[str, str]) -> Dict[str, Any]:
            worker_id = worker_info["worker_id"]
            role = worker_info["role"]

            # Build prompt based on round
            if round_idx == 1:
                # First round: initial analysis
                prompt = (
                    f"你是{role}角色的 Worker。\n"
                    f"任务：分析并回答用户问题。\n"
                    f"用户问题：{user_input}\n\n"
                    "请从你的专业视角提供分析和见解。\n"
                    '输出 JSON: {"worker_id": "...", "role": "...", "contribution": "...", "confidence": 0.8}'
                )
            elif round_idx == 2:
                # Second round: build on others' contributions
                prev_contributions = "\n".join([
                    f"- {c.get('role', '?')}: {c.get('contribution', '')[:200]}"
                    for c in discussion_history[-worker_count:]
                ])
                prompt = (
                    f"你是{role}角色的 Worker。\n"
                    f"用户问题：{user_input}\n\n"
                    f"其他 Worker 的观点:\n{prev_contributions}\n\n"
                    "请补充、完善或提出不同视角的见解。\n"
                    '输出 JSON: {"worker_id": "...", "role": "...", "contribution": "...", "confidence": 0.8}'
                )
            else:
                # Later rounds: focus on resolving disagreements
                disagreements = self._identify_disagreements(discussion_history)
                prompt = (
                    f"你是{role}角色的 Worker。\n"
                    f"用户问题：{user_input}\n\n"
                    f"待解决的分歧:\n{disagreements}\n\n"
                    "请帮助调和分歧，或提供决定性的论据。\n"
                    '输出 JSON: {"worker_id": "...", "role": "...", "contribution": "...", "confidence": 0.8, "vote": "option_A or option_B"}'
                )

            worker = self._create_worker(role, enable_tools=False)
            res = worker.step(prompt)

            try:
                data = json.loads(self._extract_json(res))
                return {
                    "round": round_idx,
                    "worker_id": data.get("worker_id", worker_id),
                    "role": data.get("role", role),
                    "contribution": data.get("contribution", str(res)),
                    "confidence": float(data.get("confidence") or 0.5),
                    "vote": data.get("vote"),
                }
            except:
                return {
                    "round": round_idx,
                    "worker_id": worker_id,
                    "role": role,
                    "contribution": str(res),
                    "confidence": 0.5,
                    "vote": None,
                }

        # Run workers in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = [executor.submit(run_worker, info) for info in role_assignments]
            for f in concurrent.futures.as_completed(futures):
                try:
                    contributions.append(f.result())
                except Exception as e:
                    contributions.append({
                        "round": round_idx,
                        "worker_id": "unknown",
                        "role": "unknown",
                        "contribution": f"Error: {e}",
                        "confidence": 0.0,
                        "vote": None,
                    })

        return contributions

    def _identify_disagreements(self, discussion_history: List[Dict[str, Any]]) -> str:
        """Identify key disagreements in discussion."""
        # Simple heuristic: find conflicting statements
        contributions = [c.get("contribution", "") for c in discussion_history[-6:]]
        if len(contributions) < 2:
            return "无明显分歧"

        prompt = (
            "你是分歧识别器。\n"
            f"讨论历史:\n{'\n'.join(contributions)}\n\n"
            "识别主要的分歧点，用简洁的语言描述。\n"
            '输出 JSON: {"disagreements": ["分歧 1", "分歧 2"]}'
        )
        res = self._create_worker("mediator", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            disagreements = data.get("disagreements", [])
            return "\n".join(disagreements) if disagreements else "无明显分歧"
        except:
            return "存在不同观点，需要进一步讨论"

    def _check_consensus(
        self,
        round_contributions: List[Dict[str, Any]],
        discussion_history: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Check if consensus has been reached."""
        # Collect votes
        votes = [c.get("vote") for c in round_contributions if c.get("vote")]
        if not votes:
            # No explicit votes, check contribution similarity
            return self._check_contribution_consensus(round_contributions)

        # Count votes
        vote_counts: Dict[str, int] = {}
        for vote in votes:
            vote_counts[vote] = vote_counts.get(vote, 0) + 1

        # Check for majority
        total_votes = len(votes)
        for option, count in vote_counts.items():
            if count / total_votes >= 0.6:  # 60% threshold
                return {
                    "consensus_reached": True,
                    "winning_option": option,
                    "vote_distribution": vote_counts,
                    "confidence": count / total_votes,
                }

        return {
            "consensus_reached": False,
            "vote_distribution": vote_counts,
            "reason": "no_majority",
        }

    def _check_contribution_consensus(self, round_contributions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Check consensus based on contribution similarity."""
        contributions = [c.get("contribution", "") for c in round_contributions]
        if len(contributions) < 2:
            return {"consensus_reached": False, "reason": "not_enough_data"}

        # Use LLM to check if contributions converge
        prompt = (
            "你是共识判断器。\n"
            f"Worker 贡献:\n{'\n'.join(contributions)}\n\n"
            "判断这些贡献是否达成了共识。\n"
            '输出 JSON: {"consensus": true, "summary": "共识内容", "confidence": 0.8}'
        )
        res = self._create_worker("mediator", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            return {
                "consensus_reached": bool(data.get("consensus", False)),
                "summary": data.get("summary", ""),
                "confidence": float(data.get("confidence") or 0.5),
            }
        except:
            return {"consensus_reached": False, "reason": "parse_failed"}

    def _force_final_vote(
        self,
        discussion_history: List[Dict[str, Any]],
        user_input: str
    ) -> Dict[str, Any]:
        """Force a final vote after max rounds."""
        all_contributions = "\n".join([
            f"{c.get('role', '?')}: {c.get('contribution', '')}"
            for c in discussion_history
        ])

        prompt = (
            "你是最终决策者。\n"
            f"用户问题：{user_input}\n\n"
            f"完整讨论历史:\n{all_contributions}\n\n"
            "请综合所有观点，做出最终决策。\n"
            '输出 JSON: {"decision": "...", "rationale": "...", "confidence": 0.8}'
        )
        res = self._create_worker("mediator", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            return {
                "consensus_reached": True,
                "decision": data.get("decision", str(res)),
                "rationale": data.get("rationale", ""),
                "confidence": float(data.get("confidence") or 0.7),
                "forced": True,
            }
        except:
            return {
                "consensus_reached": True,
                "decision": str(res),
                "rationale": "Forced decision based on discussion",
                "confidence": 0.5,
                "forced": True,
            }

    def _synthesize_response(
        self,
        final_vote: Dict[str, Any],
        discussion_history: List[Dict[str, Any]],
        user_input: str
    ) -> str:
        """Synthesize final response from vote and discussion."""
        all_contributions = "\n".join([
            f"{c.get('role', '?')}: {c.get('contribution', '')}"
            for c in discussion_history[-10:]  # Last 10 contributions
        ])

        prompt = STEP_TRANSLATION_PROMPT.format(
            user_input=user_input,
            conclusions_json=self._safe_dumps({
                "final_vote": final_vote,
                "key_contributions": all_contributions,
            }),
            soul_content=self.soul
        )

        res = self._create_worker("master", enable_tools=False).step(prompt)
        return str(res or "").strip()

    def _save_to_memory(
        self,
        user_input: str,
        response: str,
        discussion_history: List[Dict[str, Any]]
    ):
        """Save results to memory."""
        timestamp = str(int(time.time()))

        # Update hot memory
        current_hot = self.hot_memory.read()
        hot_update = f"\n\n### SwarmsWorker Update @ {timestamp}\nQ: {user_input[:200]}\nA: {response[:200]}"
        self.hot_memory.update(current_hot + hot_update)

        # Extract key facts
        facts = []
        for c in discussion_history[:3]:
            role = c.get("role", "?")
            contribution = str(c.get("contribution", ""))[:100]
            if contribution:
                facts.append(f"{role}: {contribution}")

        # Append to warm memory
        self.warm_memory.append_log(timestamp, user_input, response[:200], facts)
