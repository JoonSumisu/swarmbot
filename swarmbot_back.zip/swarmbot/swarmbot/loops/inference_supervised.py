"""
InferenceLoop Supervised - 带 Supervisor 和 Human-in-the-Loop 的增强流程

适用于高风险/高复杂度任务。
流程：ANALYSIS → [ANALYSIS_REVIEW 暂停] → COLLECTION → PLANNING → [PLAN_REVIEW 暂停] → EXECUTION → EVALUATION → TRANSLATION → ORGANIZATION
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..config_manager import load_config
from ..llm_client import OpenAICompatibleClient
from ..memory.whiteboard import Whiteboard
from ..memory.hot_memory import HotMemory
from ..memory.warm_memory import WarmMemory
from ..memory.cold_memory import ColdMemory
from .definitions import *
from .skill_registry import SkillRegistry
from .supervisor import LoopSupervisor

# Import Gateway-MasterAgent components
try:
    from ..gateway.orchestrator import SharedContextPool
    from ..skill_pool import SkillPool
except ImportError:
    SharedContextPool = None
    SkillPool = None


class InferenceLoopSupervised:
    """带 Supervisor 和 Human-in-the-Loop 的增强推理流程"""

    def __init__(self, config, workspace_path: str):
        self.config = config
        self.workspace_path = Path(workspace_path)
        self.llm = OpenAICompatibleClient.from_provider(providers=config.providers)

        # Memories
        self.whiteboard = Whiteboard()
        self.hot_memory = HotMemory(workspace_path)
        self.warm_memory = WarmMemory(workspace_path)
        self.cold_memory = ColdMemory()
        self.skill_registry = SkillRegistry()

        # Gateway-MasterAgent integration
        self.context_pool = SharedContextPool(self.workspace_path) if SharedContextPool else None
        self.skill_pool = SkillPool.get_instance() if SkillPool else None

        # Supervisor
        self.supervisor: Optional[LoopSupervisor] = None

        # Load boot files
        self.swarmboot = self._load_boot_file("swarmboot.md")
        self.soul = self._load_boot_file("SOUL.md")
        self.loop_profile_mode = (os.environ.get("SWARMBOT_LOOP_PROFILE") or "swarm_max").strip().lower()

        # Execution state
        self.is_suspended = False
        self.suspended_stage: Optional[str] = None
        self.completed_stages: List[str] = []

    def _load_boot_file(self, filename: str) -> str:
        """Load boot file from disk."""
        paths = [
            os.path.expanduser(f"~/.swarmbot/boot/{filename}"),
            os.path.join(os.path.dirname(__file__), f"../boot/{filename}")
        ]
        for p in paths:
            if os.path.exists(p):
                return open(p, "r", encoding="utf-8").read()
        return ""

    def _init_supervisor(self):
        """Initialize supervisor if not already done."""
        if self.supervisor is None:
            self.supervisor = LoopSupervisor(self.whiteboard, self.llm)

    def _create_worker(
        self,
        role: str,
        enable_tools: bool = True,
        allowed_tools: List[str] | None = None,
        task_desc: str = "",
        required_skills: List[str] | None = None,
    ) -> Any:
        """Create a worker agent."""
        if self.skill_pool:
            skills = self.skill_pool.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)
        else:
            skills = self.skill_registry.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)

        if allowed_tools is not None:
            allowed = set(allowed_tools) | {"whiteboard_update", "hot_memory_update"}
            skills = {k: v for k, v in skills.items() if k in allowed}

        from ..core.agent import CoreAgent, AgentContext
        ctx = AgentContext(agent_id=f"worker-{role}-{time.time_ns()}", role=role, skills=skills)
        return CoreAgent(ctx, self.llm, self.cold_memory, hot_memory=self.hot_memory, enable_tools=enable_tools)

    def _profile_settings(self, profile: str | None = None) -> Dict[str, Any]:
        """Get profile settings - default to swarm_max for supervised mode."""
        active = (profile or self.whiteboard.get("loop_profile") or "swarm_max").strip().lower()
        if active == "lean":
            return {"analysis_workers": 1, "collection_workers": 1, "evaluation_workers": 2, "max_eval_loops": 2, "context_limit": 3500}
        if active == "balanced":
            return {"analysis_workers": 2, "collection_workers": 2, "evaluation_workers": 3, "max_eval_loops": 3, "context_limit": 6000}
        return {"analysis_workers": 3, "collection_workers": 3, "evaluation_workers": 3, "max_eval_loops": 3, "context_limit": 9000}

    def _safe_dumps(self, data: Any, max_len: int = 4000) -> str:
        """Safely dump data to JSON string."""
        def truncate(obj):
            if isinstance(obj, str):
                return obj[:max_len] + "..." if len(obj) > max_len else obj
            if isinstance(obj, list):
                return [truncate(x) for x in obj]
            if isinstance(obj, dict):
                return {k: truncate(v) for k, v in obj.items()}
            return obj
        try:
            return json.dumps(truncate(data), ensure_ascii=False)
        except:
            return "{}"

    def _extract_json(self, text: str) -> str:
        """Extract JSON block from text."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else "{}"

    def _run_parallel(self, prompt: str, count: int, role: str, enable_tools: bool = True, allowed_tools: List[str] | None = None) -> List[str]:
        """Run workers in parallel."""
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=count) as executor:
            futures = [executor.submit(self._create_worker(role, enable_tools, allowed_tools).step, prompt) for _ in range(count)]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    print(f"Worker {role} error: {e}")
        return results

    def _get_context_for_collection(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Get context from context_pool for collection phase."""
        if not self.context_pool:
            return {}
        return self.context_pool.get_context_for_task_sync(task_desc=self._safe_dumps(analysis))

    def _format_context_pool_for_prompt(self, context_data: Dict[str, Any]) -> str:
        """Format context pool data for prompt."""
        if not context_data:
            return ""
        lines = ["## 上下文共享池状态 (来自 Autonomous Engine)"]
        relevant = context_data.get("relevant_bundles", {})
        if relevant:
            lines.append("\n### 相关 Bundle 状态:")
            for bundle_id, data in relevant.items():
                lines.append(f"- `{bundle_id}`: {data.get('status', '')} - {data.get('details', '')}")
        return "\n".join(lines)

    def _create_analysis_checkpoint(self, analysis: Dict, roles: List[str], eval_result: Dict) -> Dict[str, Any]:
        """Create structured analysis review checkpoint."""
        return {
            "stage": "ANALYSIS_REVIEW",
            "status": "pending_user_review",
            "content": {
                "problem_type": analysis.get("type", "unknown"),
                "domain": analysis.get("domain", "unknown"),
                "identified_goals": analysis.get("requirements", []),
                "constraints": analysis.get("constraints", []),
                "worker_roles_proposed": roles,
            },
            "quality_eval": {
                "score": eval_result.get("score", 0.5),
                "passed": eval_result.get("passed", False),
                "issues": eval_result.get("issues", []),
            },
            "user_actions": {
                "confirm": "确认分析，继续执行",
                "modify_roles": "修改建议的 worker 角色",
                "add_constraint": "添加额外约束条件",
                "reject_restart": "拒绝并重新开始分析"
            },
            "whiteboard_mutable_keys": ["worker_roles", "problem_analysis"]
        }

    def _create_plan_checkpoint(self, plan: Dict, eval_result: Dict = None) -> Dict[str, Any]:
        """Create structured plan review checkpoint."""
        tasks = plan.get("tasks", []) if isinstance(plan, dict) else []
        return {
            "stage": "PLAN_REVIEW",
            "status": "pending_user_review",
            "content": {
                "task_count": len(tasks),
                "tasks": [
                    {"id": t.get("id"), "desc": t.get("desc"), "skills": t.get("required_skills", [])}
                    for t in tasks
                ],
            },
            "quality_eval": eval_result or {"score": 0.5, "passed": True, "issues": []},
            "user_actions": {
                "confirm": "确认计划，开始执行",
                "modify_task": "修改某个任务",
                "add_task": "添加新任务",
                "reject_restart": "拒绝并重新规划"
            },
            "whiteboard_mutable_keys": ["action_plan"]
        }

    def _format_checkpoint_prompt(self, checkpoint: Dict) -> str:
        """Format checkpoint data into user-readable prompt."""
        stage = checkpoint.get("stage", "UNKNOWN")
        content = checkpoint.get("content", {})
        quality = checkpoint.get("quality_eval", {})
        actions = checkpoint.get("user_actions", {})

        lines = [
            f"[SUSPENDED] {stage.replace('_', ' ')}",
            f"路由模式：supervised",
            "",
            "=== 内容摘要 ===",
        ]

        if stage == "ANALYSIS_REVIEW":
            lines.append(f"问题类型：{content.get('problem_type', 'unknown')}")
            lines.append(f"领域：{content.get('domain', 'unknown')}")
            lines.append(f"建议角色：{', '.join(content.get('worker_roles_proposed', []))}")
            if content.get('identified_goals'):
                lines.append(f"识别目标：{content['identified_goals']}")
            if content.get('constraints'):
                lines.append(f"约束条件：{content['constraints']}")
        elif stage == "PLAN_REVIEW":
            lines.append(f"任务数量：{content.get('task_count', 0)}")
            for task in content.get('tasks', [])[:5]:
                lines.append(f"  - [{task.get('id')}] {task.get('desc', 'No desc')}")

        lines.append("")
        lines.append("=== 质量评估 ===")
        lines.append(f"评分：{quality.get('score', 'N/A')}")
        lines.append(f"状态：{'通过' if quality.get('passed') else '需改进'}")
        if quality.get('issues'):
            lines.append(f"问题：{quality['issues']}")

        lines.append("")
        lines.append("=== 可用操作 ===")
        for action, desc in actions.items():
            lines.append(f"  - {action}: {desc}")

        lines.append("\n请直接回复提供您的反馈或确认。")
        return "\n".join(lines)

    def run(self, user_input: str, session_id: str) -> str:
        """执行增强推理流程（带暂停确认）"""
        print(f"[InferenceLoop Supervised] Start: {user_input[:50]}...")

        # Initialize
        self.whiteboard.clear()
        self.whiteboard.update("metadata", {"session_id": session_id, "loop_id": str(int(time.time()))})
        self.whiteboard.update("input_prompt", user_input)
        self.whiteboard.update("loop_profile", "swarm_max")
        self.completed_stages = []
        self.is_suspended = False

        # Initialize supervisor
        self._init_supervisor()

        # Step 1: ANALYSIS
        print("[Step 1] Analysis (Multi-Agent)...")
        prompt_analysis = STEP_ANALYSIS_PROMPT.format(
            user_input=user_input,
            swarmboot=self.swarmboot
        ) + "\n\n输出 JSON 包含：self_defined_role, required_tools, confidence, type, domain, requirements, constraints"

        results = self._run_parallel(prompt_analysis, 3, "analyst", enable_tools=False)
        merged = {}
        worker_roles = []
        for r in results:
            try:
                data = json.loads(self._extract_json(r))
                merged.update(data)
                role = str(data.get("self_defined_role") or "").strip()
                if role:
                    worker_roles.append(role)
            except:
                pass

        if not worker_roles:
            worker_roles = ["general_analyst"]
        self.whiteboard.update("worker_roles", worker_roles)
        self.whiteboard.update("problem_analysis", merged)
        self.completed_stages.append("ANALYSIS")

        # SUSPENSION CHECKPOINT 1: ANALYSIS_REVIEW
        print("[Checkpoint] Creating ANALYSIS_REVIEW checkpoint...")
        eval_result = self.supervisor.evaluate_stage_output("ANALYSIS", merged)
        self.whiteboard.update("quality_analysis", eval_result)

        checkpoint_data = self._create_analysis_checkpoint(merged, worker_roles, eval_result)
        self.whiteboard.update("suspension_checkpoint", checkpoint_data)
        self.is_suspended = True
        self.suspended_stage = "ANALYSIS_REVIEW"

        return self._format_checkpoint_prompt(checkpoint_data)

    def resume_from_analysis(self, user_feedback: str = "") -> str:
        """Resume from ANALYSIS checkpoint."""
        print("[InferenceLoop Supervised] Resuming from ANALYSIS checkpoint...")
        self.is_suspended = False
        self.suspended_stage = None

        # Process user feedback if provided
        if user_feedback.strip():
            print(f"[Feedback] Processing user feedback: {user_feedback[:100]}...")
            # Update whiteboard with feedback
            current_analysis = self.whiteboard.get("problem_analysis") or {}
            current_analysis["user_feedback"] = user_feedback
            self.whiteboard.update("problem_analysis", current_analysis)

        user_input = self.whiteboard.get("input_prompt") or ""
        settings = self._profile_settings("swarm_max")

        # Step 2: COLLECTION
        print("[Step 2] Collection (Gather Context)...")
        analysis = self.whiteboard.get("problem_analysis") or {}

        hot = self.hot_memory.read()[:2000]
        warm = self.warm_memory.read_today()[:2000]
        cold = self.cold_memory.search_text(str(analysis), limit=5)[:2000]

        context_pool_data = self._get_context_for_collection(analysis) if self.context_pool else None

        prompt_collection = STEP_COLLECTION_PROMPT.format(
            analysis_json=self._safe_dumps(analysis),
            swarmboot=self.swarmboot,
            hot_memory=hot,
            warm_memory=warm,
            cold_memory=cold
        )
        if context_pool_data:
            prompt_collection += "\n\n" + self._format_context_pool_for_prompt(context_pool_data)

        results = self._run_parallel(prompt_collection, 3, "collector", enable_tools=False)
        merged = {"synthesized_context": "", "external_info": "", "memory_references": []}

        for r in results:
            try:
                data = json.loads(self._extract_json(r))
                merged["synthesized_context"] += "\n" + str(data.get("synthesized_context", ""))
                merged["external_info"] += "\n" + str(data.get("external_info", ""))
                merged["memory_references"].extend(data.get("memory_references", []))
            except:
                pass

        # Tool gate for collection
        tool_gate = self._decide_tool_gate("collection", user_input, self._safe_dumps(merged, max_len=2500), ["web_search", "browser_open", "browser_read", "file_read"])
        self.whiteboard.update("collection_tool_gate", tool_gate)

        if tool_gate.get("need_tools"):
            print("[Step 2b] Collection with tools...")
            tool_results = self._run_parallel(prompt_collection, 1, "collector", enable_tools=True, allowed_tools=tool_gate.get("tools"))
            for r in tool_results:
                try:
                    data = json.loads(self._extract_json(r))
                    merged["synthesized_context"] += "\n" + str(data.get("synthesized_context", ""))
                    merged["external_info"] += "\n" + str(data.get("external_info", ""))
                except:
                    pass

        self.whiteboard.update("information_gathering", merged)

        # Step 3: PLANNING
        print("[Step 3] Planning (Create Plan)...")
        info = {"analysis": analysis, "collection": merged}
        prompt_plan = STEP_PLANNING_PROMPT.format(
            info_json=self._safe_dumps(info, max_len=settings.get("context_limit", 9000)),
            swarmboot=self.swarmboot
        ) + "\n\n输出 tasks 包含 required_skills 数组。"

        res = self._create_worker("planner", enable_tools=False).step(prompt_plan)
        try:
            plan = json.loads(self._extract_json(res))
            tasks = []
            for idx, task in enumerate(plan.get("tasks") or []):
                required = task.get("required_skills") or []
                tasks.append({
                    "id": task.get("id") or (idx + 1),
                    "desc": str(task.get("desc") or f"Task {idx + 1}"),
                    "required_skills": [x for x in required if isinstance(x, str)]
                })
            plan["tasks"] = tasks
            self.whiteboard.update("action_plan", plan)
        except:
            self.whiteboard.update("action_plan", {"tasks": [{"id": 1, "desc": "Fallback task", "required_skills": []}]})

        # SUSPENSION CHECKPOINT 2: PLAN_REVIEW
        print("[Checkpoint] Creating PLAN_REVIEW checkpoint...")
        plan = self.whiteboard.get("action_plan")
        eval_result = self.supervisor.evaluate_stage_output("PLANNING", plan)
        self.whiteboard.update("quality_planning", eval_result)

        checkpoint_data = self._create_plan_checkpoint(plan, eval_result)
        self.whiteboard.update("suspension_checkpoint", checkpoint_data)
        self.is_suspended = True
        self.suspended_stage = "PLAN_REVIEW"

        return self._format_checkpoint_prompt(checkpoint_data)

    def resume_from_plan(self, user_feedback: str = "") -> str:
        """Resume from PLAN checkpoint to final execution."""
        print("[InferenceLoop Supervised] Resuming from PLAN checkpoint...")
        self.is_suspended = False
        self.suspended_stage = None

        # Process user feedback if provided
        if user_feedback.strip():
            print(f"[Feedback] Processing user feedback: {user_feedback[:100]}...")
            current_plan = self.whiteboard.get("action_plan") or {}
            current_plan["user_feedback"] = user_feedback
            self.whiteboard.update("action_plan", current_plan)

        user_input = self.whiteboard.get("input_prompt") or ""
        settings = self._profile_settings("swarm_max")
        info_gather = self.whiteboard.get("information_gathering") or {}
        context = info_gather.get("synthesized_context") or ""

        # Step 4: EXECUTION
        print("[Step 4] Execution (Task Execution)...")
        plan = self.whiteboard.get("action_plan")
        tasks = plan.get("tasks", []) if plan and isinstance(plan, dict) else []

        assignments = []
        for idx, task in enumerate(tasks):
            assignments.append({
                "worker_id": f"worker_{idx+1}",
                "task_id": task.get("id") or (idx + 1),
                "role": "executor",
                "tools": task.get("required_skills") or [],
                "task_desc": task.get("desc") or "",
            })

        self.whiteboard.update("task_assignments", assignments)
        results = []

        def run_task(assign):
            worker = self._create_worker(assign["role"], enable_tools=bool(assign["tools"]), allowed_tools=assign["tools"])
            prompt = STEP_INFERENCE_PROMPT.format(role=assign["role"], task_desc=assign["task_desc"], context=context[:settings.get("context_limit", 9000)])
            res = worker.step(prompt)
            return {"task_id": assign["task_id"], "worker_id": assign["worker_id"], "role": assign["role"], "result": res}

        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(run_task, a) for a in assignments]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    results.append({"task_id": None, "result": f"Task failed: {e}"})

        self.whiteboard.update("inference_conclusions", results)

        # Step 5: EVALUATION
        print("[Step 5] Evaluation (Multi-Agent Validation)...")
        prompt_eval = STEP_EVALUATION_PROMPT.format(
            plan_json=self._safe_dumps(plan),
            results_json=self._safe_dumps(results, max_len=2000),
            swarmboot=self.swarmboot
        )
        evals = self._run_parallel(prompt_eval, 3, "evaluator", enable_tools=False)

        pass_count = 0
        for e in evals:
            try:
                data = json.loads(self._extract_json(e))
                if data.get("vote") == "PASS":
                    pass_count += 1
            except:
                pass

        evaluation_passed = pass_count >= 2

        # If failed, do re-planning
        if not evaluation_passed:
            print("[Step 5b] Re-Planning (Retry)...")
            prompt_replan = f"评估失败，调整计划。\nCurrent Plan: {self._safe_dumps(plan)}\n输出更新后的 JSON 计划。"
            res = self._create_worker("planner", enable_tools=False).step(prompt_replan)
            try:
                new_plan = json.loads(self._extract_json(res))
                self.whiteboard.update("action_plan", new_plan)
                # Re-execute with new plan
                results = []
                for assign in assignments:
                    worker = self._create_worker(assign["role"], enable_tools=False)
                    prompt = STEP_INFERENCE_PROMPT.format(role=assign["role"], task_desc=assign["task_desc"], context=context[:settings.get("context_limit", 9000)])
                    res = worker.step(prompt)
                    results.append({"task_id": assign["task_id"], "worker_id": assign["worker_id"], "role": assign["role"], "result": res})
                self.whiteboard.update("inference_conclusions", results)
            except:
                pass

        # Step 6: TRANSLATION
        print("[Step 6] Translation (Final Response)...")
        prompt_translate = STEP_TRANSLATION_PROMPT.format(
            user_input=user_input,
            conclusions_json=self._safe_dumps(results),
            soul_content=self.soul
        )
        res_final = self._create_worker("master", enable_tools=False).step(prompt_translate)
        final_response = str(res_final or "").strip()

        # Step 7: ORGANIZATION
        print("[Step 7] Organization (Memory Update)...")
        prompt_org = STEP_ORGANIZATION_PROMPT.format(
            response=final_response,
            conclusions_json=self._safe_dumps(results)
        )
        res_org = self._create_worker("master", enable_tools=False).step(prompt_org)
        try:
            data = json.loads(self._extract_json(res_org))
            if data.get("hot_memory_update"):
                current_hot = self.hot_memory.read()
                self.hot_memory.update(current_hot + f"\n\n### Loop Update\n{data['hot_memory_update']}")
            facts = data.get("warm_memory_facts", [])
            self.warm_memory.append_log(
                str(int(time.time())),
                user_input,
                final_response[:200],
                facts
            )
        except:
            pass

        self.completed_stages.extend(["COLLECTION", "PLAN_REVIEW", "EXECUTION", "TRANSLATION", "ORGANIZATION", "DONE"])

        print(f"[InferenceLoop Supervised] Complete: {final_response[:50]}...")
        return final_response

    def _decide_tool_gate(self, stage: str, user_input: str, context_json: str, fallback_tools: List[str]) -> Dict[str, Any]:
        """Decide if tools are needed."""
        prompt = (
            "你是工具门控决策器。判断当前阶段是否需要外部工具。\n"
            f"阶段：{stage}\n用户问题：{user_input}\n上下文：{context_json[:2000]}\n\n"
            "原则：若需要实时信息/外部事实/网页证据则 need_tools=true。\n"
            '输出 JSON: {"need_tools": true, "preferred_tools": ["web_search"], "confidence": 0.78, "reason": "..."}'
        )
        decisions = []
        for _ in range(3):
            res = self._create_worker("planner", enable_tools=False).step(prompt)
            try:
                data = json.loads(self._extract_json(res))
                decisions.append({
                    "ok": True,
                    "need_tools": bool(data.get("need_tools")),
                    "tools": list(set(data.get("preferred_tools") or [])) & {"web_search", "browser_open", "browser_read", "file_read"},
                    "reason": str(data.get("reason") or ""),
                    "confidence": float(data.get("confidence") or 0.5),
                })
            except:
                decisions.append({"ok": False, "need_tools": False, "tools": [], "reason": "parse_failed", "confidence": 0.0})

        valid = [d for d in decisions if d.get("ok")]
        if not valid:
            return {"need_tools": False, "tools": fallback_tools, "reason": "parse_failed", "confidence": 0.0}

        true_votes = [d for d in valid if d.get("need_tools")]
        false_votes = [d for d in valid if not d.get("need_tools")]
        win_need = len(true_votes) >= len(false_votes)
        winner = true_votes if win_need else false_votes
        merged_tools = list(set(sum([(d.get("tools") or []) for d in winner], []))) or fallback_tools
        avg_conf = sum(float(d.get("confidence") or 0.5) for d in winner) / max(1, len(winner))

        return {
            "need_tools": win_need,
            "tools": merged_tools,
            "reason": "; ".join([str(d.get("reason") or "") for d in winner[:2]]),
            "confidence": round(avg_conf, 3),
        }
