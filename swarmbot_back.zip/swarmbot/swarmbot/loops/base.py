"""Base class and shared utilities for Loop modules."""

import os
import time
import json
import concurrent.futures
from typing import List, Dict, Any

from ..core.agent import CoreAgent, AgentContext
from ..llm_client import OpenAICompatibleClient
from ..memory.whiteboard import Whiteboard
from ..memory.hot_memory import HotMemory
from ..memory.warm_memory import WarmMemory
from ..memory.cold_memory import ColdMemory
from ..memory.session_memory import SessionMemory
from .definitions import *
from .skill_registry import SkillRegistry


class InferenceLoopBase:
    """Base class containing shared methods and state for all loop modes."""

    def __init__(self, config, workspace_path: str):
        self.config = config
        self.workspace_path = workspace_path
        self.llm = OpenAICompatibleClient.from_provider(providers=config.providers)

        # Memories
        self.whiteboard = Whiteboard()
        self.hot_memory = HotMemory(workspace_path)
        self.warm_memory = WarmMemory(workspace_path)
        self.cold_memory = ColdMemory()
        self.session_memory = SessionMemory(workspace_path)
        self.skill_registry = SkillRegistry()

        # Load Swarmboot
        self.swarmboot = self._load_boot_file("swarmboot.md")
        self.soul = self._load_boot_file("SOUL.md")
        self.loop_profile_mode = (os.environ.get("SWARMBOT_LOOP_PROFILE") or "auto").strip().lower()

        # Suspend tracking
        self.completed_stages: List[str] = []
        self.is_suspended = False
        self.suspended_stage: str | None = None

    def _load_boot_file(self, filename: str) -> str:
        """Load a boot file from the expected paths."""
        import os
        paths = [
            os.path.expanduser(f"~/.swarmbot/boot/{filename}"),
            os.path.join(os.path.dirname(__file__), f"../boot/{filename}")
        ]
        for p in paths:
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return f.read().strip()
            except FileNotFoundError:
                continue
        return ""

    def _create_worker(
        self,
        role: str,
        enable_tools: bool = True,
        allowed_tools: List[str] | None = None,
        task_desc: str | None = None,
        required_skills: List[str] | None = None,
        session_id: str | None = None,
    ) -> CoreAgent:
        """Create a CoreAgent instance with the specified configuration."""
        skills = self.skill_registry.get_skills_for_task(role, task_desc=task_desc or "", required_skills=required_skills)
        if allowed_tools is not None:
            allowed = set(allowed_tools) | {"whiteboard_update", "hot_memory_update"}
            skills = {k: v for k, v in skills.items() if k in allowed}

        # Use session-aware agent_id format for shared memory access within the same session
        if session_id:
            agent_id = f"{session_id}-{role}"
        else:
            agent_id = f"worker-{role}-{time.time_ns()}"

        ctx = AgentContext(agent_id=agent_id, role=role, skills=skills, session_id=session_id)
        worker = CoreAgent(ctx, self.llm, self.cold_memory, hot_memory=self.hot_memory,
                          session_memory=self.session_memory, enable_tools=enable_tools)
        return worker

    def _profile_settings(self, profile: str | None = None) -> Dict[str, Any]:
        """Get settings for a given loop profile."""
        if profile is None:
            profile = self.loop_profile_mode
        profiles = {
            "lean": {
                "analysis_workers": 1,
                "collection_workers": 1,
                "evaluation_workers": 2,
                "max_eval_loops": 2,
                "context_limit": 3500,
            },
            "balanced": {
                "analysis_workers": 2,
                "collection_workers": 2,
                "evaluation_workers": 3,
                "max_eval_loops": 3,
                "context_limit": 6000,
            },
            "swarm_max": {
                "analysis_workers": 3,
                "collection_workers": 3,
                "evaluation_workers": 3,
                "max_eval_loops": 3,
                "context_limit": 9000,
            },
        }
        return profiles.get(profile, profiles["balanced"])

    def _sanitize_tools(self, preferred: List[str], fallback: List[str]) -> List[str]:
        """Sanitize and merge tool lists."""
        valid = {"web_search", "browser_open", "browser_read", "file_read", "file_write", "python_exec", "shell_exec"}
        result = [t for t in preferred if isinstance(t, str) and t in valid]
        if not result:
            result = [t for t in fallback if isinstance(t, str) and t in valid]
        return list(set(result))

    def _safe_dumps(self, data: Any, max_len: int = 4000) -> str:
        """Safely dump data to JSON string with truncation."""
        def truncate(obj):
            if isinstance(obj, str):
                return obj[:max_len] + "..." if len(obj) > max_len else obj
            if isinstance(obj, list):
                return [truncate(x) for x in obj]
            if isinstance(obj, dict):
                return {k: truncate(v) for k, v in obj.items()}
            return obj

        try:
            return json.dumps(truncate(data), ensure_ascii=False)
        except:
            return "{}"

    def _decide_tool_gate_once(
        self,
        stage: str,
        user_input: str,
        context_json: str,
        fallback_tools: List[str],
    ) -> Dict[str, Any]:
        """Single tool gate decision attempt."""
        prompt = (
            f"你是工具门控决策器(阶段:{stage})。\n"
            f"用户问题: {user_input}\n"
            f"当前上下文: {context_json}\n\n"
            "是否需要使用外部工具？\n"
            "- 需要: web_search, browser_open, browser_read, file_read\n"
            "- 不需要: 直接推理回答\n\n"
            '输出JSON: {"need_tools":false,"preferred_tools":[],"reason":"...","confidence":0.8}'
        )
        res = self._create_worker("planner", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            need = bool(data.get("need_tools"))
            tools = self._sanitize_tools(data.get("preferred_tools") or [], fallback_tools)
            reason = str(data.get("reason") or "")
            conf = float(data.get("confidence") or 0.5)
            conf = 0.0 if conf < 0 else (1.0 if conf > 1 else conf)
            return {"ok": True, "need_tools": need, "tools": tools, "reason": reason, "confidence": conf}
        except:
            return {"ok": False, "need_tools": False, "tools": fallback_tools, "reason": "parse_failed", "confidence": 0.0}

    def _decide_tool_gate(
        self,
        stage: str,
        user_input: str,
        context_json: str,
        fallback_tools: List[str],
    ) -> Dict[str, Any]:
        """Tool gate decision with majority voting."""
        decisions = [self._decide_tool_gate_once(stage, user_input, context_json, fallback_tools) for _ in range(3)]
        valid = [d for d in decisions if d.get("ok")]
        if not valid:
            return {"need_tools": False, "tools": fallback_tools, "reason": "all_parse_failed", "confidence": 0.0, "mode": "fallback"}
        true_votes = [d for d in valid if d.get("need_tools")]
        false_votes = [d for d in valid if not d.get("need_tools")]
        win_need = len(true_votes) >= len(false_votes)
        winner = true_votes if win_need else false_votes
        if not winner:
            winner = valid
        merged_tools = self._sanitize_tools(sum([(d.get("tools") or []) for d in winner], []), fallback_tools)
        avg_conf = sum(float(d.get("confidence") or 0.5) for d in winner) / max(1, len(winner))
        reason = "; ".join([str(d.get("reason") or "") for d in winner[:2]]).strip("; ")
        return {
            "need_tools": win_need,
            "tools": merged_tools,
            "reason": f"majority:{reason}",
            "confidence": round(avg_conf, 3),
            "mode": "majority_vote",
        }

    def _decide_loop_profile_once(self) -> Dict[str, Any]:
        """Single profile decision attempt."""
        prompt = (
            "你是Loop调度决策器。请在 lean / balanced / swarm_max 中选择一个。\n"
            f"用户问题: {self.whiteboard.get('input_prompt')}\n"
            f"问题分析: {self._safe_dumps(self.whiteboard.get('problem_analysis'), max_len=2000)}\n"
            "选择原则:\n"
            "- lean: 常识型、低风险、无需外部信息\n"
            "- balanced: 默认，复杂度中等或不确定\n"
            "- swarm_max: 高风险、高不确定、需要更强冗余评估\n"
            '输出JSON: {"profile":"balanced","reason":"...","confidence":0.72}'
        )
        res = self._create_worker("planner", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            profile = str(data.get("profile") or "balanced").strip().lower()
            if profile not in ["lean", "balanced", "swarm_max"]:
                profile = "balanced"
            conf = float(data.get("confidence") or 0.5)
            conf = 0.0 if conf < 0 else (1.0 if conf > 1 else conf)
            return {"ok": True, "profile": profile, "reason": str(data.get("reason") or ""), "confidence": conf}
        except:
            return {"ok": False, "profile": "balanced", "reason": "parse_failed", "confidence": 0.0}

    def _decide_loop_profile(self) -> str:
        """Profile decision with majority voting."""
        forced = self.loop_profile_mode
        if forced in ["lean", "balanced", "swarm_max"]:
            return forced
        decisions = [self._decide_loop_profile_once() for _ in range(3)]
        valid = [d for d in decisions if d.get("ok")]
        if not valid:
            return "balanced"
        counts: Dict[str, int] = {"lean": 0, "balanced": 0, "swarm_max": 0}
        for d in valid:
            p = str(d.get("profile") or "balanced")
            if p in counts:
                counts[p] += 1
        best = sorted(counts.items(), key=lambda x: (-x[1], 0 if x[0] == "balanced" else 1))[0][0]
        return best

    def _run_parallel(
        self,
        prompt: str,
        count: int,
        role: str,
        enable_tools: bool = True,
        allowed_tools: List[str] | None = None,
    ) -> List[str]:
        """Run multiple workers in parallel and collect results."""
        import concurrent.futures
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=count) as executor:
            futures = [
                executor.submit(
                    self._create_worker(role, enable_tools, allowed_tools).step,
                    prompt
                )
                for _ in range(count)
            ]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    print(f"Worker error: {e}")
        return results

    def _extract_json(self, text: str) -> str:
        """Extract JSON block from text."""
        import re
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else "{}"
