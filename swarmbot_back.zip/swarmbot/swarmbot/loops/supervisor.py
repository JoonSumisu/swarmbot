"""Loop Supervisor - Monitors execution quality and makes adjustment decisions."""

import json
import time
from typing import List, Dict, Any, Optional

from ..memory.whiteboard import Whiteboard
from ..llm_client import OpenAICompatibleClient


class LoopSupervisor:
    """
    Loop 监控系统 - 实时跟踪执行质量并做出调整决策

    职责：
    - 监控每个阶段的输出质量
    - 动态调整 worker 角色配置
    - 决定是否触发重新执行/升级处理
    """

    def __init__(self, whiteboard: Whiteboard, llm_client: OpenAICompatibleClient):
        self.whiteboard = whiteboard
        self.llm = llm_client
        self.quality_scores: Dict[str, float] = {}  # stage -> score
        self.role_adjustments: List[Dict] = []  # 历史角色调整记录

    def evaluate_stage_output(self, stage: str, output: Any, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        评估阶段输出质量

        评估维度：
        1. 输出完整性 - 是否包含所有必需字段
        2. 逻辑一致性 - 是否有内部矛盾
        3. 与用户目标的对齐度 - 是否解决用户问题

        返回：{"passed": bool, "score": 0-1, "issues": [...], "recommended_action": str}
        """
        output_str = json.dumps(output, ensure_ascii=False)[:2000] if not isinstance(output, str) else output[:2000]
        user_input = self.whiteboard.get("input_prompt") or ""

        prompt = (
            f"你是质量监督器。请评估以下阶段输出的质量。\n\n"
            f"阶段名称：{stage}\n"
            f"用户问题：{user_input[:300]}\n"
            f"阶段输出：{output_str}\n\n"
            "评估维度：\n"
            "1. 完整性：输出是否包含所有必需信息\n"
            "2. 一致性：逻辑是否自洽，无内部矛盾\n"
            "3. 对齐度：是否针对用户问题\n\n"
            '输出 JSON 格式：{"score": 0.85, "issues": ["问题 1", "问题 2"], "passed": true, "recommended_action": "PROCEED"}'
        )

        try:
            res = self.llm.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=500
            )
            content = res.get("choices", [{}])[0].get("message", {}).get("content", "{}")
            data = json.loads(self._extract_json(content))

            score = float(data.get("score", 0.5))
            score = max(0.0, min(1.0, score))
            issues = data.get("issues", [])
            passed = data.get("passed", score >= 0.5)
            action = data.get("recommended_action", "PROCEED" if passed else "RETRY")

            # 记录评分
            self.quality_scores[stage] = score

            return {
                "passed": passed,
                "score": score,
                "issues": issues,
                "recommended_action": action
            }
        except Exception as e:
            # 评估失败时使用默认逻辑
            return self._fallback_eval(stage, output)

    def _fallback_eval(self, stage: str, output: Any) -> Dict[str, Any]:
        """Fallback evaluation when LLM fails."""
        # 简单启发式：检查输出长度和基本结构
        output_str = str(output)
        score = 0.5

        if len(output_str) < 50:
            score = 0.3
            issues = ["输出过短，可能不完整"]
            action = "RETRY"
        elif len(output_str) > 5000:
            score = 0.4
            issues = ["输出过长，可能需要精简"]
            action = "ADAPT"
        else:
            issues = []
            action = "PROCEED"

        self.quality_scores[stage] = score
        return {
            "passed": score >= 0.5,
            "score": score,
            "issues": issues,
            "recommended_action": action
        }

    def decide_next_action(self, stage: str, eval_result: Dict, retry_count: int = 0) -> str:
        """
        决定下一步行动：
        - "PROCEED": 继续下一阶段
        - "RETRY": 重新执行当前阶段
        - "ESCALATE": 升级处理（请求用户干预）
        - "ADAPT": 调整角色/策略后继续

        参数：
        - stage: 当前阶段名称
        - eval_result: 评估结果
        - retry_count: 当前阶段已重试次数
        """
        score = eval_result.get("score", 0.5)
        passed = eval_result.get("passed", False)
        issues = eval_result.get("issues", [])

        # 严重问题：分数过低，需要用户干预
        if score < 0.3:
            return "ESCALATE"

        # 中等问题：尝试自动修复或调整
        if score < 0.5:
            if retry_count >= 2:
                return "ESCALATE"  # 超过最大重试次数，升级
            return "RETRY"

        # 轻微问题：调整后继续
        if score < 0.7 and issues:
            return "ADAPT"

        # 正常：继续
        return "PROCEED"

    def adjust_worker_roles(self, current_roles: List[str], task_context: str, reason: str) -> List[str]:
        """
        根据任务进展动态调整 worker 角色

        参数：
        - current_roles: 当前角色列表
        - task_context: 任务上下文
        - reason: 调整原因

        返回：调整后的角色列表
        """
        if not current_roles:
            current_roles = ["general_worker"]

        prompt = (
            f"你是角色配置优化器。\n\n"
            f"当前任务：{task_context[:500]}\n"
            f"调整原因：{reason}\n"
            f"当前角色：{json.dumps(current_roles, ensure_ascii=False)}\n\n"
            "请分析是否需要调整 worker 角色配置以更好地完成后续任务。\n"
            "可考虑的方向：\n"
            "- 增加特定领域的专家角色\n"
            "- 合并冗余角色\n"
            "- 添加新的技能要求\n\n"
            '输出 JSON 格式：{"adjusted_roles": [...], "rationale": "..."}'
        )

        try:
            res = self.llm.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=500
            )
            content = res.get("choices", [{}])[0].get("message", {}).get("content", "{}")
            data = json.loads(self._extract_json(content))

            new_roles = data.get("adjusted_roles") or current_roles
            rationale = data.get("rationale", "")

            # 记录调整历史
            self.role_adjustments.append({
                "timestamp": str(int(time.time())),
                "reason": reason,
                "old_roles": current_roles,
                "new_roles": new_roles,
                "rationale": rationale
            })

            return new_roles
        except Exception:
            return current_roles

    def create_quality_report(self) -> Dict[str, Any]:
        """生成当前执行的质量报告."""
        return {
            "quality_scores": self.quality_scores.copy(),
            "avg_score": sum(self.quality_scores.values()) / max(1, len(self.quality_scores)),
            "role_adjustments": self.role_adjustments.copy(),
            "timestamp": str(int(time.time()))
        }

    def _extract_json(self, text: str) -> str:
        """Extract JSON block from text."""
        import re
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else "{}"
