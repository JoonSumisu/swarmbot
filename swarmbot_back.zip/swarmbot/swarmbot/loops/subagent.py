"""
Subagent Manager for spawning concurrent inference loop tasks.

Provides async task execution and result collection for distributed
inference operations across multiple agents.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import threading
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class SubagentTask:
    """Represents a subtask to be executed by a subagent."""
    task_id: str
    prompt: str
    role: str = "worker"
    tools: List[str] = field(default_factory=list)
    context: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SubagentResult:
    """Result from a subagent execution."""
    task_id: str
    success: bool
    output: str = ""
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    latency_ms: float = 0.0


class SubagentManager:
    """
    Manages subagent execution for distributed inference tasks.

    Architecture:
    - Task Queue: Accepts SubagentTasks from main InferenceLoop
    - Worker Pool: Spawns concurrent workers (Thread or Async)
    - Result Aggregator: Collects and merges results

    Use cases:
    - Parallel tool lookups across multiple agents
    - Multi-perspective analysis with different roles
    - Distributed reasoning tasks
    """

    def __init__(
        self,
        max_workers: int = 4,
        loop_profile: str = "balanced",
    ):
        self.max_workers = max_workers
        self.loop_profile = loop_profile.lower()
        self._thread_pool = None
        self._async_loop = None

        # Profile settings for worker allocation
        self._profile_settings = {
            "lean": {"max_workers": 1},
            "balanced": {"max_workers": 3},
            "swarm_max": {"max_workers": 4},
        }

    def _get_worker_count(self) -> int:
        """Get worker count based on profile."""
        settings = self._profile_settings.get(self.loop_profile, self._profile_settings["balanced"])
        return min(self.max_workers, settings.get("max_workers", 3))

    def submit_task(
        self,
        task_id: str,
        prompt: str,
        role: str = "worker",
        tools: Optional[List[str]] = None,
        context: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SubagentTask:
        """Submit a single task for execution."""
        return SubagentTask(
            task_id=task_id,
            prompt=prompt,
            role=role,
            tools=tools or [],
            context=context,
            metadata=metadata or {},
        )

    def execute_sync(self, tasks: List[SubagentTask]) -> List[SubagentResult]:
        """
        Execute tasks synchronously using thread pool.

        Args:
            tasks: List of SubagentTasks to execute

        Returns:
            List of SubagentResults in task order
        """
        worker_count = self._get_worker_count()
        results: List[Optional[SubagentResult]] = [None] * len(tasks)

        def run_task(idx: int, task: SubagentTask) -> SubagentResult:
            import time

            start_time = time.time()
            try:
                output = self._execute_single(task)
                latency_ms = (time.time() - start_time) * 1000
                return SubagentResult(
                    task_id=task.task_id,
                    success=True,
                    output=output,
                    latency_ms=latency_ms,
                    metadata=task.metadata,
                )
            except Exception as e:
                latency_ms = (time.time() - start_time) * 1000
                return SubagentResult(
                    task_id=task.task_id,
                    success=False,
                    error=str(e),
                    latency_ms=latency_ms,
                    metadata=task.metadata,
                )

        with concurrent.futures.ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = [executor.submit(run_task, i, t) for i, t in enumerate(tasks)]
            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result()
                    if result is not None:
                        idx = next(i for i, r in enumerate(results) if r is None)
                        results[idx] = result
                except Exception as e:
                    # Find first None position and fill with error
                    for i in range(len(results)):
                        if results[i] is None:
                            results[i] = SubagentResult(
                                task_id=tasks[i].task_id if i < len(tasks) else "unknown",
                                success=False,
                                error=str(e),
                            )
                            break

        return [r for r in results if r is not None]

    async def execute_async(self, tasks: List[SubagentTask]) -> List[SubagentResult]:
        """
        Execute tasks asynchronously.

        Args:
            tasks: List of SubagentTasks to execute

        Returns:
            List of SubagentResults in task order
        """
        worker_count = self._get_worker_count()

        async def run_task(idx: int, task: SubagentTask) -> SubagentResult:
            import asyncio
            start_time = asyncio.get_event_loop().time()
            try:
                output = await self._execute_single_async(task)
                elapsed = asyncio.get_event_loop().time() - start_time
                return SubagentResult(
                    task_id=task.task_id,
                    success=True,
                    output=output,
                    latency_ms=elapsed * 1000,
                    metadata=task.metadata,
                )
            except Exception as e:
                elapsed = asyncio.get_event_loop().time() - start_time
                return SubagentResult(
                    task_id=task.task_id,
                    success=False,
                    error=str(e),
                    latency_ms=elapsed * 1000,
                    metadata=task.metadata,
                )

        # Create tasks for async execution
        async_tasks = [run_task(i, t) for i, t in enumerate(tasks)]

        # Execute with semaphore for worker limit
        sem = asyncio.Semaphore(worker_count)

        async def limited_run(task_coro):
            async with sem:
                return await task_coro

        results = await asyncio.gather(*[limited_run(t) for t in async_tasks])
        return list(results)

    def _execute_single(self, task: SubagentTask) -> str:
        """
        Execute a single task (sync version).

        This is a placeholder that would integrate with CoreAgent
        and the actual LLM client in production.
        """
        # Placeholder implementation
        return f"Result for {task.role} on task '{task.task_id}': {task.prompt[:100]}"

    async def _execute_single_async(self, task: SubagentTask) -> str:
        """Execute a single task (async version)."""
        import asyncio
        await asyncio.sleep(0.01)  # Simulate I/O
        return f"Async result for {task.role} on task '{task.task_id}'"

    def submit_batch(
        self,
        prompts: List[str],
        role: str = "worker",
        tools: Optional[List[str]] = None,
        contexts: Optional[List[str]] = None,
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> List[SubagentTask]:
        """Submit multiple tasks with same configuration."""
        tasks = []
        for i, prompt in enumerate(prompts):
            context = contexts[i] if contexts and i < len(contexts) else ""
            metadata = metadatas[i] if metadatas and i < len(metadatas) else {}

            tasks.append(self.submit_task(
                task_id=f"task_{i+1}",
                prompt=prompt,
                role=role,
                tools=tools,
                context=context,
                metadata=metadata,
            ))
        return tasks

    def merge_results(self, results: List[SubagentResult]) -> Dict[str, Any]:
        """
        Merge multiple subagent results into a single summary.

        Returns structured data with:
        - success_count: Number of successful tasks
        - failed_count: Number of failed tasks
        - outputs: List of successful outputs
        - errors: List of error messages
        - avg_latency_ms: Average execution latency
        """
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]

        return {
            "success_count": len(successful),
            "failed_count": len(failed),
            "total_count": len(results),
            "outputs": [r.output for r in successful],
            "errors": [{"task_id": r.task_id, "error": r.error} for r in failed],
            "avg_latency_ms": sum(r.latency_ms for r in results) / max(1, len(results)),
        }


# Convenience functions for common patterns

def run_parallel_analysis(
    prompts: List[str],
    roles: Optional[List[str]] = None,
    max_workers: int = 4,
) -> SubagentManager:
    """
    Run parallel analysis tasks with different perspectives.

    Args:
        prompts: Analysis prompts for each agent
        roles: Specialized roles for each agent (defaults to "analyst")
        max_workers: Maximum concurrent workers

    Returns:
        SubagentManager with tasks ready for execution
    """
    manager = SubagentManager(max_workers=max_workers)

    if roles is None:
        roles = ["analyst"] * len(prompts)

    tasks = []
    for i, prompt in enumerate(prompts):
        role = roles[i] if i < len(roles) else "analyst"
        tasks.append(manager.submit_task(
            task_id=f"analysis_{i+1}",
            prompt=prompt,
            role=role,
        ))

    return manager


def run_multi_tool_lookup(
    queries: List[str],
    tools: List[str],
    max_workers: int = 3,
) -> SubagentManager:
    """
    Run parallel tool lookups across multiple queries.

    Args:
        queries: Search queries for each tool lookup
        tools: Tool names to use (web_search, browser_open, etc.)
        max_workers: Maximum concurrent workers

    Returns:
        SubagentManager configured for tool lookups
    """
    manager = SubagentManager(max_workers=max_workers)
    tasks = [
        manager.submit_task(
            task_id=f"lookup_{i+1}",
            prompt=query,
            role="researcher",
            tools=tools,
        )
        for i, query in enumerate(queries)
    ]

    return manager
