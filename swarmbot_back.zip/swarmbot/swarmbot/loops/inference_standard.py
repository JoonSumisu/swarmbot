"""
InferenceLoop Standard - 标准 8 步推理流程

被动思考工具，适用于中等复杂度任务。
流程：ANALYSIS → COLLECTION → PLANNING → INFERENCE → EVALUATION → TRANSLATION → ORGANIZATION
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config_manager import ProviderConfig, WORKSPACE_PATH, load_config
from ..llm_client import OpenAICompatibleClient
from ..memory.whiteboard import Whiteboard
from ..memory.hot_memory import HotMemory
from ..memory.warm_memory import WarmMemory
from ..memory.cold_memory import ColdMemory
from .definitions import *
from .skill_registry import SkillRegistry

# Import Gateway-MasterAgent components
try:
    from ..gateway.orchestrator import SharedContextPool
    from ..skill_pool import SkillPool
except ImportError:
    SharedContextPool = None
    SkillPool = None


class InferenceLoopStandard:
    """标准 8 步推理流程工具"""

    def __init__(self, config, workspace_path: str):
        self.config = config
        self.workspace_path = Path(workspace_path)
        self.llm = OpenAICompatibleClient.from_provider(providers=config.providers)

        # Memories
        self.whiteboard = Whiteboard()
        self.hot_memory = HotMemory(workspace_path)
        self.warm_memory = WarmMemory(workspace_path)
        self.cold_memory = ColdMemory()
        self.skill_registry = SkillRegistry()

        # Gateway-MasterAgent integration
        self.context_pool = SharedContextPool(self.workspace_path) if SharedContextPool else None
        self.skill_pool = SkillPool.get_instance() if SkillPool else None

        # Load boot files
        self.swarmboot = self._load_boot_file("swarmboot.md")
        self.soul = self._load_boot_file("SOUL.md")
        self.loop_profile_mode = (os.environ.get("SWARMBOT_LOOP_PROFILE") or "balanced").strip().lower()

        # Execution state
        self.is_suspended = False
        self.suspended_stage = None

    def _load_boot_file(self, filename: str) -> str:
        """Load boot file from disk."""
        paths = [
            os.path.expanduser(f"~/.swarmbot/boot/{filename}"),
            os.path.join(os.path.dirname(__file__), f"../boot/{filename}")
        ]
        for p in paths:
            if os.path.exists(p):
                return open(p, "r", encoding="utf-8").read()
        return f"Boot file {filename} not found."

    def _create_worker(
        self,
        role: str,
        enable_tools: bool = True,
        allowed_tools: List[str] | None = None,
        task_desc: str = "",
        required_skills: List[str] | None = None,
    ) -> Any:
        """Create a worker agent."""
        if self.skill_pool:
            skills = self.skill_pool.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)
        else:
            skills = self.skill_registry.get_skills_for_task(role, task_desc=task_desc, required_skills=required_skills)

        if allowed_tools is not None:
            allowed = set(allowed_tools) | {"whiteboard_update", "hot_memory_update"}
            skills = {k: v for k, v in skills.items() if k in allowed}

        from ..core.agent import CoreAgent, AgentContext
        ctx = AgentContext(agent_id=f"worker-{role}-{time.time_ns()}", role=role, skills=skills)
        return CoreAgent(ctx, self.llm, self.cold_memory, hot_memory=self.hot_memory, enable_tools=enable_tools)

    def _profile_settings(self, profile: str | None = None) -> Dict[str, Any]:
        """Get profile settings."""
        active = (profile or self.whiteboard.get("loop_profile") or "balanced").strip().lower()
        if active == "lean":
            return {"analysis_workers": 1, "collection_workers": 1, "evaluation_workers": 2, "max_eval_loops": 2, "context_limit": 3500}
        if active == "swarm_max":
            return {"analysis_workers": 3, "collection_workers": 3, "evaluation_workers": 3, "max_eval_loops": 3, "context_limit": 9000}
        return {"analysis_workers": 2, "collection_workers": 2, "evaluation_workers": 3, "max_eval_loops": 3, "context_limit": 6000}

    def _safe_dumps(self, data: Any, max_len: int = 4000) -> str:
        """Safely dump data to JSON string."""
        def truncate(obj):
            if isinstance(obj, str):
                return obj[:max_len] + "..." if len(obj) > max_len else obj
            if isinstance(obj, list):
                return [truncate(x) for x in obj]
            if isinstance(obj, dict):
                return {k: truncate(v) for k, v in obj.items()}
            return obj
        try:
            return json.dumps(truncate(data), ensure_ascii=False)
        except:
            return "{}"

    def _sanitize_tools(self, names: List[str], fallback: List[str]) -> List[str]:
        """Sanitize tool names."""
        valid = {"web_search", "browser_open", "browser_read", "file_read", "file_write", "python_exec", "shell_exec"}
        cleaned = [n for n in names or [] if isinstance(n, str) and n in valid]
        return cleaned if cleaned else [t for t in fallback if t in valid]

    def _extract_json(self, text: str) -> str:
        """Extract JSON block from text."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else "{}"

    def _run_parallel(self, prompt: str, count: int, role: str, enable_tools: bool = True, allowed_tools: List[str] | None = None) -> List[str]:
        """Run workers in parallel."""
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=count) as executor:
            futures = [executor.submit(self._create_worker(role, enable_tools, allowed_tools).step, prompt) for _ in range(count)]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    print(f"Worker {role} error: {e}")
        return results

    def _decide_tool_gate(self, stage: str, user_input: str, context_json: str, fallback_tools: List[str]) -> Dict[str, Any]:
        """Decide if tools are needed."""
        prompt = (
            "你是工具门控决策器。判断当前阶段是否需要外部工具。\n"
            f"阶段：{stage}\n用户问题：{user_input}\n上下文：{context_json[:2000]}\n\n"
            "原则：若需要实时信息/外部事实/网页证据则 need_tools=true。\n"
            '输出 JSON: {"need_tools": true, "preferred_tools": ["web_search"], "confidence": 0.78, "reason": "..."}'
        )
        decisions = [self._extract_tool_decision(self._create_worker("planner", enable_tools=False).step(prompt)) for _ in range(3)]
        valid = [d for d in decisions if d.get("ok")]
        if not valid:
            return {"need_tools": False, "tools": fallback_tools, "reason": "parse_failed", "confidence": 0.0}

        true_votes = [d for d in valid if d.get("need_tools")]
        false_votes = [d for d in valid if not d.get("need_tools")]
        win_need = len(true_votes) >= len(false_votes)
        winner = true_votes if win_need else false_votes
        merged_tools = self._sanitize_tools(sum([(d.get("tools") or []) for d in winner], []), fallback_tools)
        avg_conf = sum(float(d.get("confidence") or 0.5) for d in winner) / max(1, len(winner))

        return {
            "need_tools": win_need,
            "tools": merged_tools,
            "reason": "; ".join([str(d.get("reason") or "") for d in winner[:2]]),
            "confidence": round(avg_conf, 3),
        }

    def _extract_tool_decision(self, text: str) -> Dict[str, Any]:
        """Extract tool decision from text."""
        try:
            data = json.loads(self._extract_json(text))
            return {
                "ok": True,
                "need_tools": bool(data.get("need_tools")),
                "tools": self._sanitize_tools(data.get("preferred_tools") or [], []),
                "reason": str(data.get("reason") or ""),
                "confidence": float(data.get("confidence") or 0.5),
            }
        except:
            return {"ok": False, "need_tools": False, "tools": [], "reason": "parse_failed", "confidence": 0.0}

    def _get_context_for_collection(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Get context from context_pool for collection phase."""
        if not self.context_pool:
            return {}
        return self.context_pool.get_context_for_task_sync(
            task_desc=self._safe_dumps(analysis),
        )

    def _format_context_pool_for_prompt(self, context_data: Dict[str, Any]) -> str:
        """Format context pool data for prompt."""
        if not context_data:
            return ""
        lines = ["## 上下文共享池状态 (来自 Autonomous Engine)"]
        relevant = context_data.get("relevant_bundles", {})
        if relevant:
            lines.append("\n### 相关 Bundle 状态:")
            for bundle_id, data in relevant.items():
                lines.append(f"- `{bundle_id}`: {data.get('status', '')} - {data.get('details', '')}")
        return "\n".join(lines)

    def run(self, user_input: str, session_id: str) -> str:
        """执行标准 8 步推理流程"""
        print(f"[InferenceLoop Standard] Start: {user_input[:50]}...")

        # Initialize
        self.whiteboard.clear()
        self.whiteboard.update("metadata", {"session_id": session_id, "loop_id": str(int(time.time()))})
        self.whiteboard.update("input_prompt", user_input)
        self.whiteboard.update("loop_profile", self.loop_profile_mode)

        # Step 1: ANALYSIS
        self._step_analysis()
        selected_profile = self._decide_loop_profile()
        self.whiteboard.update("loop_profile", selected_profile)
        settings = self._profile_settings(selected_profile)

        # Step 2: COLLECTION
        self._step_collection()

        # Step 3: PLANNING
        self._step_planning()

        # Step 4, 5, 6: INFERENCE & EVALUATION (Max 3 Loops)
        max_eval_loops = int(settings.get("max_eval_loops", 3))
        for i in range(max_eval_loops):
            self.whiteboard.update("evaluation_report", {"retry_count": i})
            self._step_inference()
            if self._step_evaluation():
                break
            print(f"[InferenceLoop] Evaluation failed, retrying {i+1}/{max_eval_loops}")
            if i < max_eval_loops - 1:
                self._step_replanning(retry_idx=i)

        # Step 7: TRANSLATION
        final_response = self._step_translation()
        final_response = self._calibrate_final_response(user_input, final_response)
        self.whiteboard.update("final_response", final_response)

        # Step 8: ORGANIZATION
        self._step_organization()

        print(f"[InferenceLoop Standard] Complete: {final_response[:50]}...")
        return final_response

    def _decide_loop_profile(self) -> str:
        """Decide loop profile with voting."""
        forced = self.loop_profile_mode
        if forced in ["lean", "balanced", "swarm_max"]:
            return forced

        decisions = []
        for _ in range(3):
            prompt = (
                "你是 Loop 调度决策器。选择 loop profile。\n"
                f"用户问题：{self.whiteboard.get('input_prompt')}\n"
                f"分析：{self._safe_dumps(self.whiteboard.get('problem_analysis'), max_len=2000)}\n"
                "原则：lean=简单，balanced=默认，swarm_max=复杂\n"
                '输出 JSON: {"profile":"balanced","reason":"...","confidence":0.7}'
            )
            res = self._create_worker("planner", enable_tools=False).step(prompt)
            try:
                data = json.loads(self._extract_json(res))
                profile = str(data.get("profile") or "balanced")
                if profile in ["lean", "balanced", "swarm_max"]:
                    decisions.append(profile)
            except:
                pass

        if not decisions:
            return "balanced"
        return max(set(decisions), key=decisions.count)

    def _step_analysis(self):
        """Step 1: Problem Analysis"""
        print("[Step 1] Analysis (No Tools)...")
        settings = self._profile_settings()
        prompt = STEP_ANALYSIS_PROMPT.format(
            user_input=self.whiteboard.get("input_prompt"),
            swarmboot=self.swarmboot
        ) + "\n\n输出 JSON 包含：self_defined_role, required_tools, confidence"

        results = self._run_parallel(prompt, int(settings.get("analysis_workers", 2)), "analyst", enable_tools=False)
        merged = {}
        worker_roles = []
        for r in results:
            try:
                data = json.loads(self._extract_json(r))
                merged.update(data)
                role = str(data.get("self_defined_role") or "").strip()
                if role:
                    worker_roles.append(role)
            except:
                pass

        self.whiteboard.update("worker_roles", worker_roles or ["general_analyst"])
        self.whiteboard.update("problem_analysis", merged)

    def _step_collection(self):
        """Step 2: Information Collection"""
        print("[Step 2] Collection...")
        settings = self._profile_settings()
        analysis = self.whiteboard.get("problem_analysis")
        user_input = self.whiteboard.get("input_prompt") or ""

        # Gather memories
        hot = self.hot_memory.read()[:2000]
        warm = self.warm_memory.read_today()[:2000]
        cold = self.cold_memory.search_text(str(analysis), limit=5)[:2000]

        # Get context pool data
        context_pool_data = self._get_context_for_collection(analysis) if self.context_pool else None

        prompt = STEP_COLLECTION_PROMPT.format(
            analysis_json=self._safe_dumps(analysis),
            swarmboot=self.swarmboot,
            hot_memory=hot,
            warm_memory=warm,
            cold_memory=cold
        )
        if context_pool_data:
            prompt += "\n\n" + self._format_context_pool_for_prompt(context_pool_data)

        results = self._run_parallel(prompt, int(settings.get("collection_workers", 2)), "collector", enable_tools=False)
        merged = {"synthesized_context": "", "memory_references": [], "external_info": ""}

        for r in results:
            try:
                data = json.loads(self._extract_json(r))
                merged["synthesized_context"] += "\n" + data.get("synthesized_context", "")
                merged["memory_references"].extend(data.get("memory_references", []))
            except:
                pass

        # Tool gate
        gate = self._decide_tool_gate("collection", user_input, self._safe_dumps(merged), ["web_search", "browser_open", "browser_read", "file_read"])
        self.whiteboard.update("collection_tool_gate", gate)

        if gate.get("need_tools"):
            print("[Step 2b] Collection with tools...")
            tool_results = self._run_parallel(prompt, 1, "collector", enable_tools=True, allowed_tools=gate.get("tools"))
            for r in tool_results:
                try:
                    data = json.loads(self._extract_json(r))
                    merged["synthesized_context"] += "\n" + data.get("synthesized_context", "")
                except:
                    pass

        self.whiteboard.update("information_gathering", merged)

    def _step_planning(self):
        """Step 3: Action Planning"""
        print("[Step 3] Planning (No Tools)...")
        info = self.whiteboard.get("information_gathering")
        prompt = STEP_PLANNING_PROMPT.format(
            info_json=self._safe_dumps(info, max_len=6000),
            swarmboot=self.swarmboot
        ) + "\n\n输出 tasks 包含 required_skills 数组。"

        res = self._create_worker("planner", enable_tools=False).step(prompt)
        try:
            plan = json.loads(self._extract_json(res))
            tasks = []
            for idx, task in enumerate(plan.get("tasks") or []):
                required = task.get("required_skills")
                if not isinstance(required, list):
                    required = []
                tasks.append({"id": task.get("id") or (idx + 1), "desc": task.get("desc") or f"Task {idx+1}", "required_skills": [x for x in required if isinstance(x, str)]})
            plan["tasks"] = tasks
            self.whiteboard.update("action_plan", plan)
        except:
            self.whiteboard.update("action_plan", {"tasks": [{"id": 1, "desc": "Fallback task", "required_skills": []}]})

    def _step_replanning(self, retry_idx: int):
        """Re-planning after evaluation failure"""
        print(f"[Step 3b] Re-Planning (Attempt {retry_idx+1})...")
        eval_report = self.whiteboard.get("evaluation_report")
        current_plan = self.whiteboard.get("action_plan")

        prompt = f"评估失败，调整计划。\nEvaluation: {self._safe_dumps(eval_report)}\nCurrent Plan: {self._safe_dumps(current_plan)}\n输出更新后的 JSON 计划。"
        res = self._create_worker("planner", enable_tools=False).step(prompt)
        try:
            new_plan = json.loads(self._extract_json(res))
            tasks = []
            for idx, task in enumerate(new_plan.get("tasks") or []):
                required = task.get("required_skills") or []
                tasks.append({"id": task.get("id") or (idx + 1), "desc": task.get("desc") or f"Task {idx+1}", "required_skills": [x for x in required if isinstance(x, str)]})
            new_plan["tasks"] = tasks
            self.whiteboard.update("action_plan", new_plan)
        except:
            pass

    def _step_inference(self):
        """Step 4: Inference Execution"""
        print("[Step 4] Inference (Self-Organized Task Claim)...")
        settings = self._profile_settings()
        plan = self.whiteboard.get("action_plan")
        info = self.whiteboard.get("information_gathering") or {}
        context = info.get("synthesized_context") or ""
        tasks = plan.get("tasks") or []
        max_agents = max(1, int(getattr(self.config.swarm, "max_agents", 4)))

        # Simple task assignment
        assignments = []
        for idx, task in enumerate(tasks):
            assignments.append({
                "worker_id": f"worker_{idx+1}",
                "task_id": task.get("id") or (idx + 1),
                "role": "worker",
                "tools": task.get("required_skills") or [],
                "task_desc": task.get("desc") or "",
            })

        self.whiteboard.update("task_assignments", assignments)
        results = []

        def run_task(assign):
            worker = self._create_worker(assign["role"], enable_tools=bool(assign["tools"]), allowed_tools=assign["tools"])
            prompt = STEP_INFERENCE_PROMPT.format(role=assign["role"], task_desc=assign["task_desc"], context=context[:int(settings.get("context_limit", 8000))])
            res = worker.step(prompt)
            return {"task_id": assign["task_id"], "worker_id": assign["worker_id"], "role": assign["role"], "result": res}

        with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(assignments), max_agents)) as executor:
            futures = [executor.submit(run_task, a) for a in assignments]
            for f in concurrent.futures.as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    results.append({"task_id": None, "result": f"Task failed: {e}"})

        self.whiteboard.update("inference_conclusions", results)

    def _step_evaluation(self) -> bool:
        """Step 5: Evaluation"""
        print("[Step 5] Evaluation...")
        settings = self._profile_settings()
        plan = self.whiteboard.get("action_plan")
        results = self.whiteboard.get("inference_conclusions")

        prompt = STEP_EVALUATION_PROMPT.format(
            plan_json=self._safe_dumps(plan),
            results_json=self._safe_dumps(results, max_len=2000),
            swarmboot=self.swarmboot
        )
        evals = self._run_parallel(prompt, int(settings.get("evaluation_workers", 3)), "evaluator", enable_tools=False)

        pass_count = 0
        for e in evals:
            try:
                data = json.loads(self._extract_json(e))
                if data.get("vote") == "PASS":
                    pass_count += 1
            except:
                pass

        passed = pass_count >= 2
        self.whiteboard.update("evaluation_report", {"passed": passed, "pass_count": pass_count})
        return passed

    def _step_translation(self) -> str:
        """Step 6: Translation"""
        print("[Step 6] Translation...")
        conclusions = self.whiteboard.get("inference_conclusions")
        user_input = self.whiteboard.get("input_prompt") or ""

        prompt = STEP_TRANSLATION_PROMPT.format(
            user_input=user_input,
            conclusions_json=self._safe_dumps(conclusions, max_len=2000),
            soul_content=self.soul
        )

        res = self._create_worker("master", enable_tools=False).step(prompt)
        return str(res or "").strip()

    def _calibrate_final_response(self, user_input: str, response: str) -> str:
        """Calibrate final response for hard constraints."""
        # Simple calibration for car wash scenario
        if "洗车" in user_input and "车" in user_input:
            if "步行" in response or "走路" in response:
                return "建议开车去。洗车的前提是把车带到洗车店。"
        return response

    def _step_organization(self):
        """Step 7: Organization"""
        print("[Step 7] Organization (Memory Update)...")
        prompt = STEP_ORGANIZATION_PROMPT.format(
            response=self.whiteboard.get("final_response"),
            conclusions_json=self._safe_dumps(self.whiteboard.get("inference_conclusions"), max_len=1500)
        )
        res = self._create_worker("master", enable_tools=False).step(prompt)
        try:
            data = json.loads(self._extract_json(res))
            if data.get("hot_memory_update"):
                cur_hot = self.hot_memory.read()
                self.hot_memory.update(cur_hot + f"\n\n### Loop Update\n{data['hot_memory_update']}")
            facts = data.get("warm_memory_facts", [])
            self.warm_memory.append_log(
                self.whiteboard.get("metadata").get("loop_id"),
                self.whiteboard.get("input_prompt"),
                data.get("summary", ""),
                facts
            )
        except:
            pass
