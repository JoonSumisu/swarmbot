from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

CONFIG_HOME = os.path.expanduser("~/.swarmbot")
CONFIG_PATH = os.path.join(CONFIG_HOME, "config.json")
WORKSPACE_PATH = os.path.join(CONFIG_HOME, "workspace")
BOOT_CONFIG_PATH = os.path.join(CONFIG_HOME, "boot")


@dataclass
class ProviderConfig:
    name: str = "custom"
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    max_tokens: int = 4096
    temperature: float = 0.6


@dataclass
class SwarmSettings:
    max_agents: int = 4 # Maximum number of agents in the swarm
    # Default roles list is just a suggestion or pool; if dynamic allocation is used, this might be ignored or extended
    # Empty list by default to emphasize dynamic nature
    roles: List[str] = field(default_factory=list)
    architecture: str = "auto" # Default to auto for dynamic behavior
    max_turns: int = 16
    auto_builder: bool = True # Enable dynamic role building by default
    display_mode: str = "simple"  # simple or log


@dataclass
class ToolConfig:
    fs: Dict[str, Any] = field(default_factory=lambda: {"allow_read": [], "allow_write": []})
    shell: Dict[str, Any] = field(default_factory=lambda: {"allow_commands": [], "deny_commands": []}) # Unrestricted by default
    exec: Dict[str, Any] = field(
        default_factory=lambda: {
            "approval_mode": "deny_dangerous",
            "deny_patterns": ["rm -rf /", "shutdown", "reboot", ":(){:|:&};:", "mkfs", "dd if="],
            "default_timeout_seconds": 30,
            "max_concurrent_processes": 8,
        }
    )

@dataclass
class ChannelConfig:
    enabled: bool = False
    app_id: str = ""
    app_secret: str = ""
    encrypt_key: str = ""
    verification_token: str = ""
    token: str = ""  # For Telegram/Discord/Slack
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DaemonConfig:
    manage_gateway: bool = True
    manage_autonomous: bool = True
    backup_interval_seconds: int = 60
    health_check_interval_seconds: int = 3600
    gateway_restart_delay_seconds: int = 10
    autonomous_restart_delay_seconds: int = 10

@dataclass
class AutonomousConfig:
    enabled: bool = True
    tick_seconds: int = 30
    max_concurrent_actions: int = 3
    # Independent provider for autonomous mode
    provider: Optional[ProviderConfig] = field(default_factory=lambda: ProviderConfig(name="autonomous", max_tokens=8192))
    model_routing: Dict[str, Any] = field(default_factory=dict)
    default_locked_bundles: List[str] = field(
        default_factory=lambda: [
            "core.memory_foundation",
            "core.boot_optimizer",
            "core.system_hygiene",
            "core.bundle_governor",
        ]
    )
    queues: Dict[str, Any] = field(
        default_factory=lambda: {
            "monitor_queue_size": 1000,
            "action_queue_size": 500,
            "decision_batch_window_ms": 800,
        }
    )
    swarm_execution: Dict[str, Any] = field(
        default_factory=lambda: {
            "worker_min": 1,
            "worker_max": 10,
            "architectures": ["auto", "tree", "mesh", "pipeline"],
            "require_tasklist_before_dispatch": True,
            "role_selection_mode": "self_select_by_tasklist",
        }
    )
    bundle_registry: Dict[str, Any] = field(
        default_factory=lambda: {
            "root_dir": "~/.swarmbot/bundles",
            "index_file": "~/.swarmbot/bundles/_registry/bundles_index.jsonl",
            "catalog_file": "~/.swarmbot/bundles/_registry/bundles_catalog.md",
            "require_registry_write_on_create": True,
        }
    )
    monitor: Dict[str, Any] = field(
        default_factory=lambda: {
            "memory_organizer": {"enabled": True, "interval_minutes": 30},
            "system_health": {"enabled": True, "interval_minutes": 10, "disk_free_ratio_threshold": 0.1, "mem_free_ratio_threshold": 0.1},
            "long_task_reporter": {"enabled": True, "interval_minutes": 5},
        }
    )

@dataclass
class SwarmbotConfig:
    providers: List[ProviderConfig] = field(default_factory=lambda: [
        ProviderConfig(name="primary"),
        ProviderConfig(name="backup")
    ])
    # Deprecated 'provider' field removed to avoid confusion/conflicts
    swarm: SwarmSettings = field(default_factory=SwarmSettings)
    tools: ToolConfig = field(default_factory=ToolConfig)
    channels: Dict[str, ChannelConfig] = field(default_factory=dict)
    daemon: DaemonConfig = field(default_factory=DaemonConfig)
    autonomous: AutonomousConfig = field(default_factory=AutonomousConfig)
    # No more hardcoded paths here, rely on constants

def ensure_dirs() -> None:
    # Ensure config and workspace exist
    os.makedirs(CONFIG_HOME, exist_ok=True)
    os.makedirs(WORKSPACE_PATH, exist_ok=True)
    # Ensure boot config dir exists
    os.makedirs(BOOT_CONFIG_PATH, exist_ok=True)

def load_config() -> SwarmbotConfig:
    ensure_dirs()
    if not os.path.exists(CONFIG_PATH):
        # Create default config with 2 providers (from default_factory)
        cfg = SwarmbotConfig()
        save_config(cfg)
        return cfg
    
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            
        cfg = SwarmbotConfig()
        
        # 1. Load Providers (Priority: providers list > provider object)
        if "providers" in data and isinstance(data["providers"], list) and len(data["providers"]) > 0:
            cfg.providers = []
            for p_data in data["providers"]:
                p = ProviderConfig()
                for k, v in p_data.items():
                    if hasattr(p, k):
                        setattr(p, k, v)
                cfg.providers.append(p)
        elif "provider" in data:
            # Migration: Use existing provider as primary, add backup template
            p = ProviderConfig()
            for k, v in data["provider"].items():
                if hasattr(p, k):
                    setattr(p, k, v)
            p.name = "primary"
            # Keep old provider + add backup template
            cfg.providers = [p, ProviderConfig(name="backup")]
            # Clean up old key on next save implicitly by not loading it into a field
            
        # 2. Load Swarm Settings
        if "swarm" in data:
            for k, v in data["swarm"].items():
                if k == "agent_count": # Migration: agent_count -> max_agents
                    cfg.swarm.max_agents = v
                elif hasattr(cfg.swarm, k):
                    setattr(cfg.swarm, k, v)
                    
        # 3. Load Tools
        if "tools" in data:
            t_data = data["tools"]
            if "fs" in t_data: cfg.tools.fs = t_data["fs"]
            if "shell" in t_data: cfg.tools.shell = t_data["shell"]
            if "exec" in t_data: cfg.tools.exec = t_data["exec"]
            
        # 4. Load Channels
        if "channels" in data:
            cfg.channels = {}
            for ch_name, ch_data in data["channels"].items():
                ch_cfg = ChannelConfig()
                # Handle simple dict or structured
                conf_dict = ch_data.get("config", {}) if "config" in ch_data else ch_data
                
                if "enabled" in ch_data: ch_cfg.enabled = ch_data["enabled"]
                if "app_id" in ch_data: ch_cfg.app_id = ch_data["app_id"]
                if "app_secret" in ch_data: ch_cfg.app_secret = ch_data["app_secret"]
                if "encrypt_key" in ch_data: ch_cfg.encrypt_key = ch_data["encrypt_key"]
                if "verification_token" in ch_data: ch_cfg.verification_token = ch_data["verification_token"]
                if "token" in ch_data: ch_cfg.token = ch_data["token"]
                
                # Copy other keys to config dict
                for k, v in ch_data.items():
                    if k not in ["enabled", "app_id", "app_secret", "encrypt_key", "verification_token", "token", "config"]:
                        ch_cfg.config[k] = v
                # Merge nested config if present
                if "config" in ch_data and isinstance(ch_data["config"], dict):
                    ch_cfg.config.update(ch_data["config"])
                    
                cfg.channels[ch_name] = ch_cfg

        # 5. Load Daemon
        if "daemon" in data:
            for k, v in data["daemon"].items():
                if hasattr(cfg.daemon, k):
                    setattr(cfg.daemon, k, v)

        # 6. Load Autonomous
        if "autonomous" in data:
            auto_data = data["autonomous"]
            # Handle provider specifically to ensure it's a ProviderConfig object
            if "provider" in auto_data and isinstance(auto_data["provider"], dict):
                p_data = auto_data["provider"]
                p = ProviderConfig()
                for k, v in p_data.items():
                    if hasattr(p, k):
                        setattr(p, k, v)
                cfg.autonomous.provider = p
            
            for k, v in auto_data.items():
                if k == "provider": continue
                if hasattr(cfg.autonomous, k):
                    setattr(cfg.autonomous, k, v)

        # Sync environment variables from primary provider
        if cfg.providers:
            primary = cfg.providers[0]
            if primary.base_url: os.environ["OPENAI_API_BASE"] = primary.base_url
            if primary.api_key: os.environ["OPENAI_API_KEY"] = primary.api_key
            if primary.model: os.environ["LITELLM_MODEL"] = primary.model

        return cfg

    except Exception as e:
        print(f"Error loading config: {e}")
        # Return default with 2 providers if load fails
        return SwarmbotConfig()


def save_config(cfg: SwarmbotConfig) -> None:
    ensure_dirs()

    # Prepare channels dict
    channels_dict = {}
    for name, c_cfg in cfg.channels.items():
        # Flatten structure for JSON if desired, or keep nested.
        # Using nested approach for clarity in JSON
        c_dict = {
            "enabled": c_cfg.enabled,
            "app_id": c_cfg.app_id,
            "app_secret": c_cfg.app_secret,
            "encrypt_key": c_cfg.encrypt_key,
            "verification_token": c_cfg.verification_token,
            "token": c_cfg.token,
            "config": c_cfg.config
        }
        channels_dict[name] = c_dict

    # Prepare providers list
    providers_list = [asdict(p) for p in cfg.providers]

    data = {
        "providers": providers_list,
        "swarm": asdict(cfg.swarm),
        "tools": asdict(cfg.tools),
        "channels": channels_dict,
        "daemon": asdict(cfg.daemon),
        "autonomous": asdict(cfg.autonomous),
    }

    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


class ConfigChangeListener:
    """配置变化监听器接口"""

    def on_config_change(self, old_config: SwarmbotConfig, new_config: SwarmbotConfig):
        """配置变化时的回调"""
        pass


class ConfigHotReloader:
    """
    配置热重载器

    功能:
    1. 监听配置文件变化
    2. 自动重新加载配置
    3. 通知注册的监听器
    4. 支持部分配置动态生效
    """

    _instance: Optional["ConfigHotReloader"] = None

    @classmethod
    def get_instance(cls) -> "ConfigHotReloader":
        """获取单例实例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._listeners: List[ConfigChangeListener] = []
        self._last_modified: float = 0
        self._last_config: Optional[SwarmbotConfig] = None
        self._watch_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._check_interval = 5  # 5 秒检查一次

        # 初始化时记录最后修改时间
        self._init_last_modified()

    def _init_last_modified(self):
        """初始化最后修改时间"""
        if os.path.exists(CONFIG_PATH):
            try:
                self._last_modified = os.path.getmtime(CONFIG_PATH)
            except OSError:
                self._last_modified = 0

    def register_listener(self, listener: ConfigChangeListener):
        """注册配置变化监听器"""
        if listener not in self._listeners:
            self._listeners.append(listener)

    def unregister_listener(self, listener: ConfigChangeListener):
        """注销配置变化监听器"""
        if listener in self._listeners:
            self._listeners.remove(listener)

    def start_watching(self):
        """开始监听配置变化"""
        if self._watch_thread is not None and self._watch_thread.is_alive():
            return  # 已经在运行

        self._stop_event.clear()
        self._watch_thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._watch_thread.start()

    def stop_watching(self):
        """停止监听配置变化"""
        self._stop_event.set()
        if self._watch_thread:
            self._watch_thread.join(timeout=2)
            self._watch_thread = None

    def _watch_loop(self):
        """监听配置变化"""
        while not self._stop_event.is_set():
            try:
                self._check_for_changes()
            except Exception as e:
                print(f"[ConfigHotReloader] Error in watch loop: {e}")

            if self._stop_event.wait(self._check_interval):
                break

    def _check_for_changes(self):
        """检查配置是否有变化"""
        if not os.path.exists(CONFIG_PATH):
            return

        try:
            current_modified = os.path.getmtime(CONFIG_PATH)
        except OSError:
            return

        if current_modified > self._last_modified:
            # 配置文件已修改，重新加载
            self._last_modified = current_modified
            self._reload_config()

    def _reload_config(self):
        """重新加载配置并通知监听器"""
        print("[ConfigHotReloader] Config file changed, reloading...")

        old_config = self._last_config
        new_config = load_config()

        # 检测变化的配置项
        changes = self._detect_changes(old_config, new_config)

        if changes:
            print(f"[ConfigHotReloader] Detected changes: {', '.join(changes)}")

            # 应用动态生效的配置
            self._apply_dynamic_changes(changes, new_config)

        # 更新缓存
        self._last_config = new_config

        # 通知监听器
        for listener in self._listeners:
            try:
                listener.on_config_change(old_config, new_config)
            except Exception as e:
                print(f"[ConfigHotReloader] Listener error: {e}")

    def _detect_changes(self, old_config: Optional[SwarmbotConfig], new_config: SwarmbotConfig) -> List[str]:
        """检测变化的配置项"""
        if old_config is None:
            return ["initial_load"]

        changes = []

        # 检测 providers 变化
        if len(old_config.providers) != len(new_config.providers):
            changes.append("providers_count")
        else:
            for i, (old_p, new_p) in enumerate(zip(old_config.providers, new_config.providers)):
                if old_p.base_url != new_p.base_url or old_p.api_key != new_p.api_key or old_p.model != new_p.model:
                    changes.append(f"provider_{i}")

        # 检测 swarm 设置变化
        if old_config.swarm.max_agents != new_config.swarm.max_agents:
            changes.append("swarm.max_agents")
        if old_config.swarm.display_mode != new_config.swarm.display_mode:
            changes.append("swarm.display_mode")

        # 检测 autonomous 设置变化
        if old_config.autonomous.tick_seconds != new_config.autonomous.tick_seconds:
            changes.append("autonomous.tick_seconds")
        if old_config.autonomous.enabled != new_config.autonomous.enabled:
            changes.append("autonomous.enabled")

        # 检测 tools 设置变化
        if old_config.tools.exec.default_timeout_seconds != new_config.tools.exec.default_timeout_seconds:
            changes.append("tools.exec.timeout")

        return changes

    def _apply_dynamic_changes(self, changes: List[str], new_config: SwarmbotConfig):
        """应用动态变化的配置"""
        for change in changes:
            if change.startswith("provider_"):
                # Provider 变化 - 更新环境变量
                idx = int(change.split("_")[1]) if "_" in change else 0
                if idx < len(new_config.providers):
                    provider = new_config.providers[idx]
                    if provider.base_url:
                        os.environ["OPENAI_API_BASE"] = provider.base_url
                    if provider.api_key:
                        os.environ["OPENAI_API_KEY"] = provider.api_key
                    if provider.model:
                        os.environ["LITELLM_MODEL"] = provider.model
                print(f"[ConfigHotReloader] Applied provider changes, updated environment variables")

            elif change == "autonomous.enabled" and not new_config.autonomous.enabled:
                print(f"[ConfigHotReloader] Autonomous mode disabled")

            elif change == "autonomous.tick_seconds":
                print(f"[ConfigHotReloader] Autonomous tick interval changed to {new_config.autonomous.tick_seconds}s")

        print(f"[ConfigHotReloader] Applied {len(changes)} dynamic changes")

    def get_current_config(self) -> SwarmbotConfig:
        """获取当前配置"""
        if self._last_config is None:
            self._last_config = load_config()
        return self._last_config

    def force_reload(self) -> SwarmbotConfig:
        """强制重新加载配置"""
        self._last_modified = 0
        self._reload_config()
        return self._last_config
