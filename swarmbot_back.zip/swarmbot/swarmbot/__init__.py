__version__ = "1.8.0"

__all__ = [
    "CoreAgent",
    "MemoryStore",
    "QMDMemoryStore",
]

import importlib
import sys

try:
    sys.modules["nanobot"] = importlib.import_module("swarmbot.nanobot")
except Exception:
    pass

from .core.agent import CoreAgent
from .memory.base import MemoryStore
from .memory.qmd import QMDMemoryStore
