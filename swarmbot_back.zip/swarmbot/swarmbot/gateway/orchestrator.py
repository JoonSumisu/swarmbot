"""
Gateway-MasterAgent 统合架构 (v2.0)

统一消息编排器，整合：
- 普通对话能力（直接回复简单问题）
- 推理工具调度（InferenceLoop Standard / Supervised / SwarmsWorker）
- 主动思考 (Autonomous Engine) 输出整合
"""

from __future__ import annotations

import asyncio
import heapq
import json
import os
import re
import time
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

from loguru import logger


class Priority(IntEnum):
    """消息优先级"""
    P0_USER_RESPONSE = 0      # 用户消息响应 (最高)
    P1_HUMAN_REQUEST = 1      # 人在回路请求 / 紧急告警
    P2_BUNDLE_REPORT = 2      # Bundle 优化报告
    P3_SYSTEM_INFO = 3        # 系统信息


@dataclass(order=True)
class PrioritizedMessage:
    """带优先级的消息"""
    priority: int
    timestamp: int = field(compare=False)
    content: str = field(compare=False)
    msg_type: str = field(compare=False)
    metadata: Dict[str, Any] = field(default_factory=dict, compare=False)


class PriorityMessageQueue:
    """优先级消息队列"""

    def __init__(self, max_size: int = 100):
        self._heap: List[PrioritizedMessage] = []
        self._max_size = max_size
        self._lock = asyncio.Lock()

    async def put(self, msg: PrioritizedMessage):
        """添加消息到队列"""
        async with self._lock:
            if len(self._heap) >= self._max_size:
                heapq.heappop(self._heap)
            heapq.heappush(self._heap, msg)

    async def get(self) -> Optional[PrioritizedMessage]:
        """获取最高优先级的消息"""
        async with self._lock:
            if self._heap:
                return heapq.heappop(self._heap)
            return None

    async def peek(self) -> Optional[PrioritizedMessage]:
        """查看最高优先级的消息但不移除"""
        async with self._lock:
            if self._heap:
                return self._heap[0]
            return None

    def __len__(self) -> int:
        return len(self._heap)


class OutputBuffer:
    """输出缓冲区，用于整合多个消息"""

    def __init__(self, max_wait_seconds: float = 3.0):
        self._buffer: List[PrioritizedMessage] = []
        self._lock = asyncio.Lock()
        self._max_wait = max_wait_seconds
        self._min_wait = 0.5
        self._first_msg_time: Optional[float] = None
        self._content_threshold = 500

    async def buffer(self, msg: PrioritizedMessage):
        """缓冲消息"""
        async with self._lock:
            self._buffer.append(msg)
            if self._first_msg_time is None:
                self._first_msg_time = time.time()

    async def flush(self) -> List[str]:
        """刷新缓冲区，返回所有缓冲的内容"""
        async with self._lock:
            if not self._buffer:
                return []
            self._buffer.sort(key=lambda m: (m.priority, m.timestamp))
            contents = [m.content for m in self._buffer]
            self._buffer.clear()
            self._first_msg_time = None
            return contents

    async def should_flush(self) -> bool:
        """检查是否应该刷新缓冲区"""
        async with self._lock:
            if not self._buffer:
                return False
            if self._first_msg_time is None:
                return True

            has_p0 = any(m.priority == Priority.P0_USER_RESPONSE for m in self._buffer)
            has_p1 = any(m.priority == Priority.P1_HUMAN_REQUEST for m in self._buffer)
            total_chars = sum(len(m.content) for m in self._buffer)
            elapsed = time.time() - self._first_msg_time

            if has_p0 and elapsed >= self._min_wait:
                return True
            if has_p1 and elapsed >= self._min_wait:
                return True
            if total_chars >= self._content_threshold:
                return True
            if len(self._buffer) >= 3 and elapsed >= self._max_wait * 0.5:
                return True
            if elapsed >= self._max_wait:
                return True
            return False

    def clear(self):
        """清空缓冲区"""
        self._buffer.clear()
        self._first_msg_time = None

    def get_buffer_stats(self) -> Dict[str, Any]:
        """获取缓冲区统计信息"""
        if not self._buffer:
            return {"count": 0, "total_chars": 0, "has_p0": False, "has_p1": False, "elapsed": 0}
        return {
            "count": len(self._buffer),
            "total_chars": sum(len(m.content) for m in self._buffer),
            "has_p0": any(m.priority == Priority.P0_USER_RESPONSE for m in self._buffer),
            "has_p1": any(m.priority == Priority.P1_HUMAN_REQUEST for m in self._buffer),
            "elapsed": time.time() - (self._first_msg_time or time.time()),
        }


class SharedContextPool:
    """
    上下文共享池 - 基于 .md 文件的持久化存储
    用于 InferenceLoop 读取 Autonomous 最近发现的问题和状态
    """

    def __init__(self, workspace_path: Path):
        self.file_path = workspace_path / "context_memory.md"
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()
        self._ensure_file_exists()

    def _ensure_file_exists(self):
        """确保文件存在并初始化"""
        if not self.file_path.exists():
            self.file_path.write_text(
                "# Context Memory - 上下文共享池\n\n"
                "## Active Bundle Status\n\n"
                "| bundle_id | timestamp | status | details |\n"
                "|-----------|-----------|--------|---------|\n",
                encoding="utf-8"
            )

    def _parse_table(self, content: str) -> Dict[str, Dict[str, Any]]:
        """解析 Markdown 表格"""
        status_map = {}
        lines = content.split("\n")
        in_table = False

        for line in lines:
            line = line.strip()
            if line.startswith("| bundle_id |"):
                in_table = True
                continue
            if in_table and line.startswith("|---"):
                continue
            if in_table and line.startswith("|"):
                parts = [p.strip() for p in line.split("|") if p.strip()]
                if len(parts) >= 4:
                    bundle_id = parts[0]
                    status_map[bundle_id] = {
                        "timestamp": parts[1],
                        "status": parts[2],
                        "details": parts[3],
                    }
            elif in_table and not line.startswith("|"):
                in_table = False

        return status_map

    def _build_table(self, status_map: Dict[str, Dict[str, Any]]) -> str:
        """构建 Markdown 表格"""
        header = (
            "# Context Memory - 上下文共享池\n\n"
            "## Active Bundle Status\n\n"
            "| bundle_id | timestamp | status | details |\n"
            "|-----------|-----------|--------|---------|\n"
        )
        now = time.time()
        cutoff = now - (24 * 60 * 60)

        rows = []
        for bundle_id, data in status_map.items():
            try:
                ts = float(data.get("timestamp", 0))
                if ts >= cutoff:
                    rows.append(f"| {bundle_id} | {data['timestamp']} | {data['status']} | {data['details']} |")
            except (ValueError, TypeError):
                pass

        return header + "\n".join(rows) + "\n"

    async def update(self, bundle_id: str, status: str, details: str):
        """更新 Bundle 状态"""
        async with self._lock:
            content = self.file_path.read_text(encoding="utf-8")
            status_map = self._parse_table(content)
            status_map[bundle_id] = {
                "timestamp": str(time.time()),
                "status": status,
                "details": details,
            }
            new_content = self._build_table(status_map)
            self.file_path.write_text(new_content, encoding="utf-8")

    def update_sync(self, bundle_id: str, status: str, details: str):
        """同步版本：更新 Bundle 状态"""
        content = self.file_path.read_text(encoding="utf-8")
        status_map = self._parse_table(content)
        status_map[bundle_id] = {
            "timestamp": str(time.time()),
            "status": status,
            "details": details,
        }
        new_content = self._build_table(status_map)
        self.file_path.write_text(new_content, encoding="utf-8")

    async def get_all_status(self) -> Dict[str, Dict[str, Any]]:
        """获取所有 Bundle 状态"""
        async with self._lock:
            content = self.file_path.read_text(encoding="utf-8")
            status_map = self._parse_table(content)
            now = time.time()
            cutoff = now - (24 * 60 * 60)
            filtered = {}
            for bundle_id, data in status_map.items():
                try:
                    ts = float(data.get("timestamp", 0))
                    if ts >= cutoff:
                        filtered[bundle_id] = data
                except (ValueError, TypeError):
                    pass
            return filtered

    def get_all_status_sync(self) -> Dict[str, Dict[str, Any]]:
        """同步版本：获取所有 Bundle 状态"""
        content = self.file_path.read_text(encoding="utf-8")
        status_map = self._parse_table(content)
        now = time.time()
        cutoff = now - (24 * 60 * 60)
        filtered = {}
        for bundle_id, data in status_map.items():
            try:
                ts = float(data.get("timestamp", 0))
                if ts >= cutoff:
                    filtered[bundle_id] = data
            except (ValueError, TypeError):
                pass
        return filtered

    async def get_context_for_task(
        self,
        task_desc: str = "",
        relevant_bundles: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """为任务获取相关上下文"""
        all_status = await self.get_all_status()
        if not all_status:
            return {"bundle_status": {}, "all_status": {}, "scored_context": []}

        if relevant_bundles:
            filtered = {k: v for k, v in all_status.items() if k in relevant_bundles}
            scored = self._score_context(filtered, task_desc)
            return {"bundle_status": filtered, "all_status": all_status, "scored_context": scored}

        scored = self._score_context(all_status, task_desc)
        return {"bundle_status": all_status, "all_status": all_status, "scored_context": scored}

    def get_context_for_task_sync(
        self,
        task_desc: str = "",
        relevant_bundles: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """同步版本：为任务获取相关上下文"""
        all_status = self.get_all_status_sync()
        if not all_status:
            return {"bundle_status": {}, "all_status": {}, "scored_context": []}

        if relevant_bundles:
            filtered = {k: v for k, v in all_status.items() if k in relevant_bundles}
            scored = self._score_context(filtered, task_desc)
            return {"bundle_status": filtered, "all_status": all_status, "scored_context": scored}

        scored = self._score_context(all_status, task_desc)
        return {"bundle_status": all_status, "all_status": all_status, "scored_context": scored}

    def _score_context(
        self,
        status_map: Dict[str, Dict[str, Any]],
        task_desc: str = ""
    ) -> List[Dict[str, Any]]:
        """对上下文进行评分"""
        scored = []
        now = time.time()

        for bundle_id, data in status_map.items():
            relevance = self._compute_semantic_relevance(bundle_id, data, task_desc)
            recency = self._compute_recency_weight(data.get("timestamp", 0), now)
            severity = self._compute_severity_weight(data.get("status", "normal"))
            total_score = relevance * 0.5 + recency * 0.3 + severity * 0.2

            scored.append({
                "bundle_id": bundle_id,
                "data": data,
                "relevance_score": relevance,
                "recency_score": recency,
                "severity_score": severity,
                "total_score": total_score,
            })

        scored.sort(key=lambda x: x["total_score"], reverse=True)
        return scored

    def _compute_semantic_relevance(
        self,
        bundle_id: str,
        data: Dict[str, Any],
        task_desc: str
    ) -> float:
        """计算语义相关性"""
        if not task_desc:
            return 0.5

        import re
        task_lower = task_desc.lower()
        bundle_lower = bundle_id.lower()
        details_lower = data.get("details", "").lower()

        task_keywords = self._extract_keywords(task_lower)
        if not task_keywords:
            return 0.3

        match_count = 0
        for keyword in task_keywords:
            if keyword in bundle_lower:
                match_count += 2
            elif keyword in details_lower:
                match_count += 1

        max_possible = len(task_keywords) * 2
        relevance = match_count / max_possible if max_possible > 0 else 0
        return min(1.0, relevance)

    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        import re
        stopwords = {"的", "了", "在", "是", "我", "有", "和", "就", "不", "与", "等", "及", "一个", "一些"}
        words = re.findall(r'[a-zA-Z0-9\u4e00-\u9fff]+', text)
        return [w for w in words if w.lower() not in stopwords and len(w) > 1]

    def _compute_recency_weight(self, timestamp: str, now: float = None) -> float:
        """计算时效性权重 - 指数衰减"""
        if now is None:
            now = time.time()
        try:
            ts = float(timestamp)
        except (ValueError, TypeError):
            return 0.0

        delta = now - ts
        if delta < 0:
            return 1.0

        half_life = 1800  # 30 分钟
        weight = 2 ** (-delta / half_life)
        return max(0.0, min(1.0, weight))

    def _compute_severity_weight(self, status: str) -> float:
        """计算严重性权重"""
        status_lower = (status or "unknown").lower()
        severity_map = {
            "critical": 1.0, "error": 1.0,
            "warning": 0.8, "warn": 0.8,
            "normal": 0.5, "success": 0.5,
            "info": 0.4, "unknown": 0.3,
        }
        return severity_map.get(status_lower, 0.3)


class GatewayMasterAgent:
    """
    Gateway-MasterAgent 统一编排器 (v2.0)

    核心职责:
    - 加载 boot 文件、上下文记忆、记忆快照
    - 加载工具列表和 Skill 列表
    - 内置普通对话能力（直接回复简单问题、寒暄）
    - 决策是否使用推理工具（InferenceLoop 或其他）或由用户指定
    - 读取 OutputBuffer（主动思考结果）
    - 将用户反馈/调整要求回传给 Autonomous Engine
    """

    # 简单对话模式关键词
    SIMPLE_PATTERNS = [
        "你好", "早", "好", "嗨", "hello", "hi", "hey",
        "好久不见", "最近怎么样", "过得如何",
        "谢谢", "感谢", "thanks", "thank you",
        "好的", "好哒", "收到", "没问题",
        "在吗", "在嘛", "忙吗", "有空吗",
        "再见", "拜拜", "bye", "回聊",
    ]

    def __init__(self, workspace_path: Path, config=None):
        self.workspace_path = workspace_path
        self.config = config

        # Core components
        self.message_queue = PriorityMessageQueue()
        self.output_buffer = OutputBuffer(max_wait_seconds=3.0)
        self.context_pool = SharedContextPool(workspace_path)

        # CommunicationHub - 双向沟通窗口（替换 autonomous_feedback_queue）
        from .communication_hub import CommunicationHub
        self.comm_hub = CommunicationHub(workspace_path)

        # Callback for sending messages
        self._send_callback: Optional[Callable] = None

        # Active loop tracking
        self._active_loops: Dict[str, Any] = {}

        # LLM client
        self._llm = None

        # Boot files cache
        self._boot_cache: Dict[str, str] = {}

        # Skills and tools cache
        self._skills_cache: Dict[str, Any] = {}
        self._tools_cache: List[str] = []

    def set_send_callback(self, callback: Callable):
        """设置发送消息的回调函数"""
        self._send_callback = callback

    def has_active_loop(self, chat_id: str) -> bool:
        """检查是否有活跃的 InferenceLoop"""
        return chat_id in self._active_loops

    def register_loop(self, chat_id: str, loop: Any):
        """注册活跃的 InferenceLoop"""
        self._active_loops[chat_id] = loop
        logger.info(f"Registered active loop for chat_id: {chat_id}")

    def unregister_loop(self, chat_id: str):
        """注销活跃的 InferenceLoop"""
        if chat_id in self._active_loops:
            del self._active_loops[chat_id]
            logger.info(f"Unregistered loop for chat_id: {chat_id}")

    def _load_boot_file(self, filename: str) -> str:
        """Load boot file from disk."""
        if filename in self._boot_cache:
            return self._boot_cache[filename]

        paths = [
            os.path.expanduser(f"~/.swarmbot/boot/{filename}"),
            os.path.join(os.path.dirname(__file__), f"../../swarmbot/boot/{filename}"),
        ]
        content = ""
        for p in paths:
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                break

        self._boot_cache[filename] = content
        return content

    def _load_inference_tools_config(self) -> List[Dict[str, Any]]:
        """
        加载推理工具配置文件 (inference_tools.md)
        解析 MD 文件，提取每个工具的定义。

        配置驱动设计：工具定义完全来自配置文件，代码中无硬编码。
        """
        content = self._load_boot_file("inference_tools.md")
        if not content:
            return []

        tools = []
        current_tool: Dict[str, Any] = {}
        current_section = None

        for line in content.split('\n'):
            line_stripped = line.strip()

            # 检测新工具开始（### 标题）
            if line_stripped.startswith('### ') and not line_stripped.startswith('####'):
                if current_tool and 'tool_id' in current_tool:
                    tools.append(current_tool)
                current_tool = {'name': line_stripped.replace('###', '').strip()}
                current_section = None

            # 工具 ID
            if line_stripped.startswith('**工具 ID**'):
                match = re.search(r'`([^`]+)`', line_stripped)
                if match:
                    current_tool['tool_id'] = match.group(1)

            # 类名
            if line_stripped.startswith('**类名**'):
                match = re.search(r'`([^`]+)`', line_stripped)
                if match:
                    current_tool['class_name'] = match.group(1)

            # 模块路径
            if line_stripped.startswith('**模块路径**'):
                match = re.search(r'`([^`]+)`', line_stripped)
                if match:
                    current_tool['module_path'] = match.group(1)

            # 推理步骤
            if line_stripped.startswith('**推理步骤**'):
                current_section = 'steps'
                current_tool['reasoning_steps'] = []
            elif current_section == 'steps' and line_stripped:
                if line_stripped.startswith('**'):
                    current_section = None
                elif line_stripped.startswith('-') or line_stripped[0].isdigit():
                    current_tool['reasoning_steps'].append(line_stripped)

            # 适用场景
            if line_stripped.startswith('**适用场景**'):
                current_section = 'scenarios'
                current_tool['scenarios'] = []
            elif current_section == 'scenarios' and line_stripped:
                if line_stripped.startswith('**'):
                    current_section = None
                else:
                    current_tool['scenarios'].append(line_stripped)

        if current_tool and 'tool_id' in current_tool:
            # 跳过占位符工具 ID
            if current_tool['tool_id'] not in ['tool_id', 'xxx']:
                tools.append(current_tool)

        return tools

    def _decide_inference_tool(self, user_input: str, context: str = "") -> str:
        """
        根据配置文件决定使用哪个推理工具

        流程:
        1. 读取 inference_tools.md 配置
        2. 使用 LLM 理解每个工具的推理步骤和适用场景
        3. LLM 根据用户问题选择最适合的工具

        配置驱动设计：工具理解完全基于配置描述，无硬编码规则。
        """
        tools = self._load_inference_tools_config()

        if not tools:
            return 'standard'

        # 构建工具描述的 prompt
        tool_descriptions = []
        for tool in tools:
            desc = f"工具 ID: {tool['tool_id']}\n"
            if 'reasoning_steps' in tool:
                desc += f"推理步骤:\n" + "\n".join(tool['reasoning_steps']) + "\n"
            if 'scenarios' in tool:
                desc += f"适用场景:\n" + "\n".join(tool['scenarios']) + "\n"
            tool_descriptions.append(desc)

        tools_context = "\n---\n".join(tool_descriptions)

        # 使用 LLM 决策
        prompt = (
            f"你是工具选择器。根据用户问题，选择最适合的推理工具。\n\n"
            f"可用工具:\n{tools_context}\n"
            f"用户问题：{user_input}\n\n"
            f"分析用户问题的特征，匹配各工具的适用场景，选择最合适的工具。\n"
            f"只输出工具 ID，不要输出其他内容。"
        )

        llm = self._get_llm()
        response = llm.completion(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=50
        )

        tool_id = response.get("choices", [{}])[0].get("message", {}).get("content", "").strip()

        # 验证返回的工具 ID 是否有效
        valid_ids = [t['tool_id'] for t in tools]
        if tool_id in valid_ids:
            return tool_id

        # 兜底：返回第一个工具
        return tools[0]['tool_id'] if tools else 'standard'

    def _get_llm(self):
        """Lazy load LLM client."""
        if self._llm is None:
            from ..llm_client import OpenAICompatibleClient
            from ..config_manager import load_config
            config = self.config or load_config()
            self._llm = OpenAICompatibleClient.from_provider(providers=config.providers)
        return self._llm

    def _should_use_simple_direct(self, user_input: str) -> bool:
        """
        判断是否应该使用简单直接回复模式。

        简单对话特征：
        - 纯寒暄/问候（你好、好久不见、早上好等）
        - 简单感谢（谢谢、感谢等）
        - 简短确认（好的、是的、没问题等）
        - 闲聊（在吗、忙吗等）
        """
        # 长度阈值：非常短的消息可能是简单对话
        if len(user_input.strip()) < 15:
            for p in self.SIMPLE_PATTERNS:
                if p in user_input.lower():
                    return True

        # 包含明显的情感表达但无实质任务
        if len(user_input.strip()) < 30:
            if any(kw in user_input for kw in ["哈哈", "呵呵", "嘻嘻"]):
                if not any(kw in user_input for kw in ["怎么", "如何", "什么", "为什么", "哪里", "谁", "多少", "吗？"]):
                    return True

        return False

    async def handle_user_message(self, message: Any) -> str:
        """
        处理用户消息

        v2.0 架构：
        1. 首先判断是否为简单对话（直接回复）
        2. 否则决策使用哪个推理工具
        3. 调用推理工具执行
        4. 整合输出
        """
        chat_id = getattr(message, 'chat_id', 'unknown')
        content = getattr(message, 'content', '')

        # Create priority message
        msg = PrioritizedMessage(
            priority=Priority.P0_USER_RESPONSE,
            timestamp=int(time.time() * 1000),
            content=content,
            msg_type="user_message",
            metadata={"chat_id": chat_id}
        )

        await self.message_queue.put(msg)
        self.register_loop(chat_id, message)

        # Decision: Simple direct or reasoning tool
        if self._should_use_simple_direct(content):
            logger.info(f"[MasterAgent] Route: simple_direct (greeting detected)")
            response = await self._handle_simple_direct(content, chat_id)
        else:
            logger.info(f"[MasterAgent] Route: reasoning tool required")
            # Default to InferenceLoop Standard for now
            response = await self._handle_with_inference_tool(content, chat_id)

        return response

    def handle_user_message_sync(self, message: Any) -> str:
        """
        处理用户消息（同步版本）- 用于 CLI run 模式

        v2.0 架构：
        1. 首先判断是否为简单对话（直接回复）
        2. 否则决策使用哪个推理工具
        3. 调用推理工具执行
        4. 整合输出
        """
        chat_id = getattr(message, 'chat_id', 'unknown')
        content = getattr(message, 'content', '')

        # Decision: Simple direct or reasoning tool
        if self._should_use_simple_direct(content):
            logger.info(f"[MasterAgent] Route: simple_direct (greeting detected)")
            return self._handle_simple_direct_sync(content, chat_id)
        else:
            logger.info(f"[MasterAgent] Route: reasoning tool required")
            return self._handle_with_inference_tool_sync(content, chat_id)

    def _handle_simple_direct(self, user_input: str, chat_id: str) -> str:
        """
        处理简单直接对话（异步版本）

        Flow: Input -> Master Agent (LLM) -> Memory -> End
        """
        return self._handle_simple_direct_sync(user_input, chat_id)

    def _handle_simple_direct_sync(self, user_input: str, chat_id: str) -> str:
        """
        处理简单直接对话（同步版本）

        Flow: Input -> Master Agent (LLM) -> Memory -> End
        """
        print(f"[MasterAgent Simple] Start: {user_input[:50]}...")

        # Get LLM
        llm = self._get_llm()

        # Load boot files for context
        soul = self._load_boot_file("SOUL.md")

        # Build prompt
        prompt = (
            "你是 Master Agent。请直接回答用户的问题。\n"
            f"用户问题：{user_input}\n\n"
            "要求：简洁、直接、友好、自然地回答。\n"
            f"Persona: {soul[:500] if soul else 'Helpful assistant'}"
        )

        # Call LLM (use completion method instead of chat_completion)
        response = llm.completion(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=500
        )

        final_response = response.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
        if not final_response:
            final_response = "你好！有什么我可以帮助你的吗？"

        # Save to memory
        self._save_to_memory(user_input, final_response, chat_id)

        print(f"[MasterAgent Simple] Complete: {final_response[:50]}...")
        return final_response

    async def _handle_with_inference_tool(self, user_input: str, chat_id: str) -> str:
        """
        使用推理工具处理复杂任务

        工具列表从 inference_tools.md 动态加载
        """
        print(f"[MasterAgent] Handling with inference tool...")

        # Decide which inference tool to use (reads from config file)
        tool_name = self._decide_inference_tool(user_input)
        logger.info(f"[MasterAgent] Selected inference tool: {tool_name}")

        # Load boot files for context
        swarmboot = self._load_boot_file("swarmboot.md")
        soul = self._load_boot_file("SOUL.md")

        # Get context from context pool
        context_data = await self.context_pool.get_context_for_task(task_desc=user_input)
        context_str = self.format_context_for_prompt(context_data)

        # Execute selected tool dynamically
        response = self._run_inference_tool_by_name(tool_name, user_input, chat_id, context_str)

        return response

    def _handle_with_inference_tool_sync(self, user_input: str, chat_id: str) -> str:
        """
        使用推理工具处理复杂任务（同步版本）

        工具列表从 inference_tools.md 动态加载
        """
        print(f"[MasterAgent] Handling with inference tool...")

        # Decide which inference tool to use (reads from config file)
        tool_name = self._decide_inference_tool(user_input)
        logger.info(f"[MasterAgent] Selected inference tool: {tool_name}")

        # Load boot files for context
        swarmboot = self._load_boot_file("swarmboot.md")
        soul = self._load_boot_file("SOUL.md")

        # Get context from context pool (sync version)
        context_data = self.context_pool.get_context_for_task_sync(task_desc=user_input)
        context_str = self.format_context_for_prompt(context_data)

        # Execute selected tool dynamically
        response = self._run_inference_tool_by_name(tool_name, user_input, chat_id, context_str)

        return response

    def _run_inference_tool_by_name(self, tool_name: str, user_input: str, chat_id: str, context: str = "") -> str:
        """
        根据工具名称动态加载并执行推理工具

        配置驱动设计：工具类和模块路径从配置文件读取，使用 importlib 动态加载，无硬编码。
        """
        tools_config = self._load_inference_tools_config()
        tool_config = next((t for t in tools_config if t['tool_id'] == tool_name), None)

        if not tool_config:
            logger.warning(f"[MasterAgent] Tool '{tool_name}' not found in config, using standard")
            tool_name = "standard"
            tool_config = next((t for t in tools_config if t['tool_id'] == "standard"), None)

        if not tool_config:
            # Ultimate fallback
            return "抱歉，系统暂时无法处理您的请求。"

        class_name = tool_config.get('class_name')
        module_path = tool_config.get('module_path')

        if not class_name or not module_path:
            logger.warning(f"[MasterAgent] Tool '{tool_name}' missing class_name or module_path")
            return "抱歉，工具配置不完整。"

        try:
            from ..config_manager import load_config
            config = self.config or load_config()

            # 使用 importlib 动态导入工具类（配置驱动，无硬编码）
            import importlib
            module = importlib.import_module(module_path)
            loop_class = getattr(module, class_name)
            loop = loop_class(config, str(self.workspace_path))

            self.register_loop(chat_id, loop)
            response = loop.run(user_input, chat_id)
            self.unregister_loop(chat_id)
            return response

        except ImportError as e:
            logger.error(f"[MasterAgent] Failed to import tool {tool_name} from {module_path}: {e}")
            return f"工具加载失败：{e}"
        except Exception as e:
            logger.error(f"[MasterAgent] Tool execution failed: {e}")
            return f"处理失败：{e}"

            response = loop.run(user_input, chat_id)

            self.unregister_loop(chat_id)
            return response
        except Exception as e:
            logger.error(f"[MasterAgent] Tool execution failed: {e}")
            return f"处理失败：{e}"

    def _save_to_memory(self, user_input: str, response: str, chat_id: str):
        """Save conversation to memory."""
        try:
            from ..memory.session_memory import SessionMemory
            session_memory = SessionMemory(self.workspace_path)
            session_memory.add_turn(chat_id=chat_id, user_input=user_input, assistant_response=response)
        except Exception as e:
            logger.warning(f"[MasterAgent] Failed to save memory: {e}")

    async def handle_autonomous_request(self, request: Dict[str, Any]):
        """
        处理 Autonomous Engine 的请求 - 写入 CommunicationHub

        数据流：
        1. Autonomous Engine 发送请求到 CommunicationHub
        2. MasterAgent 消费请求并处理
        3. MasterAgent 将响应写回 CommunicationHub
        4. Autonomous Engine 读取响应
        """
        from .communication_hub import MessageType, MessagePriority

        report_type = request.get("type", "generic")
        bundle_id = request.get("bundle_id", "unknown")
        content = request.get("content", "")
        chat_id = request.get("chat_id", "")

        # 确定优先级
        priority = MessagePriority.NORMAL
        if report_type == "human_in_loop_request":
            priority = MessagePriority.CRITICAL
        elif request.get("severity") == "high" or "告警" in content:
            priority = MessagePriority.HIGH

        # 1. 写入 CommunicationHub
        if report_type == "human_in_loop_request":
            # 人在回路请求 - 需要用户确认
            checkpoint_data = request.get("checkpoint_data", {})
            msg_id = self.comm_hub.send_human_in_loop_request(
                content=content,
                loop_id=chat_id,
                stage=request.get("stage", "unknown"),
                checkpoint_data=checkpoint_data,
                conversation_id=chat_id,
            )
            logger.info(f"[MasterAgent] Human-in-loop request written to CommHub: {msg_id}")
        elif report_type == "status_update":
            # 状态更新
            msg_id = self.comm_hub.send_autonomous_status(
                content=content,
                bundle_id=bundle_id,
                status=request.get("status", "completed"),
                conversation_id=chat_id,
            )
            logger.info(f"[MasterAgent] Autonomous status written to CommHub: {msg_id}")
        else:
            # 普通请求
            msg_id = self.comm_hub.send_autonomous_request(
                content=content,
                bundle_id=bundle_id,
                conversation_id=chat_id,
            )
            logger.info(f"[MasterAgent] Autonomous request written to CommHub: {msg_id}")

        # 2. 同时发送到 OutputBuffer（如果需要即时显示给用户）
        out_priority = Priority.P2_BUNDLE_REPORT
        if priority == MessagePriority.CRITICAL:
            out_priority = Priority.P1_HUMAN_REQUEST
        elif priority == MessagePriority.HIGH:
            out_priority = Priority.P1_HUMAN_REQUEST

        msg = PrioritizedMessage(
            priority=out_priority,
            timestamp=int(time.time() * 1000),
            content=content,
            msg_type="autonomous_report",
            metadata={"bundle_id": bundle_id, "report_type": report_type}
        )

        # Update context pool
        await self.context_pool.update(
            bundle_id=bundle_id,
            status=request.get("status", "completed"),
            details=content[:200] if content else "No details"
        )

        # Check if there's an active loop
        if chat_id and self.has_active_loop(chat_id):
            # Buffer message for integration
            await self.output_buffer.buffer(msg)
            logger.info(f"Buffered autonomous report for bundle {bundle_id}")
        else:
            # Send directly
            await self._send_to_user(msg)
            logger.info(f"Sent autonomous report directly for bundle {bundle_id}")

    async def _send_to_user(self, msg: PrioritizedMessage):
        """发送消息给用户"""
        if self._send_callback:
            await self._send_callback(msg)

    async def flush_buffer_if_complete(self, chat_id: str):
        """在 InferenceLoop 完成后刷新缓冲的消息"""
        if await self.output_buffer.should_flush():
            contents = await self.output_buffer.flush()
            if contents and self._send_callback:
                combined = "\n\n---\n\n".join(contents)
                combined_msg = PrioritizedMessage(
                    priority=Priority.P0_USER_RESPONSE,
                    timestamp=int(time.time() * 1000),
                    content=combined,
                    msg_type="combined_response",
                    metadata={"chat_id": chat_id, "merged_count": len(contents)}
                )
                await self._send_to_user(combined_msg)
                logger.info(f"Flushed {len(contents)} buffered messages for chat_id: {chat_id}")

    async def get_context_for_loop(
        self,
        relevant_bundles: Optional[List[str]] = None,
        task_desc: str = ""
    ) -> Dict[str, Any]:
        """为 InferenceLoop 提供相关上下文"""
        return await self.context_pool.get_context_for_task(task_desc, relevant_bundles)

    def format_context_for_prompt(self, context: Dict[str, Any]) -> str:
        """将上下文格式化为可插入 prompt 的字符串"""
        lines = ["## 上下文共享池状态 (来自 Autonomous Engine)"]

        scored_context = context.get("scored_context", [])

        if scored_context:
            lines.append("\n### 相关 Bundle 状态 (按相关性排序):")
            for item in scored_context[:5]:
                bundle_id = item["bundle_id"]
                data = item["data"]
                score = item["total_score"]
                status = data.get("status", "")
                details = data.get("details", "")[:50]

                relevance = item.get("relevance_score", 0)
                recency = item.get("recency_score", 0)
                severity = item.get("severity_score", 0)

                lines.append(f"- `{bundle_id}`: {status} - {details}")
                lines.append(f"  > 综合评分：{score:.2f} (相关性:{relevance:.2f}, 时效性:{recency:.2f}, 严重性:{severity:.2f})")
        else:
            bundle_status = context.get("bundle_status", {})
            if bundle_status:
                lines.append("\n### Bundle 状态:")
                for bundle_id, data in bundle_status.items():
                    lines.append(f"- `{bundle_id}`: {data.get('status', '')} - {data.get('details', '')}")

        return "\n".join(lines)

    async def consume_communication_hub_messages(
        self,
        recipient_filter: Optional[str] = None,  # v2.0: 按接收者过滤
        sender_filter: Optional[str] = None,
    ) -> List[Any]:
        """
        消费 CommunicationHub 中的消息 - v2.0 支持按接收者过滤

        MasterAgent 不断消费消息，处理后整理到 Warm Memory（每日记忆）

        Args:
            recipient_filter: 按接收者过滤 (默认为 "master_agent"，只消费发给自己的消息)
            sender_filter: 按发送者过滤

        Returns:
            已消费的消息列表
        """
        from .communication_hub import MessageType

        # v2.0: 默认只消费发给 master_agent 的消息（支持广播消息）
        unconsumed = self.comm_hub.get_unconsumed_messages(
            recipient_filter=recipient_filter or "master_agent",
            sender_filter=sender_filter,
        )
        if not unconsumed:
            return []

        consumed_messages = []
        for msg in unconsumed:
            # 根据消息类型处理
            if msg.msg_type == MessageType.HUMAN_IN_LOOP_RESPONSE:
                # 用户在回路响应 - 需要转发给对应的 InferenceLoop
                logger.info(f"[MasterAgent] Processing human-in-loop response: {msg.msg_id}")
                # TODO: 转发给对应的 InferenceLoop
            elif msg.msg_type == MessageType.USER_FEEDBACK:
                # 用户反馈 - 可能需要转发给 Autonomous Engine
                logger.info(f"[MasterAgent] Processing user feedback: {msg.msg_id}")
                # TODO: 转发给 Autonomous Engine
            elif msg.msg_type == MessageType.AUTONOMOUS_REQUEST:
                # Autonomous 请求 - 处理请求
                logger.info(f"[MasterAgent] Processing autonomous request: {msg.msg_id}")
                # TODO: 处理请求
            elif msg.msg_type == MessageType.AUTONOMOUS_STATUS:
                # Autonomous 状态更新 - 记录或转发
                logger.info(f"[MasterAgent] Processing autonomous status: {msg.msg_id}")
                # TODO: 处理状态更新

            # 标记为已消费
            self.comm_hub.mark_consumed(msg.msg_id)
            consumed_messages.append(msg)

        # 整理到 Warm Memory（每日记忆）
        if consumed_messages:
            await self._organize_to_warm_memory(consumed_messages)

        return consumed_messages

    async def _organize_to_warm_memory(self, messages: List[Any]):
        """
        将消费的消息整理到 Warm Memory（每日记忆）

        Autonomous Engine 会后续将这些内容写入 QMD（永久记忆）
        """
        try:
            from ..memory.warm_memory import WarmMemory
            warm_memory = WarmMemory(self.workspace_path)

            # 将消息内容整理为日志格式
            for msg in messages:
                summary = f"[{msg.sender}] {msg.content[:200]}"
                warm_memory.append_log(
                    loop_id=msg.msg_id,
                    user_input=f"{msg.msg_type.value} from {msg.sender}",
                    summary=summary,
                    facts=[msg.content[:100]] if msg.content else [],
                )
            logger.info(f"[MasterAgent] Organized {len(messages)} messages to Warm Memory")
        except Exception as e:
            logger.warning(f"[MasterAgent] Failed to organize to warm memory: {e}")

    def submit_feedback_to_autonomous(
        self,
        bundle_id: str,
        feedback: str,
        conversation_id: Optional[str] = None,
    ) -> str:
        """
        提交用户反馈给 Autonomous Engine

        反馈会写入 CommunicationHub，由 Autonomous Engine 读取
        """
        msg_id = self.comm_hub.send_user_feedback(
            content=feedback,
            user_id="master_agent",
            conversation_id=conversation_id,
        )
        logger.info(f"[MasterAgent] Feedback submitted to Autonomous Engine: {msg_id}")
        return msg_id

    def request_new_bundle(
        self,
        objective: str,
        interval_seconds: int = 1800,
        success_metrics: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
    ) -> str:
        """
        请求 Autonomous Engine 创建新的 Bundle

        MasterAgent 可以根据用户需求或分析结果，通知 Autonomous Engine 创建新的优化 Bundle
        """
        content = f"请求创建新的 Bundle\\n目标：{objective}\\n执行间隔：{interval_seconds}秒"
        if success_metrics:
            content += f"\\n成功指标：{json.dumps(success_metrics, ensure_ascii=False)}"

        msg_id = self.comm_hub.send(
            msg_type="autonomous_request",  # type: ignore
            sender="master_agent",
            content=content,
            priority="normal",  # type: ignore
            metadata={
                "request_type": "create_bundle",
                "objective": objective,
                "interval_seconds": interval_seconds,
                "success_metrics": success_metrics or {},
            },
            conversation_id=conversation_id,
        )
        logger.info(f"[MasterAgent] New bundle request written to CommHub: {msg_id}")
        return msg_id

    def get_communication_stats(self) -> Dict[str, Any]:
        """获取 CommunicationHub 统计信息"""
        return self.comm_hub.get_stats()


# Import os for the file paths
import os
