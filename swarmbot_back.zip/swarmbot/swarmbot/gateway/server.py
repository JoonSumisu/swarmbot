"""
GatewayServer (v2.0) - 简化版

职责:
- HTTP Server + Message Bus + Session Management
- 消息接收/发送
- 生命周期管理

编排逻辑已移至 GatewayMasterAgent
"""

import asyncio
import sys
import logging
import json
import threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List
import time

# --- Path Setup ---
CURRENT_DIR = Path(__file__).resolve().parent.parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

# Ensure nanobot compatibility
try:
    import nanobot
except ImportError:
    import swarmbot.nanobot
    sys.modules["nanobot"] = swarmbot.nanobot

from loguru import logger

# --- Imports ---
from swarmbot.config_manager import load_config, SwarmbotConfig, WORKSPACE_PATH
from nanobot.bus.queue import MessageBus, InboundMessage, OutboundMessage
from nanobot.channels.feishu import FeishuChannel
from nanobot.config.schema import FeishuConfig

from swarmbot.autonomous import AutonomousEngine
from swarmbot.gateway.orchestrator import GatewayMasterAgent, PrioritizedMessage, Priority
from swarmbot.memory.session_memory import SessionMemory

# Note: v2.0 - Loop routing removed, MasterAgent handles routing internally
# InferenceLoop Standard/Supervised and SwarmsWorker are tools called by MasterAgent


class GatewayServer:
    """Gateway Server v2.0 - 简化版"""

    def __init__(self):
        self.config: SwarmbotConfig = load_config()
        self.bus = MessageBus()
        self.channels = []

        # Loops
        self.autonomous_engine = None

        self._stop_event = threading.Event()
        self._executor = ThreadPoolExecutor(max_workers=10)
        self._inflight = asyncio.Semaphore(10)
        self._latest_inbound = {"channel": "", "chat_id": "", "message_id": ""}
        self._autonomous_report_pos = 0
        self._autonomous_report_path = Path(WORKSPACE_PATH) / "autonomous_gateway_reports.jsonl"

        # Interactive Session Storage
        self.active_loops = {}  # Dict[str, Any] keyed by chat_id
        self.session_memory = SessionMemory(WORKSPACE_PATH)

        # Gateway-MasterAgent
        self.orchestrator = GatewayMasterAgent(Path(WORKSPACE_PATH), self.config)
        self.orchestrator.set_send_callback(self._send_prioritized_message)

    async def start(self):
        logger.info("Starting Swarmbot Gateway (v2.0)...")

        # 1. Initialize Channels
        await self._init_channels()

        if not self.channels:
            logger.warning("No channel initialized. Gateway will run but cannot send/receive external messages.")

        # 2. Start Background Loops
        if bool(getattr(getattr(self.config, "autonomous", None), "enabled", True)):
            self.autonomous_engine = AutonomousEngine(self._stop_event)
            self.autonomous_engine.start()

        # 3. Start Message Processing Loop
        asyncio.create_task(self.bus.dispatch_outbound())
        asyncio.create_task(self._autonomous_report_poller())
        await self._run_message_loop()

    async def _init_channels(self):
        """Initialize channels from config."""
        # Feishu
        feishu_conf = self.config.channels.get("feishu")
        if feishu_conf:
            if isinstance(feishu_conf, dict):
                enabled = feishu_conf.get("enabled", False)
                conf_data = feishu_conf.get("config", {}) if "config" in feishu_conf else feishu_conf
            else:
                enabled = feishu_conf.enabled
                conf_data = dict(feishu_conf.config or {})
                if getattr(feishu_conf, "app_id", "") and "app_id" not in conf_data:
                    conf_data["app_id"] = feishu_conf.app_id
                if getattr(feishu_conf, "app_secret", "") and "app_secret" not in conf_data:
                    conf_data["app_secret"] = feishu_conf.app_secret

            if enabled:
                logger.info("Initializing Feishu channel...")
                try:
                    app_id = conf_data.get("app_id") or conf_data.get("appId")
                    app_secret = conf_data.get("app_secret") or conf_data.get("appSecret")
                    encrypt_key = conf_data.get("encrypt_key") or conf_data.get("encryptKey") or ""
                    verification_token = conf_data.get("verification_token") or conf_data.get("verificationToken") or ""

                    if not app_id or not app_secret:
                        logger.error("Feishu app_id or app_secret missing in config")
                        return

                    pydantic_conf = FeishuConfig(
                        enabled=True,
                        app_id=app_id,
                        app_secret=app_secret,
                        encrypt_key=encrypt_key,
                        verification_token=verification_token,
                        allow_from=conf_data.get("allow_from", [])
                    )
                    channel = FeishuChannel(pydantic_conf, self.bus)
                    self.channels.append(channel)
                except Exception as e:
                    logger.error(f"Failed to init Feishu channel: {e}")

        # Start channels
        for ch in self.channels:
            asyncio.create_task(ch.start())

    async def _run_message_loop(self):
        """Main message processing loop."""
        logger.info("Gateway is ready. Listening for messages...")

        try:
            while not self._stop_event.is_set():
                message: InboundMessage = await self.bus.consume_inbound()

                if not message:
                    continue

                logger.info(f"Received message from {message.channel}: {message.content[:50]}...")

                # Launch async handler
                asyncio.create_task(self._handle_message_async(message))

        except asyncio.CancelledError:
            logger.info("Message loop cancelled.")
        finally:
            self.stop()

    async def _handle_message_async(self, message: InboundMessage):
        """Async message handler - delegates to MasterAgent."""
        loop = asyncio.get_running_loop()
        chat_id = message.chat_id or "unknown"

        async with self._inflight:
            self._latest_inbound = {
                "channel": message.channel or "",
                "chat_id": chat_id,
                "message_id": message.message_id or "",
            }
            raw = (message.content or "").strip()

            # Command Handling
            if raw == "/clear":
                self.session_memory.clear_session(chat_id)
                if chat_id in self.active_loops:
                    del self.active_loops[chat_id]
                self.orchestrator.unregister_loop(chat_id)
                await self._publish_reply(message, "已清除当前会话状态和记忆。")
                return

            if raw == "/compact":
                self.session_memory.compact_session(chat_id, keep_turns=3)
                await self._publish_reply(message, "已压缩会话历史，保留最近 3 轮对话。")
                return

            if raw == "/status":
                session_data = self.session_memory.get_context(chat_id, max_turns=1)
                turn_count = session_data.get("turn_count", 0)
                last_access = session_data.get("last_access", 0)
                status_msg = f"会话状态:\n- 对话轮数：{turn_count}\n- 最后活动：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(last_access)) if last_access else '无'}"
                await self._publish_reply(message, status_msg)
                return

            try:
                # Delegate to MasterAgent for processing
                # MasterAgent decides: simple direct OR inference tool
                response_text = await loop.run_in_executor(
                    self._executor,
                    self.orchestrator.handle_user_message_sync_wrapper,
                    message
                )

                # Handle suspended loops (Human-in-the-Loop)
                if self.orchestrator.has_active_loop(chat_id):
                    loop_instance = self._active_loops.get(chat_id)
                    if loop_instance and getattr(loop_instance, 'is_suspended', False):
                        self.active_loops[chat_id] = loop_instance
                        await self._publish_reply(message, response_text)
                        return

                # Task completed
                if chat_id in self.active_loops:
                    del self.active_loops[chat_id]
                self.orchestrator.unregister_loop(chat_id)

                if not isinstance(response_text, str) or not response_text.strip():
                    response_text = "（无内容返回）"

                # Save to SessionMemory
                self.session_memory.add_turn(
                    chat_id=chat_id,
                    user_input=raw,
                    assistant_response=response_text,
                    metadata={"master_response": response_text}
                )

                # Flush buffered autonomous messages
                await self.orchestrator.flush_buffer_if_complete(chat_id)

                # Split long responses
                chunks = self._split_message(response_text)
                for chunk in chunks:
                    await self._publish_reply(message, chunk)

            except Exception as e:
                logger.error(f"Message handling failed: {e}")
                if chat_id in self.active_loops:
                    del self.active_loops[chat_id]
                self.orchestrator.unregister_loop(chat_id)
                await self._publish_reply(message, "系统处理消息时出现异常，会话已重置。")

    def handle_user_message_sync_wrapper(self, message: InboundMessage) -> str:
        """Synchronous wrapper for MasterAgent.handle_user_message."""
        # Delegate to GatewayMasterAgent's sync method
        return self.orchestrator.handle_user_message_sync(message)

    async def _send_prioritized_message(self, msg: PrioritizedMessage):
        """Callback for orchestrator to send prioritized messages."""
        channel = self._latest_inbound.get("channel", "")
        chat_id = self._latest_inbound.get("chat_id", "")

        if not channel or not chat_id:
            logger.warning("No channel/chat_id available for sending message")
            return

        outbound = OutboundMessage(
            channel=channel,
            chat_id=chat_id,
            content=msg.content,
            reply_to=None,
        )
        await self.bus.publish_outbound(outbound)

    async def _autonomous_report_poller(self):
        """Poll autonomous gateway reports and forward to channel."""
        while not self._stop_event.is_set():
            try:
                if self._autonomous_report_path.exists():
                    with open(self._autonomous_report_path, "r", encoding="utf-8") as f:
                        f.seek(self._autonomous_report_pos)
                        lines = f.readlines()
                        self._autonomous_report_pos = f.tell()
                    for ln in lines:
                        ln = (ln or "").strip()
                        if not ln:
                            continue
                        try:
                            row = json.loads(ln)
                        except Exception:
                            continue

                        report_type = row.get("type", "generic")
                        if report_type == "human_in_loop_request":
                            content = self._format_human_in_loop_report(row)
                        else:
                            content = str(row.get("content") or "").strip()

                        if not content:
                            continue
                        channel = str(self._latest_inbound.get("channel") or "")
                        chat_id = str(self._latest_inbound.get("chat_id") or "")
                        if not channel or not chat_id:
                            continue
                        outbound = OutboundMessage(
                            channel=channel,
                            chat_id=chat_id,
                            content=content,
                            reply_to=None,
                        )
                        await self.bus.publish_outbound(outbound)
            except Exception as e:
                logger.error(f"Autonomous report poller failed: {e}")
            await asyncio.sleep(3)

    def _format_human_in_loop_report(self, row: Dict[str, Any]) -> str:
        """Format human_in_loop_request report for user."""
        bundle_id = row.get("bundle_id", "unknown")
        objective = row.get("objective", "")
        context = row.get("context", {})
        questions = row.get("questions", [])

        eval_data = context.get("eval", {})
        result_data = context.get("result", {})

        grade = eval_data.get("grade", "N/A")
        score = eval_data.get("score", 0)
        issues = eval_data.get("issues", [])

        lines = [
            "🔧 **Bundle 需要您的反馈**",
            "",
            f"**Bundle ID**: `{bundle_id}`",
            f"**目标**: {objective}",
            "",
            f"**评估结果**:",
            f"- 等级：{grade}",
            f"- 分数：{score:.2f}",
        ]

        if issues:
            lines.append(f"- 问题：{', '.join(issues)}")

        lines.extend([
            "",
            f"**执行结果**:",
            f"- 状态：{result_data.get('status', 'unknown')}",
            f"- 详情：{result_data.get('details', 'N/A')}",
            "",
            f"**请提供反馈**:",
        ])

        for i, q in enumerate(questions, 1):
            lines.append(f"{i}. {q}")

        lines.append("")
        lines.append("请直接回复此消息提供您的反馈。")

        return "\n".join(lines)

    async def _publish_reply(self, message: InboundMessage, text: str):
        """Publish reply to channel."""
        try:
            reply = OutboundMessage(
                channel=message.channel,
                content=text,
                chat_id=message.chat_id,
                reply_to=message.message_id
            )
            await self.bus.publish_outbound(reply)
        except Exception as e:
            logger.error(f"Publish outbound failed: {e}")

    def _split_message(self, text: str, part_len: int = 1200) -> list[str]:
        """Split long message into chunks."""
        raw = (text or "").strip()
        if not raw:
            return []
        chunks = []
        i = 0
        while i < len(raw):
            chunks.append(raw[i:i + part_len])
            i += part_len
        return chunks

    def stop(self):
        logger.info("Stopping Gateway...")
        self._stop_event.set()
        if self.autonomous_engine:
            self.autonomous_engine.stop()
        for ch in self.channels:
            asyncio.create_task(ch.stop())
        self._executor.shutdown(wait=False)


def run_gateway():
    """Entry point for running the gateway."""
    logging.basicConfig(level=logging.INFO)
    logger.remove()
    logger.add(sys.stderr, level="INFO")

    try:
        server = GatewayServer()
        asyncio.run(server.start())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.exception(f"Gateway crashed: {e}")


if __name__ == "__main__":
    run_gateway()
