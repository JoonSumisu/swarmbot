"""
CommunicationHub - 双向沟通窗口 (v2.0)

类似待处理列表的 FIFO 队列，基于文件持久化。

数据流：
1. Autonomous Engine / InferenceLoop 写入请求/状态
2. MasterAgent 不断消费消息
3. 对话内容整理到 Warm Memory（每日记忆）
4. Autonomous Engine 将重要内容写入 QMD（永久记忆）

支持的消息类型：
- autonomous_request: Autonomous Engine 发起的请求
- autonomous_status: Autonomous Engine 执行状态
- human_in_loop_request: InferenceLoop 需要用户确认
- human_in_loop_response: 用户对人在回路请求的响应
- user_feedback: 用户主动反馈
- system_info: 系统信息
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Literal
from enum import Enum


class MessageType(str, Enum):
    """消息类型"""
    AUTONOMOUS_REQUEST = "autonomous_request"
    AUTONOMOUS_STATUS = "autonomous_status"
    HUMAN_IN_LOOP_REQUEST = "human_in_loop_request"
    HUMAN_IN_LOOP_RESPONSE = "human_in_loop_response"
    USER_FEEDBACK = "user_feedback"
    SYSTEM_INFO = "system_info"


class MessagePriority(str, Enum):
    """消息优先级"""
    CRITICAL = "critical"    # 紧急告警/人在回路
    HIGH = "high"            # 需要及时处理
    NORMAL = "normal"        # 普通消息
    LOW = "low"              # 后台信息


@dataclass
class ChatMessage:
    """聊天消息 - v2.0 结构化改造"""
    msg_id: str
    msg_type: MessageType
    priority: MessagePriority
    sender: str  # "autonomous_engine", "inference_loop", "master_agent", "user"
    recipient: str  # "master_agent", "inference_loop", "autonomous_engine", "user", "broadcast"
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    consumed: bool = False  # 是否已被消费
    conversation_id: Optional[str] = None  # 所属会话 ID
    thread_id: Optional[str] = None  # 对话线程 ID，用于追踪相关消息
    in_reply_to: Optional[str] = None  # 回复的消息 ID，支持引用回复

    def to_jsonl(self) -> str:
        """转换为 JSONL 格式"""
        return json.dumps({
            "msg_id": self.msg_id,
            "msg_type": self.msg_type.value,
            "priority": self.priority.value,
            "sender": self.sender,
            "recipient": self.recipient,
            "content": self.content,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "consumed": self.consumed,
            "conversation_id": self.conversation_id,
            "thread_id": self.thread_id,
            "in_reply_to": self.in_reply_to,
        }, ensure_ascii=False)

    @classmethod
    def from_jsonl(cls, line: str) -> "ChatMessage":
        """从 JSONL 格式解析"""
        data = json.loads(line)
        return cls(
            msg_id=data["msg_id"],
            msg_type=MessageType(data["msg_type"]),
            priority=MessagePriority(data["priority"]),
            sender=data["sender"],
            recipient=data.get("recipient", "broadcast"),  # 默认广播
            content=data["content"],
            timestamp=data.get("timestamp", time.time()),
            metadata=data.get("metadata", {}),
            consumed=data.get("consumed", False),
            conversation_id=data.get("conversation_id"),
            thread_id=data.get("thread_id"),
            in_reply_to=data.get("in_reply_to"),
        )


class CommunicationHub:
    """
    双向沟通窗口 - 基于文件的 FIFO 消息队列

    文件结构：
    ~/.swarmbot/workspace/communication_hub.jsonl

    每条消息格式：
    {"msg_id": "...", "msg_type": "...", "sender": "...", "content": "...", ...}
    """

    def __init__(self, workspace_path: Path):
        self.file_path = workspace_path / "communication_hub.jsonl"
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_file_exists()

    def _ensure_file_exists(self):
        """确保文件存在"""
        if not self.file_path.exists():
            self.file_path.touch()

    def _read_messages(self) -> List[ChatMessage]:
        """读取所有消息"""
        messages = []
        if not self.file_path.exists():
            return messages

        with open(self.file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        messages.append(ChatMessage.from_jsonl(line))
                    except (json.JSONDecodeError, KeyError) as e:
                        # 跳过损坏的消息
                        pass
        return messages

    def _write_messages(self, messages: List[ChatMessage]):
        """写入所有消息"""
        with open(self.file_path, "w", encoding="utf-8") as f:
            for msg in messages:
                f.write(msg.to_jsonl() + "\n")

    def _append_message(self, msg: ChatMessage):
        """追加单条消息（原子操作）"""
        with open(self.file_path, "a", encoding="utf-8") as f:
            f.write(msg.to_jsonl() + "\n")

    def send(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        recipient: str = "broadcast",  # 新增：接收者
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,  # 新增：线程 ID
        in_reply_to: Optional[str] = None,  # 新增：回复的消息 ID
    ) -> str:
        """
        发送消息到沟通窗口 - v2.0 结构化版本

        Args:
            msg_type: 消息类型
            sender: 发送者
            content: 消息内容
            recipient: 接收者 (master_agent/inference_loop/autonomous_engine/user/broadcast)
            priority: 优先级
            metadata: 附加元数据
            conversation_id: 所属会话 ID
            thread_id: 对话线程 ID
            in_reply_to: 回复的消息 ID

        Returns:
            msg_id: 消息 ID
        """
        msg_id = f"{int(time.time() * 1000)}-{sender[:8]}-{hash(content) % 10000:04d}"
        msg = ChatMessage(
            msg_id=msg_id,
            msg_type=msg_type,
            priority=priority,
            sender=sender,
            recipient=recipient,
            content=content,
            metadata=metadata or {},
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )
        self._append_message(msg)
        return msg_id

    def get_unconsumed_messages(
        self,
        recipient_filter: Optional[str] = None,  # 新增：按接收者过滤
        sender_filter: Optional[str] = None,
        type_filter: Optional[MessageType] = None,
        priority_filter: Optional[MessagePriority] = None,
    ) -> List[ChatMessage]:
        """
        获取未被消费的消息 - v2.0 支持按接收者过滤

        Args:
            recipient_filter: 按接收者过滤 (master_agent/inference_loop/autonomous_engine/user/broadcast)
            sender_filter: 按发送者过滤
            type_filter: 按消息类型过滤
            priority_filter: 按优先级过滤

        Returns:
            消息列表，按优先级和时间排序
        """
        messages = self._read_messages()
        unconsumed = [m for m in messages if not m.consumed]

        # 按接收者过滤（支持广播消息）
        if recipient_filter:
            unconsumed = [m for m in unconsumed if m.recipient in (recipient_filter, "broadcast")]
        if sender_filter:
            unconsumed = [m for m in unconsumed if m.sender == sender_filter]
        if type_filter:
            unconsumed = [m for m in unconsumed if m.msg_type == type_filter]
        if priority_filter:
            unconsumed = [m for m in unconsumed if m.priority == priority_filter]

        # 按优先级排序（critical > high > normal > low），同优先级按时间排序
        priority_order = {
            MessagePriority.CRITICAL: 0,
            MessagePriority.HIGH: 1,
            MessagePriority.NORMAL: 2,
            MessagePriority.LOW: 3,
        }
        unconsumed.sort(key=lambda m: (priority_order.get(m.priority, 4), m.timestamp))

        return unconsumed

    def mark_consumed(self, msg_id: str) -> bool:
        """
        标记消息为已消费

        Args:
            msg_id: 消息 ID

        Returns:
            是否成功标记
        """
        messages = self._read_messages()
        found = False
        for msg in messages:
            if msg.msg_id == msg_id:
                msg.consumed = True
                found = True
                break

        if found:
            self._write_messages(messages)
        return found

    def mark_all_consumed(self, msg_ids: List[str]) -> int:
        """
        批量标记消息为已消费

        Args:
            msg_ids: 消息 ID 列表

        Returns:
            成功标记的数量
        """
        messages = self._read_messages()
        count = 0
        for msg in messages:
            if msg.msg_id in msg_ids:
                msg.consumed = True
                count += 1
        self._write_messages(messages)
        return count

    def get_conversation_history(
        self,
        conversation_id: str,
        limit: int = 50,
    ) -> List[ChatMessage]:
        """
        获取指定会话的历史记录

        Args:
            conversation_id: 会话 ID
            limit: 返回消息数量限制

        Returns:
            历史消息列表
        """
        messages = self._read_messages()
        conversation_msgs = [
            m for m in messages
            if m.conversation_id == conversation_id
        ]
        conversation_msgs.sort(key=lambda m: m.timestamp)
        return conversation_msgs[-limit:]

    def cleanup_old_messages(
        self,
        max_age_seconds: int = 86400,  # 默认 24 小时
    ) -> int:
        """
        清理过期消息

        Args:
            max_age_seconds: 消息最大存活时间（秒）

        Returns:
            清理的消息数量
        """
        messages = self._read_messages()
        cutoff = time.time() - max_age_seconds

        # 保留未消费的消息或近期消息
        kept_messages = []
        removed_count = 0

        for msg in messages:
            if not msg.consumed or msg.timestamp > cutoff:
                kept_messages.append(msg)
            else:
                removed_count += 1

        if removed_count > 0:
            self._write_messages(kept_messages)

        return removed_count

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        messages = self._read_messages()
        unconsumed = [m for m in messages if not m.consumed]

        stats = {
            "total_messages": len(messages),
            "unconsumed_count": len(unconsumed),
            "consumed_count": len(messages) - len(unconsumed),
            "by_type": {},
            "by_sender": {},
            "by_priority": {},
        }

        for msg in unconsumed:
            # By type
            type_key = msg.msg_type.value
            stats["by_type"][type_key] = stats["by_type"].get(type_key, 0) + 1

            # By sender
            stats["by_sender"][msg.sender] = stats["by_sender"].get(msg.sender, 0) + 1

            # By priority
            priority_key = msg.priority.value
            stats["by_priority"][priority_key] = stats["by_priority"].get(priority_key, 0) + 1

        return stats

    # ========== 便捷方法 ==========

    def send_to_master_agent(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        in_reply_to: Optional[str] = None,
    ) -> str:
        """发送消息给 MasterAgent"""
        return self.send(
            msg_type=msg_type,
            sender=sender,
            content=content,
            recipient="master_agent",
            priority=priority,
            metadata=metadata,
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )

    def send_to_inference_loop(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        in_reply_to: Optional[str] = None,
    ) -> str:
        """发送消息给 InferenceLoop"""
        return self.send(
            msg_type=msg_type,
            sender=sender,
            content=content,
            recipient="inference_loop",
            priority=priority,
            metadata=metadata,
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )

    def send_to_autonomous_engine(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        in_reply_to: Optional[str] = None,
    ) -> str:
        """发送消息给 Autonomous Engine"""
        return self.send(
            msg_type=msg_type,
            sender=sender,
            content=content,
            recipient="autonomous_engine",
            priority=priority,
            metadata=metadata,
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )

    def send_to_user(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        in_reply_to: Optional[str] = None,
    ) -> str:
        """发送消息给用户"""
        return self.send(
            msg_type=msg_type,
            sender=sender,
            content=content,
            recipient="user",
            priority=priority,
            metadata=metadata,
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )

    def broadcast(
        self,
        msg_type: MessageType,
        sender: str,
        content: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        in_reply_to: Optional[str] = None,
    ) -> str:
        """广播消息给所有接收者"""
        return self.send(
            msg_type=msg_type,
            sender=sender,
            content=content,
            recipient="broadcast",
            priority=priority,
            metadata=metadata,
            conversation_id=conversation_id,
            thread_id=thread_id,
            in_reply_to=in_reply_to,
        )

    def send_autonomous_request(
        self,
        content: str,
        bundle_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> str:
        """发送 Autonomous Engine 请求"""
        return self.send(
            msg_type=MessageType.AUTONOMOUS_REQUEST,
            sender="autonomous_engine",
            content=content,
            priority=MessagePriority.NORMAL,
            metadata={"bundle_id": bundle_id} if bundle_id else {},
            conversation_id=conversation_id,
        )

    def send_autonomous_status(
        self,
        content: str,
        bundle_id: Optional[str] = None,
        status: str = "completed",
        conversation_id: Optional[str] = None,
        recipient: str = "master_agent",  # 新增：默认发送给 MasterAgent
    ) -> str:
        """发送 Autonomous Engine 状态更新"""
        return self.send(
            msg_type=MessageType.AUTONOMOUS_STATUS,
            sender="autonomous_engine",
            content=content,
            recipient=recipient,  # 支持指定接收者
            priority=MessagePriority.LOW,
            metadata={"bundle_id": bundle_id, "status": status},
            conversation_id=conversation_id,
        )

    def send_human_in_loop_request(
        self,
        content: str,
        loop_id: str,
        stage: str,
        checkpoint_data: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[str] = None,
        recipient: str = "master_agent",  # 新增：默认发送给 MasterAgent
    ) -> str:
        """发送人在回路请求（需要用户确认）"""
        return self.send(
            msg_type=MessageType.HUMAN_IN_LOOP_REQUEST,
            sender="inference_loop",
            content=content,
            recipient=recipient,  # 支持指定接收者
            priority=MessagePriority.CRITICAL,
            metadata={
                "loop_id": loop_id,
                "stage": stage,
                "checkpoint_data": checkpoint_data or {},
            },
            conversation_id=conversation_id,
        )

    def send_human_in_loop_response(
        self,
        content: str,
        request_msg_id: str,
        user_id: str = "user",
        conversation_id: Optional[str] = None,
        recipient: str = "inference_loop",  # 新增：默认发送给 InferenceLoop
        in_reply_to: Optional[str] = None,  # 新增：支持回复原请求
    ) -> str:
        """发送人在回路响应（用户反馈）"""
        return self.send(
            msg_type=MessageType.HUMAN_IN_LOOP_RESPONSE,
            sender=user_id,
            content=content,
            recipient=recipient,  # 支持指定接收者
            priority=MessagePriority.HIGH,
            metadata={"request_msg_id": request_msg_id},
            conversation_id=conversation_id,
            in_reply_to=in_reply_to or request_msg_id,  # 默认回复原请求
        )

    def send_user_feedback(
        self,
        content: str,
        user_id: str = "user",
        conversation_id: Optional[str] = None,
        recipient: str = "master_agent",  # 新增：默认发送给 MasterAgent
    ) -> str:
        """发送用户反馈"""
        return self.send(
            msg_type=MessageType.USER_FEEDBACK,
            sender=user_id,
            content=content,
            recipient=recipient,  # 支持指定接收者
            priority=MessagePriority.NORMAL,
            metadata={},
            conversation_id=conversation_id,
        )

    def send_system_info(
        self,
        content: str,
        conversation_id: Optional[str] = None,
        recipient: str = "broadcast",  # 新增：默认广播
    ) -> str:
        """发送系统信息"""
        return self.send(
            msg_type=MessageType.SYSTEM_INFO,
            sender="master_agent",
            content=content,
            recipient=recipient,  # 支持指定接收者
            priority=MessagePriority.LOW,
            metadata={},
            conversation_id=conversation_id,
        )
