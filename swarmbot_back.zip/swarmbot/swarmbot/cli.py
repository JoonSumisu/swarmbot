from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import os
import re
import readline  # Enable arrow keys and better input handling
from typing import Any, Dict, List

from .config_manager import (
    SwarmbotConfig,
    load_config,
    save_config,
    ensure_dirs,
    CONFIG_PATH,
    BOOT_CONFIG_PATH,
    WORKSPACE_PATH,
)
import shutil
from pathlib import Path


def load_nanobot_config() -> dict:
    cfg = load_config()
    channels_dict = {}
    for name, c_cfg in cfg.channels.items():
        channels_dict[name] = c_cfg.config.copy()
        channels_dict[name]["enabled"] = c_cfg.enabled
    return {"channels": channels_dict}

def save_nanobot_config(config: dict) -> None:
    cfg = load_config()
    
    if "channels" in config:
        for name, c_data in config["channels"].items():
            # Update or create
            enabled = c_data.get("enabled", False)
            conf = {k:v for k,v in c_data.items() if k != "enabled"}
            
            # Update existing or create new
            if name in cfg.channels:
                cfg.channels[name].enabled = enabled
                cfg.channels[name].config.update(conf)
            else:
                from .config_manager import ChannelConfig
                cfg.channels[name] = ChannelConfig(enabled=enabled, config=conf)
    
    save_config(cfg)


def cmd_channels(args: argparse.Namespace, extra_args: list[str]) -> None:
    if not extra_args:
        cmd_channels_list()
        return

    action = extra_args[0]

    if action == "list":
        cmd_channels_list()
    elif action in ("add", "enable"):
        if len(extra_args) < 2:
            print("Usage: swarmbot channels add <name> [key=value ...]")
            return
        name = extra_args[1]
        params = extra_args[2:]
        cmd_channels_enable(name, params)
    elif action in ("remove", "disable"):
        if len(extra_args) < 2:
            print("Usage: swarmbot channels remove <name>")
            return
        name = extra_args[1]
        cmd_channels_disable(name)
    elif action == "config":
        if len(extra_args) < 2:
            print("Usage: swarmbot channels config <name> [key=value ...]")
            return
        name = extra_args[1]
        params_list = extra_args[2:]
        params = {}
        for arg in params_list:
            if "=" in arg:
                k, v = arg.split("=", 1)
                params[k] = v
        cmd_channels_config(name, params)
    else:
        print(f"Unsupported channels action: {action}")

def cmd_channels_list() -> None:
    cfg = load_nanobot_config()
    channels = cfg.get("channels", {})
    print("Available Channels:")
    print(f"{'Name':<15} {'Status':<10} {'Config'}")
    print("-" * 50)
    for name, data in channels.items():
        status = "Enabled" if data.get("enabled") else "Disabled"
        print(f"{name:<15} {status:<10}")

def cmd_channels_enable(name: str, args: list[str]) -> None:
    cfg = load_nanobot_config()
    if "channels" not in cfg:
        cfg["channels"] = {}
    
    # Process args first
    params = {}
    for arg in args:
        if "=" in arg:
            k, v = arg.split("=", 1)
            params[k] = v

    if "appId" in params and "app_id" not in params:
        params["app_id"] = params.pop("appId")
    if "appSecret" in params and "app_secret" not in params:
        params["app_secret"] = params.pop("appSecret")
    if "encryptKey" in params and "encrypt_key" not in params:
        params["encrypt_key"] = params.pop("encryptKey")
    if "verificationToken" in params and "verification_token" not in params:
        params["verification_token"] = params.pop("verificationToken")

    # Interactive setup for Feishu
    if name == "feishu":
        # Required keys for Feishu (snake_case internally)
        required_keys = ["app_id", "app_secret"]
        current_config = cfg.get("channels", {}).get(name, {})
        
        # Check if user provided keys via args (camelCase or snake_case)
        # We already normalized params to snake_case above
        
        missing = [k for k in required_keys if k not in params and k not in current_config]
        
        # If explicitly requested via add, or missing keys, trigger interactive
        if missing or not params:
            print(f"Configuring Feishu channel...")
            for k in required_keys:
                if k not in params and k not in current_config:
                    val = input(f"Enter {k}: ").strip()
                    if val:
                        params[k] = val
            
            # Optional keys
            if "encrypt_key" not in params and "encrypt_key" not in current_config:
                val = input("Enter encrypt_key (optional, press Enter to skip): ").strip()
                if val:
                    params["encrypt_key"] = val
            if "verification_token" not in params and "verification_token" not in current_config:
                val = input("Enter verification_token (optional, press Enter to skip): ").strip()
                if val:
                    params["verification_token"] = val

    if name not in cfg["channels"]:
        print(f"Channel '{name}' not found in default config. Creating new entry...")
        cfg["channels"][name] = {"enabled": True}
    
    cfg["channels"][name]["enabled"] = True
    cfg["channels"][name].update(params)
    
    # Clean up any camelCase keys if they exist in the config to avoid duplication/confusion
    # The runtime expects snake_case
    camel_map = {
        "appId": "app_id",
        "appSecret": "app_secret",
        "encryptKey": "encrypt_key",
        "verificationToken": "verification_token"
    }
    for camel, snake in camel_map.items():
        if camel in cfg["channels"][name]:
            # If snake_case missing, move value over
            if snake not in cfg["channels"][name]:
                cfg["channels"][name][snake] = cfg["channels"][name][camel]
            # Remove camelCase
            del cfg["channels"][name][camel]
            
    save_nanobot_config(cfg)
    print(f"Channel '{name}' enabled and configured.")
    # Show Swarmbot config path now
    print(f"Configuration saved to: {CONFIG_PATH}")
    # Also mirrored to ~/.nanobot/config.json for compatibility
    print(json.dumps({name: cfg["channels"][name]}, ensure_ascii=False, indent=2))

def cmd_channels_disable(name: str) -> None:
    cfg = load_nanobot_config()
    if "channels" in cfg and name in cfg["channels"]:
        cfg["channels"][name]["enabled"] = False
        save_nanobot_config(cfg)
        print(f"Channel '{name}' disabled.")
    else:
        print(f"Channel '{name}' is not enabled or does not exist.")

def cmd_channels_config(name: str, params: dict) -> None:
    cfg = load_nanobot_config()
    if "channels" not in cfg or name not in cfg["channels"]:
        print(f"Channel '{name}' not found. Please enable it first using 'add' or 'enable'.")
        return
        
    for k, v in params.items():
        cfg["channels"][name][k] = v
        
    save_nanobot_config(cfg)
    print(f"Channel '{name}' configuration updated.")


def cmd_onboard() -> None:
    ensure_dirs()
    cfg = load_config()
    save_config(cfg)
    
    # Init Boot Config: Copy default boot files to ~/.swarmbot/boot/ if not exist
    pkg_boot_dir = os.path.join(os.path.dirname(__file__), "boot")
    if os.path.exists(pkg_boot_dir):
        print(f"Initializing boot configuration in {BOOT_CONFIG_PATH}...")
        for filename in os.listdir(pkg_boot_dir):
            if filename.endswith(".md"):
                src = os.path.join(pkg_boot_dir, filename)
                dst = os.path.join(BOOT_CONFIG_PATH, filename)
                if not os.path.exists(dst):
                    shutil.copy2(src, dst)
                    print(f"  Created {filename}")
                else:
                    print(f"  Skipped {filename} (already exists)")
    workspace_soul = os.path.join(WORKSPACE_PATH, "SOUL.md")
    boot_soul = os.path.join(BOOT_CONFIG_PATH, "SOUL.md")
    if os.path.exists(workspace_soul):
        should_copy = (not os.path.exists(boot_soul)) or (os.path.getsize(workspace_soul) > os.path.getsize(boot_soul))
        if should_copy:
            shutil.copy2(workspace_soul, boot_soul)
            print("  Synced SOUL.md from workspace to boot")
    
    print(f"Swarmbot 已完成初始化，配置文件位于: {CONFIG_PATH}")
    print(f"个性化 Boot 配置位于: {BOOT_CONFIG_PATH}")


def cmd_run() -> None:
    """
    CLI run mode - thin client that passes messages to Gateway.

    v2.0 architecture:
    - cli.py is a thin client
    - GatewayServer receives messages
    - GatewayMasterAgent handles all routing and tool selection
    - InferenceLoop tools (Standard/Supervised/SwarmsWorker) are called by MasterAgent
    """
    from .memory.session_memory import SessionMemory
    from .gateway.orchestrator import GatewayMasterAgent

    # Session memory for CLI
    session_memory = SessionMemory(WORKSPACE_PATH)
    session_id = "cli-session"  # Fixed session ID for CLI

    print("Swarmbot run 模式已启动 (v2.0)，Ctrl+C 退出。")
    print("MasterAgent 将根据 inference_tools.md 配置文件自动选择推理工具。")
    print("可用命令：/clear (清除会话), /compact (压缩历史), /status (会话状态), /quit (退出)")

    # Create a minimal GatewayMasterAgent for local testing
    cfg = load_config()
    orchestrator = GatewayMasterAgent(Path(WORKSPACE_PATH), cfg)

    turn = 0

    while True:
        try:
            user_input = input("\n你：").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not user_input:
            continue

        # Command Handling
        if user_input in ["/quit", "/exit"]:
            print("退出 Swarmbot run 模式。")
            break

        if user_input == "/clear":
            session_memory.clear_session(session_id)
            print("已清除当前会话状态和记忆。")
            turn = 0
            continue

        if user_input == "/compact":
            session_memory.compact_session(session_id, keep_turns=3)
            print("已压缩会话历史，保留最近 3 轮对话。")
            continue

        if user_input == "/status":
            session_data = session_memory.get_context(session_id, max_turns=1)
            turn_count = session_data.get("turn_count", 0)
            last_access = session_data.get("last_access", 0)
            from time import strftime, localtime
            print(f"会话状态:")
            print(f"  - 对话轮数：{turn_count}")
            print(f"  - 最后活动：{strftime('%Y-%m-%d %H:%M:%S', localtime(last_access)) if last_access else '无'}")
            continue

        # Create a message wrapper for MasterAgent
        class MessageWrapper:
            def __init__(self, chat_id: str, content: str):
                self.chat_id = chat_id
                self.content = content

        message = MessageWrapper(chat_id=session_id, content=user_input)

        # Delegate to MasterAgent - it handles all routing and tool selection
        print("\n[MasterAgent] 处理中...")
        reply = orchestrator.handle_user_message_sync(message)

        print(f"\nSwarmbot:\n{reply}")

        # Save to session memory
        session_memory.add_turn(
            chat_id=session_id,
            user_input=user_input,
            assistant_response=reply,
            metadata={"master_response": reply}
        )

        turn += 1

import socket
import os

def check_port(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) != 0

def get_available_port(start_port: int, step: int = 20, max_tries: int = 5) -> int:
    current_port = start_port
    for _ in range(max_tries):
        if check_port(current_port):
            return current_port
        print(f"Port {current_port} is busy, trying {current_port + step}...")
        current_port += step
    raise RuntimeError(f"Could not find available port starting from {start_port}")

def cmd_gateway() -> None:
    """
    Run the Gateway in native mode.
    This replaces the legacy nanobot CLI wrapper with a direct Python implementation.
    """
    try:
        from swarmbot.gateway.server import run_gateway
        run_gateway()
    except Exception as e:
        print(f"Gateway crashed: {e}")
        import traceback
        traceback.print_exc()

def cmd_heartbeat(args: argparse.Namespace) -> None:
    from .config_manager import WORKSPACE_PATH
    from pathlib import Path

    hb_path = Path(WORKSPACE_PATH) / "HEARTBEAT.md"

    if args.action == "status":
        if not hb_path.exists():
            print("HEARTBEAT.md 不存在。")
            return
        content = hb_path.read_text(encoding="utf-8")
        stripped = "".join(line for line in content.splitlines() if not line.strip().startswith(">")).strip()
        if not stripped:
            print("HEARTBEAT.md 存在但当前没有待办任务。")
        else:
            print("HEARTBEAT.md 存在且包含待办任务。")
    elif args.action == "trigger":
        if not hb_path.exists():
            print("HEARTBEAT.md 不存在，无法触发。")
            return
        print("当前 Heartbeat 任务清单如下（需手动执行）：")
        print(hb_path.read_text(encoding="utf-8"))

def cmd_tool() -> None:
    print("工具管理 CLI 已简化，请在对话中通过 LLM 工具调用使用工具。")


def cmd_cron(args: argparse.Namespace) -> None:
    print("Cron 管理功能当前已禁用（nanobot 依赖已移除）。")

def cmd_status() -> None:
    cfg = load_config()
    print("Swarmbot 状态:")
    print()
    print("Providers:")
    print(json.dumps([p.__dict__ for p in cfg.providers], ensure_ascii=False, indent=2))
    print()
    print("Swarm:")
    print(json.dumps({"swarm": cfg.swarm.__dict__}, ensure_ascii=False, indent=2))



def cmd_provider_add(args: argparse.Namespace) -> None:
    cfg = load_config()
    from .config_manager import ProviderConfig
    new_provider = ProviderConfig(
        name="primary",
        base_url=args.base_url,
        api_key=args.api_key,
        model=args.model,
        max_tokens=args.max_tokens,
    )
    # Overwrite all providers to avoid conflict as per user instruction
    cfg.providers = [new_provider]
    save_config(cfg)
    print("已更新模型提供方配置（作为唯一 primary provider 生效）。")


def cmd_provider_delete() -> None:
    cfg = load_config()
    cfg.providers = []  # Clear all providers
    save_config(cfg)
    print("已重置模型提供方配置（清空所有 provider）。")


def cmd_config(args: argparse.Namespace) -> None:
    cfg = load_config()
    updated = False
    if args.max_agents is not None:
        cfg.swarm.max_agents = args.max_agents
        updated = True
    if args.architecture is not None:
        cfg.swarm.architecture = args.architecture
        updated = True
    if args.max_turns is not None:
        cfg.swarm.max_turns = args.max_turns
        updated = True
    if args.auto_builder is not None:
        cfg.swarm.auto_builder = args.auto_builder
        updated = True
    if updated:
        save_config(cfg)
        print("已更新 Swarm 配置。")
    print()
    print("当前 Swarm 配置:")
    print(json.dumps(cfg.swarm.__dict__, ensure_ascii=False, indent=2))


def cmd_update() -> None:
    """
    Update Swarmbot core code.
    """
    print("自动更新功能目前已禁用。")
    print("请手动进入 Swarmbot 源码目录进行更新：")
    print("")
    print("  cd /path/to/swarmbot")
    print("  git pull")
    print("  ./scripts/install_deps.sh")
    print("")
    print("如果您是通过 pip 安装的，请使用 pip install --upgrade swarmbot")


def cmd_daemon(args: argparse.Namespace) -> None:
    from .config_manager import CONFIG_HOME, load_config, save_config, WORKSPACE_PATH
    from pathlib import Path
    pid_file = os.path.join(CONFIG_HOME, "daemon.pid")
    state_file = os.path.join(CONFIG_HOME, "daemon_state.json")
    if args.action == "start":
        # 1. 初始化基础配置
        try:
            cmd_onboard()
        except Exception:
            pass

        # 2. 配置 daemon 管理选项
        try:
            cfg = load_config()
            cfg.daemon.manage_gateway = True
            cfg.daemon.manage_autonomous = True
            save_config(cfg)
        except Exception:
            pass

        # 3. 初始化核心 Bundles
        try:
            bundles_dir = Path(CONFIG_HOME) / "bundles"
            core_bundles = ["core.memory_foundation", "core.boot_optimizer",
                           "core.system_hygiene", "core.bundle_governor"]

            # 检查是否缺少核心 bundles
            missing_bundles = []
            if not bundles_dir.exists():
                missing_bundles = core_bundles
            else:
                for bundle_id in core_bundles:
                    bundle_path = bundles_dir / bundle_id
                    if not bundle_path.exists() or not (bundle_path / "bundle.json").exists():
                        missing_bundles.append(bundle_id)

            # 运行初始化脚本补全缺失的 bundles
            if missing_bundles:
                print(f"初始化核心 Bundles: {', '.join(missing_bundles)}")
                init_script = Path(__file__).parent.parent / "scripts" / "init_bundles.py"
                if init_script.exists():
                    subprocess.run(
                        [sys.executable, str(init_script)],
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
        except Exception as e:
            print(f"Bundle 初始化失败：{e}")

        # 4. 创建 context_memory.md 和 skills 目录
        try:
            workspace = Path(WORKSPACE_PATH)
            workspace.mkdir(parents=True, exist_ok=True)

            # 创建 context_memory.md
            context_file = workspace / "context_memory.md"
            if not context_file.exists():
                context_file.write_text(
                    "# Context Memory - 上下文共享池\n\n"
                    "## Active Bundle Status\n\n"
                    "| bundle_id | timestamp | status | details |\n"
                    "|-----------|-----------|--------|---------|\n",
                    encoding="utf-8"
                )

            # 创建 skills 目录
            skills_dir = workspace.parent / "skills"
            skills_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"工作空间初始化失败：{e}")
        if os.path.exists(pid_file):
            try:
                with open(pid_file, "r", encoding="utf-8") as f:
                    pid = int(f.read().strip() or "0")
                if pid > 0:
                    import signal
                    os.kill(pid, signal.SIGTERM)
                    print(f"检测到已有 daemon 进程，正在关闭，PID={pid}")
                    for _ in range(20):
                        try:
                            os.kill(pid, 0)
                            time.sleep(0.2)
                        except ProcessLookupError:
                            break
            except Exception:
                try:
                    os.remove(pid_file)
                except Exception:
                    pass
        cmd = [sys.executable, "-m", "swarmbot.daemon"]
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        time.sleep(0.8)
        if proc.poll() is not None:
            print("Swarmbot daemon 启动失败，请检查 ~/.swarmbot/logs/daemon_gateway.log")
            return
        daemon_pid = None
        for _ in range(20):
            try:
                if os.path.exists(pid_file):
                    with open(pid_file, "r", encoding="utf-8") as f:
                        pid_txt = (f.read() or "").strip()
                    pid_val = int(pid_txt or "0")
                    if pid_val > 0:
                        daemon_pid = pid_val
                        break
            except Exception:
                pass
            time.sleep(0.2)
        gateway_ready = False
        for _ in range(30):
            try:
                if os.path.exists(state_file):
                    with open(state_file, "r", encoding="utf-8") as f:
                        state = json.load(f)
                    gw_pid = (
                        ((state.get("services") or {}).get("gateway") or {}).get("pid")
                    )
                    if gw_pid:
                        gateway_ready = True
                        break
            except Exception:
                pass
            time.sleep(0.5)
        if not gateway_ready:
            try:
                subprocess.Popen(
                    [sys.executable, "-m", "swarmbot.cli", "gateway"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            except Exception:
                pass
            if daemon_pid:
                print(f"Swarmbot daemon 已启动(PID={daemon_pid})，但未检测到 gateway 进程，已触发兜底拉起。")
            else:
                print("Swarmbot daemon 已启动，但未检测到 gateway 进程，已触发兜底拉起。")
            return
        if daemon_pid:
            print(f"Swarmbot daemon 已启动，PID={daemon_pid}")
        else:
            print("Swarmbot daemon 已启动")
    elif args.action == "shutdown":
        if not os.path.exists(pid_file):
            print("Swarmbot daemon 未在运行。")
            return
        try:
            with open(pid_file, "r", encoding="utf-8") as f:
                pid = int(f.read().strip() or "0")
        except Exception:
            pid = 0
        if pid <= 0:
            try:
                os.remove(pid_file)
            except Exception:
                pass
            print("Swarmbot daemon PID 文件无效，已清理。")
            return
        try:
            import signal

            os.kill(pid, signal.SIGTERM)
            print(f"已发送 shutdown 信号到 Swarmbot daemon (PID={pid})")
        except ProcessLookupError:
            print("Swarmbot daemon 进程不存在，清理 PID 文件。")
        except Exception as e:
            print(f"无法发送 shutdown 信号: {e}")
        try:
            os.remove(pid_file)
        except Exception:
            pass


def main() -> None:
    # Use parse_known_args so we can grab extra args for passthrough commands
    parser = argparse.ArgumentParser(description="Swarmbot CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("onboard", help="初始化配置和工作区")

    subparsers.add_parser("run", help="与 Swarmbot 进行连续对话（本地调试）")

    # Gateway passthrough
    subparsers.add_parser("gateway", help="启动 Swarmbot Gateway")
    
    heartbeat_parser = subparsers.add_parser("heartbeat", help="管理 Swarmbot 的 heartbeat")
    heartbeat_sub = heartbeat_parser.add_subparsers(dest="action", required=True)
    heartbeat_sub.add_parser("status", help="查看 heartbeat 状态")
    heartbeat_sub.add_parser("trigger", help="立即执行一次 heartbeat 检查")

    subparsers.add_parser("tool", help="查看和使用 Swarmbot 暴露的工具（简化模式）")
    subparsers.add_parser("channels", help="管理 Swarmbot 的消息通道配置")
    
    cron_parser = subparsers.add_parser("cron", help="管理 Swarmbot 的定时任务")
    cron_sub = cron_parser.add_subparsers(dest="action", required=True)
    cron_sub.add_parser("list", help="列出所有定时任务")
    cron_add = cron_sub.add_parser("add", help="添加一个新的定时任务")
    cron_add.add_argument("--name", required=True, help="任务名称")
    cron_add.add_argument("--message", required=True, help="发送给 Agent 的消息")
    cron_add.add_argument("--every-minutes", type=int, required=True, help="执行间隔（分钟）")
    cron_add.add_argument("--deliver", action="store_true", help="是否将结果发送到指定渠道")
    cron_add.add_argument("--channel", type=str, help="渠道名称，如 feishu")
    cron_add.add_argument("--to", type=str, help="接收者标识")
    cron_remove = cron_sub.add_parser("remove", help="删除定时任务")
    cron_remove.add_argument("--id", required=True, help="任务 ID")
    cron_enable = cron_sub.add_parser("enable", help="启用定时任务")
    cron_enable.add_argument("--id", required=True, help="任务 ID")
    cron_disable = cron_sub.add_parser("disable", help="禁用定时任务")
    cron_disable.add_argument("--id", required=True, help="任务 ID")
    
    subparsers.add_parser("agent", help="保留占位符（原 nanobot agent 透传已禁用）")

    subparsers.add_parser("status", help="查看当前 Swarmbot 状态")

    provider_parser = subparsers.add_parser("provider", help="管理模型提供方")
    provider_sub = provider_parser.add_subparsers(dest="action", required=True)
    provider_add = provider_sub.add_parser("add", help="新增/覆盖一个模型提供方（仅保留一个）")
    provider_add.add_argument("--base-url", required=True, help="OpenAI 兼容接口 base url")
    provider_add.add_argument("--api-key", required=True, help="API key")
    provider_add.add_argument("--model", required=True, help="模型名称")
    provider_add.add_argument(
        "--max-tokens",
        type=int,
        default=4096,
        help="最大生成 token 数",
    )
    provider_sub.add_parser("delete", help="删除当前 provider 配置，恢复默认")

    config_parser = subparsers.add_parser("config", help="配置和查看 Swarm 工作模式")
    config_parser.add_argument("--max-agents", type=int, help="Swarm 中的 agent 最大数量")
    config_parser.add_argument(
        "--architecture",
        type=str,
        choices=[
            "auto",
            "sequential",
            "concurrent",
            "agent_rearrange",
            "graph",
            "mixture",
            "group_chat",
            "forest",
            "hierarchical",
            "heavy",
            "swarm_router",
            "long_horizon",
            "state_machine",
        ],
        help="架构类型，对应 swarms Multi-Agent Architectures（默认 auto = AutoSwarmBuilder）",
    )
    config_parser.add_argument("--max-turns", type=int, help="对话最大轮数（0 为不限制）")
    config_parser.add_argument(
        "--auto-builder",
        type=lambda x: x.lower() in ("1", "true", "yes", "on"),
        help="是否启用 AutoSwarmBuilder",
    )

    subparsers.add_parser("skill", help="查看当前可用的技能（内部通过 ToolAdapter 实现）")

    daemon_parser = subparsers.add_parser("daemon", help="管理 Swarmbot 守护进程")
    daemon_sub = daemon_parser.add_subparsers(dest="action", required=True)
    daemon_sub.add_parser("start", help="启动守护进程")
    daemon_sub.add_parser("shutdown", help="关闭守护进程")

    # Note: Overthinking functionality has been replaced by AutonomousEngine
    # Subparser removed - use daemon commands instead

    subparsers.add_parser("update", help="更新 Swarmbot 核心代码（保留配置）")

    args, _ = parser.parse_known_args()

    if args.command == "onboard":
        cmd_onboard()
    elif args.command == "update":
        cmd_update()
    elif args.command == "run":
        cmd_run()
    elif args.command == "gateway":
        cmd_gateway()
    elif args.command == "heartbeat":
        cmd_heartbeat(args)
    elif args.command == "tool":
        cmd_tool()
    elif args.command == "channels":
        cmd_channels(args, sys.argv[2:])
    elif args.command == "cron":
        cmd_cron(args)
    elif args.command == "agent":
        print("直接与底层 nanobot agent 对话的功能已禁用。")
    elif args.command == "status":
        cmd_status()
    elif args.command == "provider":
        if args.action == "add":
            cmd_provider_add(args)
        elif args.action == "delete":
            cmd_provider_delete()
    elif args.command == "config":
        cmd_config(args)
    elif args.command == "skill":
        print("技能管理请通过对话中的 skill_summary / skill_load 工具完成。")
    elif args.command == "daemon":
        cmd_daemon(args)

if __name__ == "__main__":
    main()
