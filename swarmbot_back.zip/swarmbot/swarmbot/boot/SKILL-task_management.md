---
name: 任务管理与清理
description: 管理 Claude Code 任务列表的最佳实践 - 创建、更新、清理任务
category: workflow
required_tools: TaskCreate, TaskUpdate, TaskList
---

# 任务管理与清理技能

## 问题背景

在使用 Claude Code 的 Task 工具时，容易出现以下问题：

1. **任务状态不同步** - 代码已实现但任务状态仍为 pending
2. **任务列表累积** - 过期任务未及时清理，干扰后续工作
3. **任务创建过于细碎** - 创建了大量不需要追踪的小任务

## 任务生命周期管理

### 1. 何时创建任务

**应该创建任务的情况**：
- 多步骤的复杂功能开发（3 步以上）
- 需要跨对话持续追踪的工作
- 用户明确要求分步骤完成的任务
- 发现需要先修复的阻塞性问题

**不需要创建任务的情况**：
- 单次编辑可完成的修改
- 简单的修复（如语法错误、拼写错误）
- 已经立即完成的工作
- 临时性的探索工作

### 2. 任务更新时机

```
开始工作前：TaskUpdate(status="in_progress", taskId=#X)
完成任务后：TaskUpdate(status="completed", taskId=#X)
发现阻塞：保持 in_progress，创建新的阻塞任务
```

**重要**：任务完成后必须立即标记为 completed，不要等到下次对话！

### 3. 任务清理流程

每次开始新任务前，先执行：

```python
# 检查任务列表
tasks = TaskList()

# 对于已实现但标记为 pending 的任务
for task in tasks:
    if task.status == "pending" and is_implemented(task):
        TaskUpdate(status="completed", taskId=task.id)
    elif task.is_obsolete():
        TaskUpdate(status="deleted", taskId=task.id)
```

## 最佳实践

### 任务命名规范

```
好：实现 SessionMemory 会话保持功能
坏：修复问题、实施优化

好：修复 gateway/server.py 中的语法错误
坏：修 bug
```

### 任务描述规范

任务描述应包含：
- 具体要做什么
- 验收标准是什么
- 相关文件路径

示例：
```
描述：实现 SessionMemory 类支持按 chat_id 索引的会话记忆
验收：
- 创建 swarmbot/memory/session_memory.py
- 实现 add_turn(), get_context(), clear_session() 方法
- 持久化到 ~/.swarmbot/workspace/sessions/{chat_id}.md
```

### 任务数量控制

- 同时进行的任务不超过 5 个
- 单个任务的工作量不超过 30 分钟
- 复杂任务拆分为子任务

## 常见问题

### Q: 任务列表全是 pending 怎么办？

A: 执行以下检查：
1. 逐个检查任务是否已实现
2. 已实现的标记为 completed
3. 不再需要的标记为 deleted
4. 模糊不清的任务更新描述

### Q: 什么时候删除任务？

A: 以下情况删除任务：
- 任务已完成后清理
- 需求变更不再需要
- 任务描述过于模糊无法执行
- 任务被其他任务替代

### Q: 如何避免任务积压？

A: 养成以下习惯：
1. 完成任务后立即更新状态
2. 每次对话开始前清理任务列表
3. 不创建不必要的任务
4. 合并相关的子任务

## 操作示例

### 完成任务并清理

```
# 完成所有已实现的功能
TaskUpdate(status="completed", taskId="#1")  # 代码审查
TaskUpdate(status="completed", taskId="#2")  # ContextPool 评分
TaskUpdate(status="completed", taskId="#3")  # SkillRecommender
TaskUpdate(status="completed", taskId="#4")  # ConfigHotReloader
TaskUpdate(status="completed", taskId="#5")  # BundleGovernor
TaskUpdate(status="completed", taskId="#6")  # system_hygiene

# 创建新的修复任务
TaskCreate(subject="修复会话保持问题", description="...")
```

### 批量清理过期任务

```
# 查看任务列表
TaskList()

# 删除/完成所有过期任务
TaskUpdate(status="completed", taskId="#X")  # 已实现的
TaskUpdate(status="deleted", taskId="#Y")    # 不再需要的
```

## 相关工具

- `TaskCreate` - 创建新任务
- `TaskUpdate` - 更新任务状态
- `TaskList` - 查看所有任务
- `TaskGet` - 获取任务详情
- `TaskStop` - 停止后台任务

---

**创建日期**: 2026-03-18
**适用场景**: 所有需要多步骤完成的任务
