# 推理工具配置 (Inference Tools Configuration)

MasterAgent 通过 LLM 理解每个工具的推理步骤和适用场景，智能选择工具。

---

## 工具定义格式

每个工具定义包含：
- **推理步骤**: 该工具执行的推理流程描述
- **适用场景**: 在什么情况下使用这个工具
- **调用方式**: 如何实例化和调用

---

## 可用工具列表

### standard - 标准推理流程

**工具 ID**: `standard`

**类名**: `InferenceLoopStandard`

**模块路径**: `swarmbot.loops.inference_standard`

**推理步骤**:
1. ANALYSIS - 分析问题类型、领域、意图
2. COLLECTION - 收集上下文信息（记忆检索、工具查询）
3. PLANNING - 制定执行计划
4. INFERENCE - 执行推理（自组织任务认领）
5. EVALUATION - 逻辑一致性验证
6. TRANSLATION - 转化为用户友好的回答
7. ORGANIZATION - 记忆归档

**适用场景**:
当用户问题需要系统性的推理分析时使用。适合中等复杂度的知识问答、概念解释、信息查询类任务。不需要人工干预，可以自动完成全流程。

**示例问题**:
- "解释一下什么是量子纠缠"
- "Python 的装饰器怎么用"
- "光合作用的原理是什么"

---

### supervised - 带人工确认的增强流程

**工具 ID**: `supervised`

**类名**: `InferenceLoopSupervised`

**模块路径**: `swarmbot.loops.inference_supervised`

**推理步骤**:
1. ANALYSIS - 分析问题
2. ANALYSIS_REVIEW - [暂停] 等待用户确认分析方向
3. COLLECTION - 收集信息
4. PLANNING - 制定计划
5. PLAN_REVIEW - [暂停] 等待用户确认方案
6. EXECUTION - 执行计划
7. EVALUATION - 评估结果
8. TRANSLATION - 输出答案
9. ORGANIZATION - 记忆归档

**适用场景**:
当任务涉及高风险、高复杂度或需要用户确认关键决策点时使用。适合工程问题、代码修复、系统架构设计等容易出错的任务。在分析和计划两个关键节点会暂停等待用户确认，确保方向正确。

**示例问题**:
- "我的 Python 程序报错 TypeError，帮我修复"
- "设计一个高并发的订单系统架构"
- "数据库迁移后性能下降，排查原因"

---

### swarms - 多 Worker 协作投票

**工具 ID**: `swarms`

**类名**: `SwarmsWorker`

**模块路径**: `swarmbot.loops.swarms_worker`

**推理步骤**:
1. 动态生成 3-9 个 Worker
2. 为每个 Worker 分配独特角色（analyst、planner、critic 等）
3. 多轮沟通讨论（最多 10 轮）
4. 投票达成共识
5. 综合结论输出

**适用场景**:
当问题需要多视角分析、方案比较或复杂决策时使用。适合开放性问题、方案评估、决策建议等需要权衡利弊的场景。通过多个 Worker 的视角互补，得出更全面的结论。

**示例问题**:
- "分析一下选择 A 方案和 B 方案各自的优缺点"
- "应该考研还是直接工作"
- "评估这个创业项目的可行性"

---

## 添加新工具

按照以下格式添加新的工具定义：

<!--
### 工具名称

**工具 ID**: `tool_id`

**类名**: `InferenceLoopXxx`

**模块路径**: `swarmbot.loops.inference_xxx`

**推理步骤**:
1. 步骤 1 - 描述
2. 步骤 2 - 描述

**适用场景**:
描述在什么情况下使用这个工具。
-->

**无需修改任何代码**，MasterAgent 会读取配置并动态加载新工具。
