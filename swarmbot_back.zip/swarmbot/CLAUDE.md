# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Quick Start

### Installation & Setup

Swarmbot uses a bootstrap script for installation. Run once after cloning:

```bash
python3 scripts/bootstrap.py [--mode pipx|user|venv] [--editable] [--with-eval-deps]
```

- `--mode pipx`: Install globally as `swarmbot` command (recommended)
- `--mode venv`: Create `.venv/` and install there
- `--mode user`: Install to user site-packages
- `--editable`: Install in editable mode for development

After installation:
```bash
swarmbot onboard          # Initialize config and workspace
swarmbot provider add --base-url "http://localhost:8000/v1" --api-key "key" --model "qwen3-coder-next"
swarmbot daemon start     # Start gateway + background loops
```

### Common Commands

| Command | Purpose |
|---------|---------|
| `swarmbot run` | Interactive CLI mode for local testing (v2.0 thin client) |
| `swarmbot gateway` | Start Gateway HTTP server (port 18790) |
| `swarmbot daemon start` | Start daemon with auto-restart |
| `swarmbot status` | Show current configuration |
| `swarmbot channels add feishu ...` | Configure Feishu/Lark channel |
| `swarmbot provider add ...` | Configure LLM provider |

### Running Tests & Evaluations

```bash
# Interactive local tests
python tests/test_interactive_local.py

# Unit tests (CI)
python -m unittest discover -s tests -p "test_*.py"

# Inference benchmark (quick mode)
python scripts/eval_inference_benchmark.py --quick
```

Output artifacts go to `artifacts/` directory.

---

## Architecture Overview (v2.0)

### Core Components

| Component | File | Purpose |
|-----------|------|---------|
| **GatewayServer** | `swarmbot/gateway/server.py` | HTTP server + message bus + channels |
| **GatewayMasterAgent** | `swarmbot/gateway/orchestrator.py` | Unified message orchestrator (v2.0 core) |
| **InferenceLoop Tools** | `swarmbot/loops/*.py` | Pluggable inference tools (config-driven) |
| **AutonomousEngine** | `swarmbot/autonomous/engine.py` | Background self-organizing engine with Bundles |
| **ConfigManager** | `swarmbot/config_manager.py` | Global config at `~/.swarmbot/config.json` |
| **Memory System** | `swarmbot/memory/` | L1-L4 memory hierarchy (Whiteboard/Hot/Warm/Cold) |
| **CommunicationHub** | `swarmbot/gateway/communication_hub.py` | Bidirectional communication window |

### v2.0 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        GatewayServer                            │
│  (HTTP Server + Message Bus + Session Management)               │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                     GatewayMasterAgent                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Core Responsibilities                                   │   │
│  │  • Load boot files, context, memory snapshots            │   │
│  │  • Built-in simple chat (LLM direct response)            │   │
│  │  • Decide: simple_direct OR inference tool               │   │
│  │  • Dynamic tool loading via importlib                    │   │
│  │  • Read/Write CommunicationHub (bidirectional comm)      │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
          │
          ▼
    ┌─────────────────────────────────────────┐
    │  Inference Tools (config-driven)        │
    │  • standard: 8-step reasoning flow      │
    │  • supervised: Human-in-the-Loop        │
    │  • swarms: Multi-worker collaboration   │
    └─────────────────────────────────────────┘
```

### v2.0 Key Changes

1. **Pluggable Inference Tools**: Tools are loaded dynamically from configuration
2. **No Hardcoding**: Tool selection based on MD config, not if/else logic
3. **simple_direct**: Built-in capability, not a tool
4. **Thin CLI**: `cli.py` delegates to MasterAgent, no direct tool calls

---

## Configuration Files

| File | Purpose |
|------|---------|
| `~/.swarmbot/config.json` | Main config (providers, swarm, autonomous) |
| `~/.swarmbot/boot/inference_tools.md` | **v2.0** Inference tool definitions |
| `~/.swarmbot/boot/SOUL.md` | Agent persona definition |
| `~/.swarmbot/boot/swarmboot.md` | System rules and guidelines |
| `~/.swarmbot/workspace/HEARTBEAT.md` | Current todo list |
| `~/.swarmbot/logs/daemon_gateway.log` | Gateway process logs |

### Example config.json
```json
{
  "providers": [
    {
      "name": "primary",
      "base_url": "http://localhost:8000/v1",
      "api_key": "sk-xxx",
      "model": "qwen3-coder-next",
      "max_tokens": 64000,
      "temperature": 0.6
    }
  ],
  "swarm": {
    "max_agents": 4,
    "architecture": "auto",
    "max_turns": 16
  },
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3
  },
  "daemon": {
    "manage_gateway": true,
    "manage_autonomous": true
  }
}
```

---

## v2.0 核心设计原则：配置驱动

**核心思想**: 工具定义和调用完全由配置文件驱动，代码中无硬编码。

### InferenceLoop 工具集架构

**工具配置文件**: `~/.swarmbot/boot/inference_tools.md`

每个工具定义包含：
```markdown
### 工具名称

**工具 ID**: `tool_id`

**类名**: `InferenceLoopXxx`

**模块路径**: `swarmbot.loops.inference_xxx`

**推理步骤**:
1. 步骤描述
2. 步骤描述

**适用场景**:
描述在什么情况下使用这个工具。
```

**MasterAgent 动态加载流程**:
1. 读取 `inference_tools.md` 配置文件
2. 解析工具定义（工具 ID、类名、模块路径）
3. 使用 LLM 理解工具描述，选择适合的工具
4. 使用 `importlib` 动态导入模块和类
5. 实例化并调用 `run(user_input, session_id)` 方法

### 添加新工具

1. 在 `swarmbot/loops/` 创建工具类（如 `inference_xxx.py`）
2. 实现统一接口 `run(user_input, session_id) -> str`
3. 在 `inference_tools.md` 添加配置
4. **无需修改任何核心代码**

### simple_direct 是内置能力，不是工具

- `simple_direct` 不是推理工具，是 MasterAgent 的内置能力
- 简单对话直接由 MasterAgent 调用 LLM 回复
- 不经过推理工具流程
- 在 `_should_use_simple_direct()` 中检测

---

## CommunicationHub 双向沟通窗口

**设计原则**: 类似待处理列表的 FIFO 队列，基于文件持久化，支持多方双向沟通。

### 数据流

```
CommunicationHub (messages.jsonl)
  │
  ├─ Autonomous Engine 写入请求/状态
  ├─ InferenceLoop 写入人在回路请求
  └─ 用户反馈
       │
       ▼
  MasterAgent 不断消费
       │
       ▼
  整理到 Warm Memory（每日记忆）
       │
       ▼
  Autonomous Engine 写入 QMD（永久记忆）
```

### 消息类型

| 类型 | 发送者 | 说明 |
|------|--------|------|
| `autonomous_request` | autonomous_engine | Autonomous Engine 发起的请求 |
| `autonomous_status` | autonomous_engine | Autonomous Engine 执行状态 |
| `human_in_loop_request` | inference_loop | 需要用户确认（人在回路） |
| `human_in_loop_response` | user/master_agent | 用户对在回路请求的响应 |
| `user_feedback` | user/master_agent | 用户主动反馈 |
| `system_info` | master_agent | 系统信息 |

### 使用示例

```python
from swarmbot.gateway.communication_hub import CommunicationHub

hub = CommunicationHub(workspace_path)

# Autonomous Engine 发送状态
hub.send_autonomous_status(
    content="Bundle xxx 执行完成",
    bundle_id="core.memory_foundation",
    status="success",
)

# InferenceLoop 发送人在回路请求
hub.send_human_in_loop_request(
    content="需要确认分析方向",
    loop_id="session-123",
    stage="ANALYSIS_REVIEW",
    checkpoint_data={...},
)

# MasterAgent 消费消息
messages = hub.get_unconsumed_messages()
for msg in messages:
    # 处理消息
    hub.mark_consumed(msg.msg_id)
```

---

## Critical Implementation Notes

1. **LLM Client**: All LLM calls flow through `OpenAICompatibleClient`. Never use nanobot providers directly.

2. **Local Model Support**: URL handling must respect user-configured base_url - no automatic `/v1` appending.

3. **Gateway Isolation**: Each inbound message gets its own InferenceLoop instance to prevent whiteboard contamination.

4. **Daemon Defaults**: `manage_gateway=True` and `manage_autonomous=True` in config_manager.py.

5. **Configuration-Driven**: Tool definitions from `inference_tools.md`, loaded via `importlib`.

6. **Version Sync**: Ensure `__version__` in `swarmbot/__init__.py` matches pyproject.toml.

7. **CommunicationHub**: Bidirectional communication via file-based FIFO queue, messages flow to Warm Memory then QMD.

---

## Workspace Layout

| Path | Purpose |
|------|---------|
| `/root/swarmbot_dev` | Development/experimentation |
| `/root/.swarmbot/` | Runtime directory (config, workspace, logs) |
| `/root/swarmbot_git` | Git-ready checkout (worktree) |

---

## Testing Checklist

After major changes, verify:

1. `python tests/test_interactive_local.py` passes
2. `swarmbot gateway` starts successfully
3. `swarmbot daemon start` works with auto-restart
4. `swarmbot run` correctly delegates to MasterAgent
5. Tool selection works for different query types
6. All imports pass: `from swarmbot.gateway.orchestrator import GatewayMasterAgent`

---

## Model Configuration Example

```bash
# Local vLLM/Ollama
swarmbot provider add \
  --base-url "http://127.0.0.1:8000/v1" \
  --api-key "sk-xxx" \
  --model "qwen3-coder-next" \
  --max-tokens 64000

# OpenAI-compatible API
swarmbot provider add \
  --base-url "https://api.example.com/v1" \
  --api-key "sk-xxx" \
  --model "gpt-4o"
```

---

## Debugging Tips

- Enable log display mode: Check `~/.swarmbot/logs/daemon_gateway.log`
- Check tool config: `cat ~/.swarmbot/boot/inference_tools.md`
- Test tool loading: `python -c "from swarmbot.gateway.orchestrator import GatewayMasterAgent; ..."`
