# SwarmBot 开发框架完整文档

**版本**: v1.1.0
**最后更新**: 2026-03-14
**作者**: Claude Opus 4.6

---

## 目录

1. [系统架构概览](#一-system-architecture-overview)
2. [核心模块结构与代码映射](#二-core-module-structure-and-code-mapping)
3. [执行流程详解](#三-execution-flow-details)
4. [内存分层系统](#四-memory-hierarchy-system)
5. [工具与技能系统](#五-tool--skill-system)
6. [自治引擎](#六-autonomous-engine)
7. [网关与通道](#七-gateway--channels)
8. [配置管理](#八-configuration-management)
9. [开发指南](#九-development-guide)

---

## 一、System Architecture Overview

### 1.1 核心组件架构图

```
┌─────────────────────────────────────────────────────────────────────┐
│                        SwarmBot v1.1                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐    ┌──────────────┐    ┌─────────────────────┐   │
│  │   Gateway    │────▶│ InferenceLoop│────▶ Memory Hierarchy    │   │
│  │  (Server)    │    │  (8-Step      │    │ (L1-L4)           │   │
│  └──────────────┘    │   Loop)      │    └─────────────────────┘   │
│                      └──────────────┘                              │
│                            │                                       │
│                            ▼                                       │
│                    ┌──────────────┐                                │
│                    │  Autonomous  │                                │
│                    │   Engine     │                                │
│                    │ (Monitor +   │                                │
│                    │  Action Queues)│                               │
│                    └──────────────┘                                │
│                            │                                       │
│                            ▼                                       │
│                    ┌──────────────┐                                │
│                    │   Swarm      │                                │
│                    │   Manager    │                                │
│                    │ (Multi-Agent)│                                │
│                    └──────────────┘                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 1.2 核心组件说明

| 组件 | 文件路径 | 功能描述 |
|------|---------|----------|
| **CLI** | `swarmbot/__init__.py` | 命令行入口，支持 onboard/run/gateway/daemon/provider/channels |
| **Daemon** | `scripts/bootstrap.py` | 进程托管与健康恢复 |
| **GatewayServer** | `swarmbot/gateway/server.py` | 消息总线与外部通道（Feishu）调度 |
| **InferenceLoop** | `swarmbot/loops/inference.py` | 8 步推理主循环 |
| **AutonomousEngine** | `swarmbot/autonomous/engine.py` | 自治编排引擎（双线决策执行） |
| **OverthinkingLoop** | `swarmbot/loops/overthinking.py` | 记忆压缩归档 |
| **OveractionLoop** | `swarmbot/loops/overaction.py` | 主动行动、系统诊断与优化 |
| **SwarmManager** | `swarmbot/swarm/manager.py` | 多 Agent 架构执行器 |

---

## 二、Core Module Structure and Code Mapping

### 2.1 入口模块

#### `swarmbot/__init__.py`
- 主入口文件
- 导出核心类和配置

### 2.2 Gateway 模块

**文件**: `swarmbot/gateway/server.py`

```python
class GatewayServer:
    def __init__(self)
        self.config = load_config()              # 加载配置
        self.bus = MessageBus()                   # 消息总线
        self.channels = []                        # 通道列表
        self.active_loops = {}                    # 交互式会话存储

    async def start(self)
        await self._init_channels()               # 初始化通道（Feishu等）
        self.autonomous_engine.start()           # 启动自治引擎
        await self._run_message_loop()            # 运行消息循环

    async def _handle_message_async(self, message)
        # 处理用户消息
        inference_loop = InferenceLoop(config, WORKSPACE_PATH)
        response_text = await loop.run_in_executor(inference_loop.run, ...)
        # 返回结果给用户
```

**关键功能**:
- 初始化 Feishu 等通道
- 启动 AutonomousEngine（当配置启用）
- 创建/复用 InferenceLoop 处理用户消息
- 支持 `/clear` 命令清除会话状态
- 轮询 autonomous_gateway_reports.jsonl 并转发结果

### 2.3 Inference Loop 模块

**文件**: `swarmbot/loops/inference.py`

```python
class InferenceLoop:
    def __init__(self, config, workspace_path)
        self.whiteboard = Whiteboard()            # L1 白板
        self.hot_memory = HotMemory(workspace)    # L2 热记忆
        self.warm_memory = WarmMemory(workspace)  # L3 温记忆
        self.cold_memory = ColdMemory()           # L4 冷记忆
        self.evidence_store = EvidenceStore()     # 证据存储

    def run(self, user_input, session_id)
        # 执行 8 步推理循环
```

**8步推理流程**:

| Step | 名称 | 功能 | 关键代码 |
|------|------|------|----------|
| 1 | Metadata Initialization | 初始化白板元信息 | `wb_update("metadata")` |
| 2 | Problem Analysis | 并行 analyst 分析问题 | `_step_analysis()` |
| 3 | Information Collection | 信息收集与证据补采 | `_step_collection()` |
| 4 | Action Planning | 生成 framework_doc 和任务分解 | `_step_planning()` |
| 5 | Skill Discovery | 加载/拉取技能说明书 | `skill_summary/skill_load` |
| 6 | Tool Decision | 计算最小工具集合 | `_decide_tool_gate()` |
| 7 | Inference Execution | Worker 并行执行任务 | `_step_inference()` |
| 8 | Evaluation | 按 acceptance_criteria 评估 | `_step_evaluation()` |
| 9 | Translation | Master 汇总输出 | `_step_translation()` |
| 10 | Organization | 写入 Hot/Warm，归档证据 | `_step_organization()` |

### 2.4 自治引擎模块

**文件**: `swarmbot/autonomous/engine.py`

```python
class AutonomousEngine:
    def __init__(self, stop_event)
        self.monitor_queue = deque()              # 监控队列（Bundle事件）
        self.action_queue = {}                    # 行为队列（执行计划）
        self.bundles = self._build_bundles()      # 默认bundles

    def _build_bundles(self)
        return [
            _MemoryFoundationBundle("core.memory_foundation"),
            _BootOptimizerBundle("core.boot_optimizer"),
            _SystemHygieneBundle("core.system_hygiene"),
            _BundleGovernorBundle("core.bundle_governor")
        ]
```

**双线模型**:
- **MonitorQueue**: 接收 bundle 监测事件（定时检查）
- **ActionQueue**: 承载决策计划、执行状态、结果、评估反馈

**默认 Bundle**:
| Bundle ID | 类型 | 功能 |
|-----------|------|------|
| `core.memory_foundation` | _MemoryFoundationBundle | 记忆整理（每30分钟） |
| `core.boot_optimizer` | _BootOptimizerBundle | 优化循环触发（每20分钟） |
| `core.system_hygiene` | _SystemHygieneBundle | 资源阈值诊断（每10分钟） |
| `core.bundle_governor` | _BundleGovernorBundle | registry 索引冲突扫描 |

### 2.5 核心 Agent 模块

**文件**: `swarmbot/core/agent.py`

```python
@dataclass
class AgentContext:
    agent_id: str
    role: str = "assistant"
    skills: Dict[str, Any] = field(default_factory=dict)

class CoreAgent:
    def __init__(self, ctx, llm, memory, hot_memory)
        self.ctx = ctx
        self.llm = llm
        self.memory = memory
        self._tool_adapter = ToolAdapter()

    def step(self, user_input) -> str
        # 构建消息（系统提示词 + 历史 + 当前输入）
        messages = self._build_messages(user_input)
        # 调用 LLM 并执行工具
        return content
```

**Agent 关键功能**:
- Soul 加载逻辑（Master/Overthinker 加载 SOUL.md）
- 技能控制的工具暴露
- 多轮工具调用支持（最多 3 轮）
- 并行工具执行

### 2.6 Swarm 模块

**文件**: `swarmbot/swarm/manager.py`

```python
@dataclass
class SwarmAgentSlot:
    agent: CoreAgent
    weight: float = 1.0

class SwarmSession:
    def __init__(self, session_id, config, llm)
        self.agents = []                          # Agent 列表
        self.skill_registry = SkillRegistry()
        self._init_default_agents()              # 初始化默认角色

    def resize_swarm(self, target_count)        # 调整 swarm 大小
    def reassign_roles(self, new_roles):        # 重新分配角色

class SwarmManager:
    def get_session(self, session_id)
        # 获取或创建会话
```

**默认 Agent 角色**: planner, coder, critic, summarizer, researcher, analyst, writer, reviewer

---

## 三、Execution Flow Details

### 3.1 完整执行流程图

```
┌─────────────────────────────────────────────────────────────────────┐
│                          User Request                              │
└─────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌───────────────────────────────────────┐
                    │         GatewayServer                 │
                    │  - 检查会话状态                        │
                    │  - 创建/复用 InferenceLoop             │
                    └───────────────────────────────────────┘
                                      │
                                      ▼
                    ┌───────────────────────────────────────┐
                    │        InferenceLoop.run()            │
                    └───────────────────────────────────────┘
                            │         │         │
                            ▼         ▼         ▼
                  ┌───────────────────────────────────────┐
                  │      8-Step Inference Loop           │
                  ├───────────────────────────────────────┤
                  │ Step 1: Metadata Initialization     │
                  │ Step 2: Problem Analysis            │
                  │ Step 3: Information Collection      │
                  │ Step 4: Action Planning             │
                  │ Step 5: Skill Discovery             │
                  │ Step 6: Tool Decision               │
                  │ Step 7: Inference Execution         │
                  │ Step 8: Evaluation                  │
                  │ Step 9: Translation                 │
                  │ Step 10: Organization               │
                  └───────────────────────────────────────┘
                            │
                            ▼
                    ┌───────────────────────────────────────┐
                    │       Response to User              │
                    └───────────────────────────────────────┘

同时运行的后台任务:
┌─────────────────────────────────────────────────────────────────────┐
│                  AutonomousEngine (Background)                       │
├─────────────────────────────────────────────────────────────────────┤
│  MonitorQueue (Bundle Events) → ActionQueue (Execute Tasks)         │
│   - memory_foundation      → Memory整理                             │
│   - boot_optimizer        → 系统优化                                │
│   - system_hygiene        → 资源诊断                                │
│   - bundle_governor       → 冲突检测                                │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 Step 4: Action Planning (framework_doc)

**关键数据结构**:

```python
framework_doc = {
    "schema_version": "1.1",
    "objective": "完成用户请求...",
    "scope": {"in_scope": [...], "out_scope": [...]},
    "hard_constraints": [],
    "task_breakdown": [
        {
            "task_id": "t1",
            "title": "...",
            "description": "...",
            "priority": "high",
            "dependencies": [],
            "definition_of_done": ["..."],
            "worker_assignment": {...},
            "recommended_skills": [...],
            "recommended_tools": [...],
        }
    ],
    "acceptance_criteria": [...],
    "checkpoint_plan": [...],
    "rollback_strategy": [...],
    "early_finish_rules": {
        "key_task_completion_rate_threshold": 0.8,
        "final_confidence_threshold": 0.78,
    },
}
```

### 3.3 Supervisor 控制机制

**阶段锁 (stage_lock)**:
```python
def _supervisor_control_action(self, action, stage, reason)
    # 检查幂等键（防止重复）
    idem_key = f"{session_id}:{stage}:{action_id}"

    # 检查阶段锁
    if stage_lock and stage_lock != stage and action in ["interrupt", "rerun", "terminate"]:
        return {"accepted": False}  # 被锁定阻止

    # 更新白板
    wb_control["stage"] = stage
    wb_control["stage_lock"] = stage
```

**提前收敛评分**:
```python
final_confidence = 0.5*confidence_score + 0.2*consistency_score +
                   0.2*evidence_coverage + 0.1*key_task_completion_rate

触发条件:
- key_task_completion_rate >= 0.80
- final_confidence >= 0.78
- hard_constraints 无违反

→ 触发 promote_to_master
```

---

## 四、Memory Hierarchy System

### 4.1 记忆分层架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Memory Hierarchy (L1-L4)                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  L1: Whiteboard          内存中共享状态                  易失性    │
│      (当前会话)           - task_specification                          │
│                           - execution_plan                              │
│                           - current_state                               │
│                           - checkpoint_data                             │
│                                                                     │
│  L2: HotMemory          ~/.swarmbot/workspace/hot_memory.md         │
│      (短期持久,1-7天)     - Past (Recent)                                │
│                           - Present                                       │
│                           - Future                                        │
│                           - Todo List                                     │
│                                                                     │
│  L3: WarmMemory         ~/.swarmbot/workspace/memory/               │
│      (每日日志)           YYYY-MM-DD.md                                  │
│                           - Entry [timestamp]                             │
│                           - Input/Conclusion/Facts                      │
│                                                                     │
│  L4: ColdMemory         ~/.swarmbot/workspace/qmd/                  │
│      (长期知识库,语义检索)   Collection 隔离                              │
│                           - facts                                         │
│                           - experiences                                   │
│                           - theories                                      │
│                                                                     │
│  EvidenceStore          ~/.swarmbot/evidence/                       │
│      (证据增量)           legal/                                         │
│                           economy/                                        │
│                           business/                                       │
│                           policy/                                         │
│                           incremental.jsonl                              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 4.2 记忆模块详细说明

#### L1: Whiteboard (`swarmbot/memory/whiteboard.py`)

```python
class Whiteboard:
    def __init__(self)
        self.clear()  # 初始化结构

    def update(self, section: str, data: Any)   # 更新指定section
    def get(self, section: str) -> Any          # 获取数据
    def get_full_snapshot() -> str             # JSON快照
```

**Section 结构**:
- `metadata`: session_id, loop_id, start_time
- `wb_control`: stage, stage_lock, retry_count, control_actions
- `wb_plan`: framework_doc, task_status, checkpoints
- `wb_evidence`: critical_facts, critical_quotes, external_refs
- `problem_analysis`, `information_gathering`, `action_plan`
- `inference_conclusions`, `evaluation_report`, `final_response`

#### L2: HotMemory (`swarmbot/memory/hot_memory.py`)

```python
class HotMemory:
    def __init__(self, workspace_path)
        self.file_path = Path(workspace) / "hot_memory.md"

    def read() -> str           # 读取内容
    def update(content: str)    # 完全覆盖
    def append_todo(item: str)  # 添加待办项
```

**文件格式**:
```markdown
# Hot Memory

## Past (Recent)
...

## Present
...

## Future
...

## Todo List
- [ ] Task 1
- [ ] Task 2
```

#### L3: WarmMemory (`swarmbot/memory/warm_memory.py`)

```python
class WarmMemory:
    def append_log(loop_id, input_prompt, summary, facts)
        # 追加到 today's file

    def read_today() -> str     # 读取今日日志
```

#### L4: ColdMemory (`swarmbot/memory/cold_memory.py`)

```python
class ColdMemory(QMDMemoryStore):
    def search_text(query, limit=5) -> str
        # 语义检索
```

### 4.3 Evidence Store (`swarmbot/memory/evidence_store.py`)

```python
class EvidenceStore:
    def classify_domain(question: str) -> str
        # 分类到 legal/economy/business/policy/general

    def extract_citations(answer: str) -> List[str]
        # 提取 URL/法律条文/文章编号

    def append_incremental(question, answer, route)
        # 追加证据记录

    def build_summary() -> Dict
        # 生成 library_summary.json
```

---

## 五、Tool & Skill System

### 5.1 工具与技能边界（v1.1 强约束）

**Tool (可执行能力)**:
| 工具名 | 功能 |
|--------|------|
| `web_search` | 网页搜索 |
| `browser_open` | 打开网页 |
| `browser_read` | 读取网页内容 |
| `file_read` | 读取文件 |
| `file_write` | 写入文件 |
| `python_exec` | Python代码执行 |
| `shell_exec` | Shell命令执行 |

**Skill (任务处理说明书)**:
- 不直接执行系统动作
- 指导策略（SKILL.md 文件）
- 通过 `skill_summary` / `skill_load` / `skill_fetch` 访问

### 5.2 ToolRegistry (`swarmbot/tools/registry.py`)

```python
class ToolRegistry:
    def register(name: str, func: Callable, schema: Dict)
        # 注册工具

    def execute(name: str, args: Dict, context=None) -> Any
        # 执行工具（带策略检查）
```

### 5.3 SkillRegistry (`swarmbot/loops/skill_registry.py`)

```python
class SkillRegistry:
    base_skills = ["whiteboard_update", "hot_memory_update"]

    role_skills = {
        "planner": ["web_search", "python_exec"],
        "coder": ["file_write", "shell_exec", "file_read", "python_exec"],
        "researcher": ["web_search", "browser_open", "browser_read", "python_exec"],
        ...
    }

    def get_skills(role: str) -> Dict[str, bool]
        # 返回该角色的可用技能
```

**默认角色技能映射**:
| Role | Skills |
|------|--------|
| planner | web_search, python_exec, whiteboard_update, hot_memory_update |
| coder | file_write, shell_exec, file_read, python_exec |
| analyst | web_search, browser_read, python_exec |
| researcher | web_search, browser_open, browser_read, python_exec |
| writer | web_search, python_exec |
| reviewer | file_read, python_exec |

### 5.4 ToolAdapter (`swarmbot/tools/adapter.py`)

```python
class ToolAdapter:
    def __init__(self)
        self.registry = get_registry()

    def get_tool_definitions() -> List[Dict]
        # 返回 OpenAI 格式工具定义

    def execute(name: str, args: Dict, context=None) -> Any
        # 执行工具（带白板/热记忆绑定）
```

---

## 六、Autonomous Engine

### 6.1 架构设计

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Autonomous Engine                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  MonitorQueue (Bundle Events)                                      │
│    │                                                                 │
│    ├─ core.memory_foundation (30min interval)                      │
│    ├─ core.boot_optimizer (20min interval)                         │
│    ├─ core.system_hygiene (10min, disk/mem threshold)              │
│    └─ core.bundle_governor (5min, duplicate detection)             │
│                                                                 │
│  ActionQueue (Executing Tasks)                                     │
│    │                                                                 │
│    ├─ execute_task (run inference loop)                            │
│    ├─ update_bundle (update bundle state)                          │
│    ├─ loop_optimize (improve efficiency)                           │
│    └─ gateway_report (forward results to user)                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 6.2 Bundle Registry

**默认配置**:
```json
{
  "autonomous": {
    "bundle_registry": {
      "root_dir": "~/.swarmbot/bundles",
      "index_file": "~/.swarmbot/bundles/_registry/bundles_index.jsonl",
      "catalog_file": "~/.swarmbot/bundles/_registry/bundles_catalog.md"
    }
  }
}
```

---

## 七、Gateway & Channels

### 7.1 Gateway 流程

```python
class GatewayServer:
    async def start(self)
        await self._init_channels()           # 初始化通道
        if autonomous.enabled:
            self.autonomous_engine = AutonomousEngine(...)
            self.autonomous_engine.start()

        asyncio.create_task(self.bus.dispatch_outbound())
        asyncio.create_task(self._autonomous_report_poller())
        await self._run_message_loop()        # 主消息循环

    async def _handle_message_async(self, message)
        chat_id = message.chat_id

        if chat_id in self.active_loops:
            inference_loop = self.active_loops[chat_id]
        else:
            inference_loop = InferenceLoop(config, WORKSPACE_PATH)

        response_text = await loop.run_in_executor(
            inference_loop.run,
            message.content,
            chat_id
        )

        # 处理结果...
```

### 7.2 Feishu 通道配置

```python
{
  "channels": {
    "feishu": {
      "enabled": true,
      "app_id": "...",
      "app_secret": "...",
      "encrypt_key": "",           // 可选
      "verification_token": ""     // 可选
    }
  }
}
```

---

## 八、Configuration Management

### 8.1 配置文件结构

**默认路径**: `~/.swarmbot/config.json`

```json
{
  "providers": [
    { "name": "primary", "base_url": "...", "api_key": "...", "model": "..." },
    { "name": "backup", ... }
  ],
  "swarm": {
    "max_agents": 4,
    "roles": [],
    "architecture": "auto",
    "max_turns": 16,
    "display_mode": "simple"
  },
  "tools": {
    "fs": { "allow_read": [], "allow_write": [] },
    "shell": { "allow_commands": [], "deny_commands": [...] },
    "exec": { ... }
  },
  "daemon": {
    "manage_gateway": true,
    "manage_autonomous": true
  },
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3,
    "default_locked_bundles": [...],
    "queues": { ... },
    "swarm_execution": { ... },
    "bundle_registry": { ... }
  }
}
```

### 8.2 配置类 (`swarmbot/config_manager.py`)

```python
@dataclass
class SwarmbotConfig:
    providers: List[ProviderConfig]
    swarm: SwarmSettings
    tools: ToolConfig
    channels: Dict[str, ChannelConfig]
    daemon: DaemonConfig
    autonomous: AutonomousConfig

def load_config() -> SwarmbotConfig
    # 从 config.json 加载，不存在则创建默认配置
```

---

## 九、Development Guide

### 9.1 新功能开发流程

**步骤 1: 确定位置**
- Gateway/Channel 相关 → `swarmbot/gateway/`
- 推理逻辑相关 → `swarmbot/loops/`
- 记忆系统相关 → `swarmbot/memory/`
- 工具/技能相关 → `swarmbot/tools/`

**步骤 2: 添加测试**
```bash
# 运行特定评估脚本
python scripts/eval_inference_benchmark.py --quick
```

### 9.2 关键代码路径

| 需求 | 修改文件 |
|------|----------|
| 调整推理步数 | `swarmbot/loops/inference.py` |
| 修改 Agent 行为 | `swarmbot/core/agent.py` |
| 添加新工具 | `swarmbot/tools/adapter.py` |
| 调整技能映射 | `swarmbot/loops/skill_registry.py` |
| 修改白板结构 | `swarmbot/memory/whiteboard.py` |

### 9.3 配置文件示例

```json
{
  "providers": [
    {
      "name": "primary",
      "base_url": "http://localhost:8080/v1",
      "api_key": "sk-...",
      "model": "qwen3-coder-next",
      "max_tokens": 4096,
      "temperature": 0.6
    }
  ],
  "swarm": {
    "max_agents": 6,
    "roles": ["planner", "coder", "critic", "summarizer"],
    "architecture": "auto",
    "display_mode": "simple"
  },
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30
  }
}
```

### 9.4 启动命令

```bash
# 自动安装（推荐）
python scripts/bootstrap.py --mode auto

# 运行 Gateway
swarmbot gateway

# 运行 Daemon
swarmbot daemon

# 执行评估
python scripts/eval_inference_benchmark.py
```

---

## 十、Framework Architecture Summary

### 10.1 模块依赖关系图

```
┌─────────────────────────────────────────────────────────────────────┐
│                      Module Dependencies                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  CLI (swarmbot/__init__.py)                                         │
│      │                                                               │
│      ├─▶ GatewayServer (gateway/server.py)                          │
│      │     ├─▶ InferenceLoop (loops/inference.py)                   │
│      │     │     ├─▶ Whiteboard (memory/whiteboard.py)              │
│      │     │     ├─▶ HotMemory (memory/hot_memory.py)               │
│      │     │     ├─▶ WarmMemory (memory/warm_memory.py)             │
│      │     │     ├─▶ ColdMemory (memory/cold_memory.py)             │
│      │     │     ├─▶ EvidenceStore (memory/evidence_store.py)       │
│      │     │     ├─▶ SkillRegistry (loops/skill_registry.py)        │
│      │     │     └─▶ ToolAdapter (tools/adapter.py)                 │
│      │     │           └─▶ ToolRegistry (tools/registry.py)         │
│      │     │                                                                 │
│      │     ├─▶ AutonomousEngine (autonomous/engine.py)              │
│      │     │     ├─▶ MonitorQueue                                    │
│      │     │     └─▶ ActionQueue                                     │
│      │     │                                                                 │
│      │     └─▶ SwarmManager (swarm/manager.py)                      │
│      │           ├─▶ CoreAgent (core/agent.py)                      │
│      │           └─▶ OpenAICompatibleClient (llm_client.py)         │
│      │                                                                     │
│      └─▶ ConfigManager (config_manager.py)                          │
│            └─▶ load_config()                                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 10.2 数据流向图

```
┌─────────────────────────────────────────────────────────────────────┐
│                           Data Flow                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  User Input (Feishu)                                                │
│      │                                                               │
│      ▼                                                               │
│  GatewayServer                                                      │
│      │                                                               │
│      ▼                                                               │
│  InferenceLoop.run()                                                │
│      │                                                               │
│      ├─▶ Whiteboard.update("input_prompt")                          │
│      │                                                               │
│      ▼                                                               │
│  Problem Analysis (analyst agents)                                  │
│      │                                                               │
│      ▼                                                               │
│  Whiteboard.update("problem_analysis")                              │
│      │                                                               │
│      ▼                                                               │
│  Information Collection (with tool decision)                        │
│      │                                                               │
│      ├─▶ ToolAdapter.execute("web_search", ...)                     │
│      │     └─▶ Whiteboard.update("information_gathering")           │
│      │                                                               │
│      ▼                                                               │
│  Planning (with framework_doc validation)                           │
│      │                                                               │
│      ▼                                                               │
│  Skill Discovery / Tool Decision                                    │
│      │                                                               │
│      ▼                                                               │
│  Inference Execution (worker agents)                                │
│      │                                                               │
│      ▼                                                               │
│  Evaluation (voting mechanism)                                      │
│      │                                                               │
│      ▼                                                               │
│  Translation & Organization                                         │
│      │                                                               │
│      ├─▶ HotMemory.update()                                         │
│      ├─▶ WarmMemory.append_log()                                    │
│      └─▶ EvidenceStore.append_incremental()                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 十一、Future Development Plan

基于 v1.1 的当前状态，建议的后续优化方向：

### 11.1 短期优化 (v1.1.x)

| 任务 | 说明 |
|------|------|
| 并行化 Tool Gate 投票 | 提高工具决策效率 |
| 强化 Skill 远程检索策略 | 支持动态技能加载 |
| 完善 acceptance_criteria 评估可解释性 | 增强评估透明度 |

### 11.2 中期改进 (v1.2)

| 任务 | 说明 |
|------|------|
| Inference Supervisor 化调度 | 统一的流程控制器 |
| 分层增量请求协议 | 优化 Token 使用 |
| 白板降噪与强约束测试校准 | 提高稳定性 |

### 11.3 长期规划 (v2.0)

| 任务 | 说明 |
|------|------|
| 多模态支持 | 扩展到图像/音频处理 |
| 分布式架构 | 支持多节点协作 |
| 模型即服务路由 | 动态选择最优模型 |

---

## 十二、Appendix

### A. 关键常量与路径

```python
# config_manager.py
CONFIG_HOME = os.path.expanduser("~/.swarmbot")
CONFIG_PATH = os.path.join(CONFIG_HOME, "config.json")
WORKSPACE_PATH = os.path.join(CONFIG_HOME, "workspace")
BOOT_CONFIG_PATH = os.path.join(CONFIG_HOME, "boot")

# memory modules
HOT_MEMORY_FILE = Path(workspace) / "hot_memory.md"
WARM_MEMORY_DIR = Path(workspace) / "memory"
COLD_MEMORY_DIR = Path(workspace) / "qmd"
EVIDENCE_STORE_DIR = Path("~/.swarmbot/evidence")
```

### B. 环境变量

```bash
SWARMBOT_LOOP_PROFILE=auto        # lean/swarm_max/balanced
OPENAI_API_BASE=http://...        # LLM API 地址
OPENAI_API_KEY=sk-...             # API 密钥
LITELLM_MODEL=model-name          # 模型名称
```

### C. 评估脚本

| 脚本 | 功能 |
|------|------|
| `eval_inference_benchmark.py` | 推理性能基准测试 |
| `eval_analysis_routing.py` | 路由准确率测试 |
| `eval_subtask_async.py` | 异步子任务测试 |
| `eval_mmlu_pro.py` | MMLU 专业科目测试 |
| `eval_conflict_stability.py` | 冲突稳定性测试 |

---

**文档版本**: v1.1 Framework Documentation
**生成时间**: 2026-03-14
**维护者**: SwarmBot Team

---

## 更新日志

| 版本 | 日期 | 作者 | 变更内容 |
|------|------|------|----------|
| v1.1 | 2026-03-14 | Claude Opus 4.6 | 完成基于 spec_1.0 和 spec_1.1 的完整框架文档 |
| v1.0 | 2026-03-12 | Project Team | v1.0 基线版本 |

---

## 索引

### A. 模块代码映射表

| 功能模块 | 核心文件路径 | 关键类/函数 |
|----------|-------------|-------------|
| CLI 入口 | `swarmbot/__init__.py` | `onboard()`, `run()`, `gateway()` |
| Gateway 服务 | `swarmbot/gateway/server.py` | `GatewayServer`, `_handle_message_async()` |
| 推理循环 | `swarmbot/loops/inference.py` | `InferenceLoop`, `run()`, `step_*.py` |
| 自治引擎 | `swarmbot/autonomous/engine.py` | `AutonomousEngine`, `MonitorQueue`, `ActionQueue` |
| Agent 执行 | `swarmbot/core/agent.py` | `CoreAgent`, `step()` |
| Swarm 管理 | `swarmbot/swarm/manager.py` | `SwarmManager`, `SwarmSession` |
| 白板存储 | `swarmbot/memory/whiteboard.py` | `Whiteboard`, `update()`, `get()` |
| 热记忆 | `swarmbot/memory/hot_memory.py` | `HotMemory` |
| 温记忆 | `swarmbot/memory/warm_memory.py` | `WarmMemory` |
| 冷记忆 | `swarmbot/memory/cold_memory.py` | `ColdMemory` |
| 证据存储 | `swarmbot/memory/evidence_store.py` | `EvidenceStore`, `append_incremental()` |
| 工具注册 | `swarmbot/tools/registry.py` | `ToolRegistry` |
| 技能注册 | `swarmbot/loops/skill_registry.py` | `SkillRegistry` |

### B. 8步推理流程速查

| Step | 名称 | 输入 | 输出 | 关键代码位置 |
|------|------|------|------|--------------|
| 1 | Metadata Initialization | user_input | whiteboard.metadata | `_step_metadata()` |
| 2 | Problem Analysis | input_prompt | problem_analysis | `analyst_agents` |
| 3 | Information Collection | analysis, history | information_gathering | `_step_collection()` |
| 4 | Action Planning | gathering + config | framework_doc | `planner_agent` |
| 5 | Skill Discovery | task_breakdown | skill_summary/load | `skill_registry.get_skills()` |
| 6 | Tool Decision | framework_doc | tool_gate_config | `_decide_tool_gate()` |
| 7 | Inference Execution | tasks, tools | task_results | `worker_agents` |
| 8 | Evaluation | results + criteria | evaluation_report | `evaluator_agents` |
| 9 | Translation | conclusions | final_response | `master_agent` |
| 10 | Organization | response | hot/warm/evidence | `_step_organization()` |

### C. 默认配置结构

```json
{
  "autonomous": {
    "enabled": true,
    "tick_seconds": 30,
    "max_concurrent_actions": 3,
    "default_locked_bundles": [
      "core.memory_foundation",
      "core.boot_optimizer",
      "core.system_hygiene",
      "core.bundle_governor"
    ]
  },
  "swarm": {
    "max_agents": 4,
    "roles": ["planner", "coder", "critic", "summarizer"],
    "architecture": "auto"
  }
}
```

### D. 关键数据结构

#### Whiteboard (L1)
```python
{
    "wb_control": {"stage", "stage_lock", "retry_count", "control_actions"},
    "wb_plan": {"framework_doc", "task_status", "checkpoints"},
    "wb_evidence": {"critical_facts", "critical_quotes", "external_refs"}
}
```

#### framework_doc (required-only)
```python
{
    "schema_version", "objective", "scope",
    "hard_constraints", "task_breakdown",
    "acceptance_criteria", "checkpoint_plan",
    "rollback_strategy", "early_finish_rules"
}
```

### E. 执行链路图

```
Gateway → InferenceLoop (8-Step) → Response
           ↓
      AutonomousEngine (Background)
           ↓
      MonitorQueue → ActionQueue → Tasks
```

---

**版权信息**: 本框架文档基于 SwarmBot v1.1 版本，遵循 Apache License 2.0。
