# Swarmbot 系统设计文档 (v1.3)

本文档旨在详尽描述 Swarmbot 的当前系统架构、核心组件设计、配置逻辑及调用链路，防止未来开发中的功能回归或错误覆写。

## 1. 系统概览 (Architecture Overview)

Swarmbot 是一个基于 **Nanobot** 框架演进的多 Agent 协作系统（Swarm），支持本地与云端 LLM 模型。其核心理念是自组织协作（Self-Organizing）与持久化记忆（QMD - Quantum Memory Drive）。

### 核心特性
- **自组织架构**：AutonomousEngine 使用 Bundle 模式实现自组织，替代传统的 Overthinking/Overaction Loop。
- **纯粹的 LLM 客户端**：通过 `OpenAICompatibleClient` 直接对接 LiteLLM，移除了复杂的中间件 Provider 抽象。
- **本地优先**：原生支持 vLLM 等本地推理端点，自动归一化 OpenAI 兼容接口。
- **守护进程 (Daemon)**：后台管理 Gateway、Autonomous Engine 和健康检查。

### 自组织引擎架构

AutonomousEngine 使用两个队列实现自组织：

| Queue | Purpose |
|-------|---------|
| `MonitorQueue` | 存储来自 Bundle 检查的事件（内存基础、启动优化、系统卫生、Bundle 协调） |
| `ActionQueue` | 存储已批准的行动，包含 Swarm 配置、任务列表、重试策略 |

内置 Bundles:
- `core.memory_foundation`: 定期记忆压缩 (默认 30 分钟)
- `core.boot_optimizer`: 启动提示优化 (默认 20 分钟)
- `core.system_hygiene`: 磁盘/内存监控 (默认 10 分钟)
- `core.bundle_governor`: Bundle 冲突检测 (默认 5 分钟)

### 路由模式系统 (v2.0 简化)

InferenceLoop 使用三种路由模式进行智能编排：

| Route | Profile | 描述 |
|-------|---------|------|
| `simple_direct_master` | lean | 简单问题，直接由 Master Agent 回答 (1 步) |
| `reasoning_swarm` | balanced | 多 Agent Swarm 协作推理 (2 步) |
| `engineering_complex` | swarm_max | 复杂任务需要交互式工作流（分析/计划审查时的人类参与） |

**v2.0 简化变更**:
- **路由器**: 移除前置规则判断 (task_type/domain)，纯 3 代理投票输出 1/2/3
- **Route 1**: 从 6 步简化到 1 步 - Master Agent 直接回答 → 保存记忆 → 结束
- **Route 2**: 从 8 步简化到 2 步 - 多代理推理 → Master Agent 综合回答 → 保存记忆 → 结束
- **Route 3**: 保持不变，支持悬挂确认机制

路由决策通过 3 个 Planner Agent 的多数决投票决定，只输出数字 1/2/3。

---

## 2. 核心组件设计

### 2.1 LLM Client (`swarmbot.llm_client`)
**职责**：负责所有与 LLM 的交互，是系统唯一的出口。
- **实现**：`OpenAICompatibleClient`。
- **依赖**：直接调用 `litellm.completion` / `acompletion`。
- **配置**：
  - 仅接受 `LLMConfig` 对象。
  - **关键逻辑**：
    - **禁止自动 URL 修正**：不再自动为本地 IP 追加 `/v1`，完全尊重用户配置的 `base_url`。
    - **日志抑制**：默认关闭 LiteLLM 的 `debug_info` 和 `drop_params` 警告。
    - **错误处理**：包含重试机制（Exponential Backoff）和 Schema 错误降级（自动重试不带工具的请求）。

### 2.2 配置管理 (`swarmbot.config_manager`)
**职责**：加载和保存全局配置。
- **路径**：`~/.swarmbot/config.json`。
- **数据结构**：
  - `providers`: 列表，但 CLI 逻辑目前强制仅使用第一个作为 Primary。
  - `swarm`: 定义 `max_agents`, `architecture` 等。
  - `daemon`: 定义后台服务行为（Gateway, Autonomous 启停）。
  - `channels`: 定义消息通道（Feishu, Telegram 等）。
- **默认行为**：
  - `daemon.manage_gateway`: **True** (默认启动 Gateway)。
  - `daemon.manage_autonomous`: **True** (默认启动自主引擎)。

### 2.3 守护进程 (`swarmbot.daemon`)
**职责**：作为系统常驻进程，维持核心服务运行。
- **启动方式**：`swarmbot daemon start`。
- **管理服务**：
  1.  **Gateway** (`swarmbot.cli gateway`): 处理外部消息（Feishu 等）并分发给 Swarm。
  2.  **Autonomous Engine** (`swarmbot.autonomous.engine`): 后台自组织循环（记忆压缩、引导优化、系统维护）。
- **机制**：
  - 使用 `subprocess.Popen` 启动子进程。
  - 自动重启崩溃的子进程。
  - 定期备份配置与 Boot 文件。

### 2.4 网关与消息路由 (`swarmbot.gateway`)
**职责**：连接外部消息通道与内部推理循环。
- **实现**：`GatewayServer`。
- **流程**：
  1.  初始化 Channels (如 Feishu)。
  2.  接收 `InboundMessage`。
  3.  将消息放入线程池，调用 `InferenceLoop.run()`。
  4.  获取结果并封装为 `OutboundMessage` 返回。
- **注意**：不再使用 `nanobot` 的 AgentLoop，而是直接使用 Swarmbot 的 `InferenceLoop`。

### 2.5 推理循环 (`swarmbot.loops.inference`)
**职责**：处理单次用户请求的完整生命周期。

#### 路由模式（自组织决策）
在 v1.3 中，路由模式通过 LLM 驱动的投票机制自动选择：

| Route | Profile | 适用场景 |
|-------|---------|----------|
| `simple_direct_master` | lean | 简单知识问答，无需工具调用 |
| `reasoning_swarm` | balanced | 中等复杂度任务，需要多 Agent 协作 |
| `engineering_complex` | swarm_max | 复杂工程任务，需要人机交互确认 |

#### 8-Step 推理流程 (SOP)
1.  **Analysis**: 分析用户意图（无工具）。
2.  **Collection**: 收集上下文与记忆（有工具）。
3.  **Planning**: 生成行动计划（JSON framework_doc）。
4.  **Execution**: 执行计划中的任务（多 Agent 并行/串行）。
5.  **Evaluation**: 评估结果质量（支持多轮自我批评）。
6.  **Translation**: 答案生成与格式化。
7.  **Organization**: 更新 Whiteboard 和记忆。
8.  **Feedback** (可选): 接收用户反馈用于后续优化。

#### 记忆交互
- Whiteboard (L1): 瞬时记忆，仅在 Loop 内有效。
- HotMemory (L2): 短期记忆，持久化到工作区。

---

## 3. 关键调用链路

### 3.1 用户发送消息 (CLI/Feishu)
```mermaid
[User] -> [Channel (Feishu)] -> [MessageBus] -> [GatewayServer]
                                                      |
                                          (ThreadPoolExecutor)
                                                      v
                                              [InferenceLoop]
                                                      |
                                            [OpenAICompatibleClient]
                                                      |
                                                  (LiteLLM)
                                                      v
                                              [Local/Remote LLM]
```

### 3.2 守护进程启动
```mermaid
[CLI: daemon start] -> [Daemon Process]
                            |-- (Spawn) --> [Gateway Process]
                            |-- (Spawn) --> [Autonomous Engine]
                            |-- (Loop)  --> [Health Check / Backup]
```

---

## 4. 维护与防回归指南

1.  **禁止恢复 `nanobot.providers`**：
    -   系统已彻底解耦 `nanobot` 的 provider 抽象。任何新功能必须通过 `llm_client.py` 实现。
    -   `litellm_provider.py` 应保持为空或被删除状态（目前已精简）。

2.  **本地模型兼容性**：
    -   所有 URL 处理逻辑必须在 `llm_client.py` 中显式处理，**严禁**隐式修改用户输入的 `base_url`（如自动加 `/v1`），除非是明确的协议适配层。
    -   配置中必须明确区分 `openai/` 前缀的使用场景（LiteLLM 路由需求）。

3.  **Daemon 默认值**：
    -   `config_manager.py` 中 `DaemonConfig` 的 `manage_gateway` 和 `manage_autonomous` 必须默认为 `True`，确保开箱即用。

4.  **依赖管理**：
    -   `nanobot` 目录下的代码仅作为工具库（Bus, Channels, Tools）保留，**不应**包含核心 Agent 逻辑。

---

## 5. 当前版本状态 (v1.1)
- **状态**：Stable
- **已知问题修复**：
  - 修复了本地模型因自动追加 `/v1` 导致的 404 错误。
  - 修复了 LiteLLM 日志过噪问题。
  - 修复了 Daemon 不自动启动 Gateway 的问题。
  - 移除 Overthinking/Overaction Loop，替换为 Autonomous Engine（自组织系统）。
